import React, { useState } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext.tsx';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { BottomNav } from './components/BottomNav.tsx';
import { AIHeroSection } from './components/AIHeroSection.tsx';
import { CategoryGrid } from './components/CategoryGrid.tsx';
import { BookingModal } from './components/BookingModal.tsx';
import { RentAgreementForm } from './components/RentAgreementForm.tsx';
import { RoadsideAssistanceView } from './components/RoadsideAssistanceView.tsx';
import { CustomerBookingsView } from './components/CustomerBookingsView.tsx';
import { JobsSection } from './components/JobsSection.tsx';
import { RecruiterPortal } from './components/RecruiterPortal.tsx';
import { ProviderPortal } from './components/ProviderPortal.tsx';
import { AdminPortal } from './components/AdminPortal.tsx';
import { CustomerProfileView } from './components/CustomerProfileView.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { TrustSafetyModal } from './components/TrustSafetyModal.tsx';
import { ServiceDetailModal } from './components/ServiceDetailModal.tsx';
import { BikeRepairFlow } from './components/BikeRepairFlow.tsx';
import { Logo } from './components/Logo.tsx';
import { Service, Booking } from './types/index.ts';
import { ShieldCheck, Heart, Sparkles, CheckCircle2, ShieldAlert } from 'lucide-react';

function AppContent() {
  const { t, language } = useLanguage();
  const { user, activeRole } = useAuth();

  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [viewingServiceDetail, setViewingServiceDetail] = useState<Service | null>(null);
  const [initialProblemText, setInitialProblemText] = useState<string>('');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [safetyModalOpen, setSafetyModalOpen] = useState(false);
  const [bookingSuccessToast, setBookingSuccessToast] = useState<Booking | null>(null);

  const handleSelectService = (service: Service, problemText?: string) => {
    setSelectedService(service);
    setInitialProblemText(problemText || '');
  };

  const handleBookingCompleted = (booking: Booking) => {
    setSelectedService(null);
    setBookingSuccessToast(booking);
    setActiveTab('bookings');
    setTimeout(() => setBookingSuccessToast(null), 6000);
  };

  const handleLoginSuccess = (role: string) => {
    if (role === 'admin') {
      setActiveTab('admin-panel');
    } else if (role === 'provider') {
      setActiveTab('provider-portal');
    } else {
      setActiveTab('home');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-amber-500 selection:text-slate-950 pb-20 md:pb-0">
      {/* Navbar */}
      <Navbar
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenSafety={() => setSafetyModalOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Booking Success Toast Notification */}
      {bookingSuccessToast && (
        <div className="fixed top-20 right-4 sm:right-6 z-50 bg-emerald-700 text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-emerald-500 flex items-center gap-3 animate-in slide-in-from-top-4 duration-300">
          <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
          <div className="text-xs">
            <span className="font-bold block">Booking Confirmed! #{bookingSuccessToast.bookingNumber}</span>
            <span className="text-emerald-100">Financial snapshot secured. Provider dispatch initialized.</span>
          </div>
        </div>
      )}

      {/* Main View Router */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <>
            <AIHeroSection
              onSelectService={handleSelectService}
              onOpenRentAgreement={() => setActiveTab('rent-agreement')}
              onOpenRoadside={() => setActiveTab('bike-repair')}
            />
            <CategoryGrid
              onSelectService={handleSelectService}
              onViewServiceDetails={(svc) => setViewingServiceDetail(svc)}
              onOpenRentAgreement={() => setActiveTab('rent-agreement')}
              onOpenRoadside={() => setActiveTab('roadside')}
              onOpenBikeRepair={() => setActiveTab('bike-repair')}
              onOpenJobs={() => setActiveTab('jobs')}
            />
          </>
        )}

        {activeTab === 'rent-agreement' && (
          <div className="py-10 px-4 max-w-4xl mx-auto">
            <RentAgreementForm
              onSuccess={handleBookingCompleted}
              onCancel={() => setActiveTab('home')}
              onOpenAuth={() => setAuthModalOpen(true)}
            />
          </div>
        )}

        {activeTab === 'bike-repair' && (
          <div className="py-10 px-4 max-w-4xl mx-auto">
            <BikeRepairFlow
              onSuccess={handleBookingCompleted}
              onCancel={() => setActiveTab('home')}
              onOpenAuth={() => setAuthModalOpen(true)}
            />
          </div>
        )}

        {activeTab === 'roadside' && (
          <div className="py-10 px-4 max-w-4xl mx-auto">
            <RoadsideAssistanceView
              onBookEmergency={(svc, problem, loc) => handleSelectService(svc, problem)}
              onCancel={() => setActiveTab('home')}
              onOpenAuth={() => setAuthModalOpen(true)}
            />
          </div>
        )}

        {activeTab === 'bookings' && (
          <CustomerBookingsView
            onOpenExplore={() => setActiveTab('home')}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {activeTab === 'jobs' && (
          <JobsSection
            onSelectPaidService={handleSelectService}
            onOpenRecruiterPortal={() => setActiveTab('recruiter-portal')}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {activeTab === 'provider-portal' && (
          <ProviderPortal onOpenAuth={() => setAuthModalOpen(true)} />
        )}

        {activeTab === 'recruiter-portal' && (
          <RecruiterPortal onOpenAuth={() => setAuthModalOpen(true)} />
        )}

        {/* Admin Dashboard: Strictly never expose to customer or non-admin */}
        {activeTab === 'admin-panel' && (
          user?.role === 'admin' ? (
            <AdminPortal />
          ) : (
            <div className="py-24 px-4 max-w-lg mx-auto text-center space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-amber-50 text-amber-700 flex items-center justify-center mx-auto shadow-sm">
                <ShieldAlert className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">Access Restricted</h2>
              <p className="text-xs text-slate-500 leading-relaxed">
                Administrator credentials are required to view the administrative console. If you are an administrator, please sign in with your administrative account.
              </p>
              <div className="pt-2 flex justify-center gap-3">
                <button
                  onClick={() => setActiveTab('home')}
                  className="px-5 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800 transition"
                >
                  Return to Home
                </button>
                {!user && (
                  <button
                    onClick={() => setAuthModalOpen(true)}
                    className="px-5 py-2.5 rounded-xl bg-blue-600 text-white font-bold text-xs hover:bg-blue-700 transition"
                  >
                    Admin Sign In
                  </button>
                )}
              </div>
            </div>
          )
        )}

        {activeTab === 'wallet' && (
          user?.role === 'provider' ? (
            <ProviderPortal onOpenAuth={() => setAuthModalOpen(true)} />
          ) : (
            <CustomerBookingsView
              onOpenExplore={() => setActiveTab('home')}
              onOpenAuth={() => setAuthModalOpen(true)}
            />
          )
        )}

        {activeTab === 'profile' && (
          <CustomerProfileView onOpenAuth={() => setAuthModalOpen(true)} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-slate-800">
            <div>
              <Logo size="lg" inverted={true} />
              <p className="text-xs text-slate-400 mt-2 max-w-sm">
                India's trusted on-demand service marketplace. Verified professionals, transparent pricing, and instant coordination.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs font-semibold">
              <button onClick={() => setActiveTab('home')} className="hover:text-white transition">
                {t('home')}
              </button>
              <button onClick={() => setActiveTab('bookings')} className="hover:text-white transition">
                {t('bookings')}
              </button>
              <button onClick={() => setActiveTab('jobs')} className="hover:text-white transition">
                {t('jobs')}
              </button>
              <button onClick={() => setSafetyModalOpen(true)} className="hover:text-white transition">
                {t('customerSafety')}
              </button>
              <button
                onClick={() => {
                  if (user?.role === 'provider') {
                    setActiveTab('provider-portal');
                  } else {
                    setAuthModalOpen(true);
                  }
                }}
                className="text-amber-400 hover:text-amber-300 font-bold"
              >
                Become a Partner
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <p>© {new Date().getFullYear()} KARWA DO Technologies Private Limited. All rights reserved.</p>
            <div className="flex items-center gap-4">
              <span>Made for Indian Consumers & Professionals</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                <span>Verified Aadhaar / KYC Standards</span>
              </span>
            </div>
          </div>
        </div>
      </footer>

      {/* Bottom Navigation for Mobile */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      {/* Customer Service Page / Detail Modal (Phase 3 Section 17) */}
      {viewingServiceDetail && (
        <ServiceDetailModal
          service={viewingServiceDetail}
          onClose={() => setViewingServiceDetail(null)}
          onBook={(svc) => {
            setViewingServiceDetail(null);
            handleSelectService(svc);
          }}
        />
      )}

      {/* Regular Booking Modal */}
      {selectedService && (
        <BookingModal
          service={selectedService}
          initialProblemText={initialProblemText}
          onClose={() => setSelectedService(null)}
          onBookingSuccess={handleBookingCompleted}
          onOpenAuth={() => setAuthModalOpen(true)}
        />
      )}

      {/* Auth Modal with Phase 2 capabilities */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* Trust & Safety Modal */}
      <TrustSafetyModal isOpen={safetyModalOpen} onClose={() => setSafetyModalOpen(false)} />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}
