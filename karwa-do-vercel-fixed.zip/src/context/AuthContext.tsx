import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth, googleAuthProvider } from '../lib/firebase.ts';
import { signInWithPopup, signOut as fbSignOut } from 'firebase/auth';
import { UserProfile, Address, UserRole } from '../types/index.ts';

interface VerifyOtpResult {
  success: boolean;
  isNewUser: boolean;
  user?: UserProfile;
  token?: string;
  role?: UserRole;
  tempToken?: string;
  phone?: string;
  redirectUrl?: string;
}

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  token: string | null;
  activeRole: UserRole;
  addresses: Address[];
  sendMobileOtp: (phone: string) => Promise<{ success: boolean; message: string; cooldownSeconds?: number; devTestingOtp?: string }>;
  verifyMobileOtp: (phone: string, otp: string) => Promise<VerifyOtpResult>;
  completeOtpRegistration: (data: {
    tempToken?: string;
    phone: string;
    name: string;
    email?: string;
    role: 'customer' | 'provider';
    preferredLanguage: string;
    city: string;
    pincode: string;
    profilePhoto?: string;
    termsConsent: boolean;
  }) => Promise<{ success: boolean; user: UserProfile; token?: string; role?: UserRole; redirectUrl: string }>;
  registerCustomer: (data: {
    name: string;
    phone: string;
    email?: string;
    preferredLanguage: string;
    city: string;
    pincode: string;
    profilePhoto?: string;
    password?: string;
    termsConsent: boolean;
    role?: 'customer' | 'provider';
  }) => Promise<{ success: boolean; user: UserProfile; token?: string; role?: UserRole; redirectUrl: string }>;
  loginWithEmail: (email: string, password: string) => Promise<{ success: boolean; user: UserProfile; token?: string; role?: UserRole; redirectUrl: string }>;
  registerWithEmail: (data: {
    name: string;
    email: string;
    password: string;
    phone?: string;
    city?: string;
    pincode?: string;
    preferredLanguage?: string;
    role?: 'customer' | 'provider';
    termsConsent: boolean;
  }) => Promise<{ success: boolean; user: UserProfile; token?: string; role?: UserRole; redirectUrl: string }>;
  forgotPassword: (email: string) => Promise<{ success: boolean; message: string; devTestingCode?: string }>;
  resetPassword: (email: string, resetCode: string, newPassword: string) => Promise<{ success: boolean; message: string }>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  addAddress: (addressData: Partial<Address>) => Promise<Address | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('karwado_token'));
  const [activeRole, setActiveRole] = useState<UserRole>(() => {
    const saved = localStorage.getItem('karwado_role') as UserRole;
    return saved === 'admin' || saved === 'provider' ? saved : 'customer';
  });
  const [addresses, setAddresses] = useState<Address[]>([]);

  useEffect(() => {
    const savedToken = localStorage.getItem('karwado_token');
    if (savedToken) {
      loadProfile(savedToken).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const loadProfile = async (authToken: string) => {
    try {
      const res = await fetch('/api/user/me', {
        headers: {
          Authorization: `Bearer ${authToken}`,
          'x-user-id': authToken,
        },
      });

      if (res.ok) {
        const data = await res.json();
        if (data.user) {
          setUser(data.user);
          setActiveRole(data.user.role || 'customer');
          localStorage.setItem('karwado_role', data.user.role || 'customer');
          // Sync language preference if set
          if (data.user.preferredLanguage) {
            localStorage.setItem('karwado_lang', data.user.preferredLanguage);
          }
        }
        if (data.addresses) {
          setAddresses(data.addresses);
        }
      } else if (res.status === 401 || res.status === 404) {
        // Token invalid or deactivated
        logout();
      }
    } catch (err) {
      console.error('Failed to load user profile:', err);
    }
  };

  const handleAuthSuccess = (userData: UserProfile, authToken: string, role?: UserRole) => {
    setUser(userData);
    setToken(authToken);
    const resolvedRole = (role || userData.role || 'customer') as UserRole;
    setActiveRole(resolvedRole);
    localStorage.setItem('karwado_token', authToken);
    localStorage.setItem('karwado_role', resolvedRole);
    if (userData.preferredLanguage) {
      localStorage.setItem('karwado_lang', userData.preferredLanguage);
    }
    loadProfile(authToken);
  };

  const sendMobileOtp = async (phone: string) => {
    const res = await fetch('/api/auth/otp/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to send OTP.');
    }
    return data;
  };

  const verifyMobileOtp = async (phone: string, otp: string): Promise<VerifyOtpResult> => {
    const res = await fetch('/api/auth/otp/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, otp }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'OTP verification failed.');
    }

    if (!data.isNewUser && data.user && data.token) {
      handleAuthSuccess(data.user, data.token, data.role);
    }

    return data;
  };

  const completeOtpRegistration = async (formData: {
    tempToken?: string;
    phone: string;
    name: string;
    email?: string;
    role: 'customer' | 'provider';
    preferredLanguage: string;
    city: string;
    pincode: string;
    profilePhoto?: string;
    termsConsent: boolean;
  }) => {
    const res = await fetch('/api/auth/otp/complete-registration', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to complete registration.');
    }

    handleAuthSuccess(data.user, data.token, data.role);
    return data;
  };

  const registerCustomer = async (formData: {
    name: string;
    phone: string;
    email?: string;
    preferredLanguage: string;
    city: string;
    pincode: string;
    profilePhoto?: string;
    password?: string;
    termsConsent: boolean;
    role?: 'customer' | 'provider';
  }) => {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Registration failed.');
    }

    handleAuthSuccess(data.user, data.token, data.role);
    return data;
  };

  const loginWithEmail = async (email: string, password: string) => {
    const res = await fetch('/api/auth/email/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Invalid email or password.');
    }

    handleAuthSuccess(data.user, data.token, data.role);
    return data;
  };

  const registerWithEmail = async (formData: {
    name: string;
    email: string;
    password: string;
    phone?: string;
    city?: string;
    pincode?: string;
    preferredLanguage?: string;
    role?: 'customer' | 'provider';
    termsConsent: boolean;
  }) => {
    const res = await fetch('/api/auth/email/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Registration failed.');
    }

    handleAuthSuccess(data.user, data.token, data.role);
    return data;
  };

  const forgotPassword = async (email: string) => {
    const res = await fetch('/api/auth/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to send password reset code.');
    }
    return data;
  };

  const resetPassword = async (email: string, resetCode: string, newPassword: string) => {
    const res = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, resetCode, newPassword }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to reset password.');
    }
    return data;
  };

  const loginWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleAuthProvider);
      const idToken = await result.user.getIdToken();

      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Google login is currently unavailable.');
      }

      handleAuthSuccess(data.user, data.token, data.role);
    } catch (err: any) {
      console.warn('Google Sign-In Error:', err);
      // Explicit requirement: if Google OAuth is not configured or fails, show exact message:
      throw new Error('Google login is currently unavailable.');
    }
  };

  const logout = async () => {
    try {
      await fbSignOut(auth);
    } catch (e) {
      // Ignore
    }
    setUser(null);
    setToken(null);
    setActiveRole('customer');
    localStorage.removeItem('karwado_token');
    localStorage.removeItem('karwado_role');
  };

  const refreshProfile = async () => {
    if (token) {
      await loadProfile(token);
    }
  };

  const addAddress = async (addr: Partial<Address>): Promise<Address | null> => {
    if (!token) return null;
    try {
      const res = await fetch('/api/addresses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'x-user-id': token,
        },
        body: JSON.stringify(addr),
      });
      if (res.ok) {
        const created = await res.json();
        setAddresses((prev) => [...prev, created]);
        return created;
      }
    } catch (err) {
      console.error('Error adding address:', err);
    }
    return null;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        token,
        activeRole,
        addresses,
        sendMobileOtp,
        verifyMobileOtp,
        completeOtpRegistration,
        registerCustomer,
        loginWithEmail,
        registerWithEmail,
        forgotPassword,
        resetPassword,
        loginWithGoogle,
        logout,
        refreshProfile,
        addAddress,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
