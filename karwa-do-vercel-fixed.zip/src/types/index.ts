export type UserRole = 'customer' | 'provider' | 'admin';

export interface ServiceCategory {
  id: number;
  slug: string;
  name: string;
  icon: string;
  description: string | null;
  displayOrder: number;
  isActive: boolean;
}

export interface Service {
  id: number;
  categoryId: number;
  categorySlug?: string;
  categoryName?: string;
  slug: string;
  name: string;
  description: string | null;
  pricingType: 'FIXED' | 'STARTING_FROM' | 'CUSTOM_QUOTE' | 'fixed' | 'starting' | 'quote';
  customerPrice: number;
  minPrice?: number | null;
  maxPrice?: number | null;
  commissionType?: 'FIXED' | 'PERCENTAGE' | 'FIXED_AMOUNT' | string;
  commissionValue?: number | string;
  platformCommission: number;
  platformFee: number;
  providerAmount: number;
  serviceArea?: string | null;
  providerEligibility?: string | null;
  estimatedDuration: string | null;
  requiredDocuments?: string[];
  customerInstructions?: string | null;
  shortDescription?: string | null;
  detailedDescription?: string | null;
  cancellationPolicy?: string | null;
  faq?: Array<{ question: string; answer: string }>;
  whatsIncluded: string[];
  requirements: string[];
  isActive: boolean;
  translations?: Record<string, {
    name?: string;
    description?: string;
    shortDescription?: string;
    detailedDescription?: string;
    customerInstructions?: string;
  }>;
}

export interface CustomQuote {
  id: number;
  bookingId: number;
  providerId: number;
  quoteAmount: number;
  platformFee: number;
  totalAmount: number;
  status: 'pending_approval' | 'approved' | 'rejected';
  details?: string | null;
  createdAt: string;
  approvedAt?: string | null;
}

export interface PriceChange {
  id: number;
  bookingId: number;
  providerId: number;
  originalAmount: number;
  additionalAmount: number;
  newTotal: number;
  reason?: string | null;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  respondedAt?: string | null;
}

export interface Address {
  id: number;
  userId: string;
  label: 'Home' | 'Work' | 'Other' | string;
  fullAddress: string;
  area?: string | null;
  landmark: string | null;
  city: string;
  state: string;
  pincode: string;
  latitude: string | null;
  longitude: string | null;
  isDefault: boolean;
}

export interface Booking {
  id: number;
  bookingNumber: string;
  customerId: string;
  serviceId: number;
  providerId: number | null;
  addressId: number | null;
  status: 'requested' | 'provider_assigned' | 'provider_on_the_way' | 'in_progress' | 'completed' | 'cancelled' | 'disputed';
  scheduledDate: string;
  scheduledTime: string;
  problemDescription: string | null;
  serviceType: string;
  serviceDetails: Record<string, any>;
  snapshotCustomerTotal: number;
  snapshotPlatformCommission: number;
  snapshotPlatformFee: number;
  snapshotProviderAmount: number;
  additionalChargeRequested: number;
  additionalChargeApproved: boolean;
  additionalChargeReason: string | null;
  paymentStatus: 'pending' | 'processing' | 'paid' | 'failed' | 'refunded';
  paymentMethod: string;
  paymentTransactionId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Provider {
  id: number;
  userId: string;
  businessName: string | null;
  categories: string[];
  serviceAreas: string[];
  city?: string | null;
  pincode?: string | null;
  profilePhoto?: string | null;
  experienceYears: number;
  kycStatus: 'pending' | 'under_review' | 'verified' | 'rejected';
  kycDocumentType: string | null;
  kycDocumentNumber: string | null;
  bankAccountName: string | null;
  bankAccountNumber: string | null;
  bankIfsc: string | null;
  upiId: string | null;
  isOnline: boolean;
  ratingAverage: string;
  totalReviews: number;
  totalJobsCompleted: number;
}

export interface ProviderWorkingHour {
  id?: number;
  providerId?: number;
  dayOfWeek: string;
  isOpen: boolean;
  startTime: string;
  endTime: string;
}

export interface ProviderLedgerEntry {
  id: number;
  providerId: number;
  bookingId: number | null;
  entryType: 'credit_earning' | 'debit_payout' | 'adjustment';
  amount: number;
  balanceAfter: number;
  description: string;
  createdAt: string;
}

export interface PayoutRequest {
  id: number;
  providerId: number;
  amount: number;
  status: 'pending' | 'processing' | 'completed' | 'rejected';
  bankReference: string | null;
  requestedAt: string;
  processedAt: string | null;
  rejectionReason: string | null;
}

export interface Job {
  id: number;
  recruiterId: string;
  title: string;
  companyName: string;
  category: string;
  location: string;
  salaryMin: number | null;
  salaryMax: number | null;
  experienceMin: number;
  jobType: 'full_time' | 'part_time' | 'contract' | 'internship';
  workMode: 'on_site' | 'remote' | 'hybrid';
  skillsRequired: string[];
  description: string;
  status: 'active' | 'paused' | 'closed';
  createdAt: string;
}

export interface JobApplication {
  id: number;
  jobId: number;
  candidateId: string;
  applicantName: string;
  applicantEmail: string;
  applicantPhone: string;
  resumeUrl: string | null;
  status: 'applied' | 'reviewed' | 'shortlisted' | 'interview_scheduled' | 'rejected' | 'hired';
  matchScore: number | null;
  createdAt: string;
}

export interface UserProfile {
  id: number;
  uid: string;
  email: string | null;
  phone: string | null;
  name: string | null;
  avatar: string | null;
  profilePhoto?: string | null;
  role: UserRole;
  preferredLanguage: string;
  city?: string | null;
  pincode?: string | null;
  isVerified?: boolean;
  isActive?: boolean;
  createdAt: string;
}
