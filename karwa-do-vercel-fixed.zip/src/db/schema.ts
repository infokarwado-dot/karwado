import { relations } from 'drizzle-orm';
import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core';

// Users table (Role: CUSTOMER, PROVIDER, ADMIN)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email'),
  phone: text('phone'),
  name: text('name'),
  avatar: text('avatar'),
  role: text('role').notNull().default('customer'), // 'customer' | 'provider' | 'admin'
  preferredLanguage: text('preferred_language').notNull().default('en'),
  city: text('city'),
  pincode: text('pincode'),
  passwordHash: text('password_hash'),
  salt: text('salt'),
  isVerified: boolean('is_verified').default(false),
  isEmailVerified: boolean('is_email_verified').default(false),
  isPhoneVerified: boolean('is_phone_verified').default(false),
  termsConsent: boolean('terms_consent').default(false),
  termsAcceptedAt: timestamp('terms_accepted_at'),
  isActive: boolean('is_active').default(true),
  deletedAt: timestamp('deleted_at'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Secure OTP verification table
export const otpVerifications = pgTable('otp_verifications', {
  id: serial('id').primaryKey(),
  phone: text('phone').notNull(),
  otpHash: text('otp_hash').notNull(),
  salt: text('salt').notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  attempts: integer('attempts').default(0),
  verified: boolean('verified').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Secure Password Reset Tokens (Section 4)
export const passwordResetTokens = pgTable('password_reset_tokens', {
  id: serial('id').primaryKey(),
  email: text('email').notNull(),
  tokenHash: text('token_hash').notNull(),
  salt: text('salt').notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  used: boolean('used').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Secure Email Verification Tokens (Section 4)
export const emailVerificationTokens = pgTable('email_verification_tokens', {
  id: serial('id').primaryKey(),
  email: text('email').notNull(),
  tokenHash: text('token_hash').notNull(),
  salt: text('salt').notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  verified: boolean('verified').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Languages supported
export const languages = pgTable('languages', {
  id: serial('id').primaryKey(),
  code: text('code').notNull().unique(), // 'en', 'hi', 'mr', 'gu', 'ta', 'te', 'bn'
  name: text('name').notNull(),
  nativeName: text('native_name').notNull(),
  flag: text('flag').notNull(),
  isActive: boolean('is_active').default(true),
});

// User language preferences
export const userLanguagePreferences = pgTable('user_language_preferences', {
  id: serial('id').primaryKey(),
  userId: text('user_id')
    .references(() => users.uid)
    .notNull()
    .unique(),
  languageCode: text('language_code').notNull().default('en'),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Centralized UI Translations
export const translations = pgTable('translations', {
  id: serial('id').primaryKey(),
  key: text('key').notNull(),
  languageCode: text('language_code').notNull(),
  value: text('value').notNull(),
});

// Service Translations
export const serviceTranslations = pgTable('service_translations', {
  id: serial('id').primaryKey(),
  serviceId: integer('service_id').references(() => services.id).notNull(),
  languageCode: text('language_code').notNull(),
  name: text('name').notNull(),
  description: text('description'),
  shortDescription: text('short_description'),
  detailedDescription: text('detailed_description'),
  customerInstructions: text('customer_instructions'),
  whatsIncluded: jsonb('whats_included').default([]),
  requirements: jsonb('requirements').default([]),
});

// Category Translations
export const categoryTranslations = pgTable('category_translations', {
  id: serial('id').primaryKey(),
  categoryId: integer('category_id').references(() => serviceCategories.id).notNull(),
  languageCode: text('language_code').notNull(),
  name: text('name').notNull(),
  description: text('description'),
});

// Profiles for extended info
export const profiles = pgTable('profiles', {
  id: serial('id').primaryKey(),
  userId: text('user_id')
    .references(() => users.uid)
    .notNull()
    .unique(),
  bio: text('bio'),
  city: text('city'),
  state: text('state'),
  pincode: text('pincode'),
  profilePhoto: text('profile_photo'),
  notificationSettings: jsonb('notification_settings').default({
    sms: true,
    whatsapp: true,
    email: true,
    push: true,
  }),
  createdAt: timestamp('created_at').defaultNow(),
});

// Service Categories
export const serviceCategories = pgTable('service_categories', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  icon: text('icon').notNull(),
  description: text('description'),
  displayOrder: integer('display_order').default(0),
  isActive: boolean('is_active').default(true),
});

// Services with admin pricing & commission controls
export const services = pgTable('services', {
  id: serial('id').primaryKey(),
  categoryId: integer('category_id').references(() => serviceCategories.id),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  description: text('description'),
  icon: text('icon'),
  serviceArea: text('service_area').default('All India'),
  pricingType: text('pricing_type').default('fixed'), // fixed, starting, quote (or FIXED, STARTING_FROM, CUSTOM_QUOTE)
  customerPrice: integer('customer_price').notNull(),
  minPrice: integer('min_price'),
  maxPrice: integer('max_price'),
  commissionType: text('commission_type').default('FIXED'), // FIXED or PERCENTAGE
  commissionValue: numeric('commission_value').default('0'),
  platformCommission: integer('platform_commission').notNull(),
  platformFee: integer('platform_fee').default(0),
  providerAmount: integer('provider_amount').notNull(),
  commissionPercentage: numeric('commission_percentage', { precision: 5, scale: 2 }),
  estimatedDuration: text('estimated_duration'),
  providerEligibility: text('provider_eligibility'),
  requiredDocuments: jsonb('required_documents').default([]),
  customerInstructions: text('customer_instructions'),
  shortDescription: text('short_description'),
  detailedDescription: text('detailed_description'),
  cancellationPolicy: text('cancellation_policy'),
  faq: jsonb('faq').default([]),
  whatsIncluded: jsonb('whats_included').default([]),
  requirements: jsonb('requirements').default([]),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Service Areas
export const serviceAreas = pgTable('service_areas', {
  id: serial('id').primaryKey(),
  city: text('city').notNull(),
  state: text('state').notNull(),
  pincode: text('pincode'),
  isActive: boolean('is_active').default(true),
});

// Providers
export const providers = pgTable('providers', {
  id: serial('id').primaryKey(),
  userId: text('user_id')
    .references(() => users.uid)
    .notNull()
    .unique(),
  businessName: text('business_name'),
  categories: jsonb('categories').default([]),
  serviceAreas: jsonb('service_areas').default([]),
  city: text('city'),
  pincode: text('pincode'),
  profilePhoto: text('profile_photo'),
  experienceYears: integer('experience_years').default(0),
  kycStatus: text('kyc_status').default('pending'), // pending, under_review, verified, rejected
  kycDocumentType: text('kyc_document_type'),
  kycDocumentNumber: text('kyc_document_number'),
  bankAccountName: text('bank_account_name'),
  bankAccountNumber: text('bank_account_number'),
  bankIfsc: text('bank_ifsc'),
  upiId: text('upi_id'),
  isOnline: boolean('is_online').default(false), // Default offline until verified & toggled
  ratingAverage: numeric('rating_average', { precision: 3, scale: 2 }).default('0.00'),
  totalReviews: integer('total_reviews').default(0),
  totalJobsCompleted: integer('total_jobs_completed').default(0),
  createdAt: timestamp('created_at').defaultNow(),
});

// Provider Working Hours (Monday to Sunday)
export const providerWorkingHours = pgTable('provider_working_hours', {
  id: serial('id').primaryKey(),
  providerId: integer('provider_id').references(() => providers.id).notNull(),
  dayOfWeek: text('day_of_week').notNull(), // 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
  isOpen: boolean('is_open').default(true),
  startTime: text('start_time').default('09:00'),
  endTime: text('end_time').default('19:00'),
});

// Customer Saved Addresses (Home, Work, Other)
export const addresses = pgTable('addresses', {
  id: serial('id').primaryKey(),
  userId: text('user_id').references(() => users.uid).notNull(),
  label: text('label').default('Home'), // 'Home' | 'Work' | 'Other'
  fullAddress: text('full_address').notNull(),
  area: text('area'),
  landmark: text('landmark'),
  city: text('city').notNull(),
  state: text('state').notNull(),
  pincode: text('pincode').notNull(),
  latitude: numeric('latitude', { precision: 10, scale: 7 }),
  longitude: numeric('longitude', { precision: 10, scale: 7 }),
  isDefault: boolean('is_default').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Bookings
export const bookings = pgTable('bookings', {
  id: serial('id').primaryKey(),
  bookingNumber: text('booking_number').notNull().unique(),
  customerId: text('customer_id').references(() => users.uid).notNull(),
  serviceId: integer('service_id').references(() => services.id),
  providerId: integer('provider_id').references(() => providers.id),
  addressId: integer('address_id').references(() => addresses.id),
  status: text('status').notNull().default('requested'),
  scheduledDate: text('scheduled_date').notNull(),
  scheduledTime: text('scheduled_time').notNull(),
  problemDescription: text('problem_description'),
  serviceType: text('service_type').default('standard'),
  serviceDetails: jsonb('service_details').default({}),
  snapshotCustomerTotal: integer('snapshot_customer_total').notNull(),
  snapshotPlatformCommission: integer('snapshot_platform_commission').notNull(),
  snapshotPlatformFee: integer('snapshot_platform_fee').notNull().default(0),
  snapshotProviderAmount: integer('snapshot_provider_amount').notNull(),
  currency: text('currency').default('INR'),
  commissionType: text('commission_type').default('FIXED'),
  commissionValue: numeric('commission_value').default('0'),
  commissionRuleId: text('commission_rule_id'),
  additionalChargeRequested: integer('additional_charge_requested').default(0),
  additionalChargeApproved: boolean('additional_charge_approved').default(false),
  additionalChargeReason: text('additional_charge_reason'),
  paymentStatus: text('payment_status').notNull().default('pending'),
  payoutStatus: text('payout_status').default('pending'),
  paymentMethod: text('payment_method').default('upi'),
  paymentTransactionId: text('payment_transaction_id'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Immutable Financial Snapshots (Phase 3 Section 5)
export const bookingFinancialSnapshots = pgTable('booking_financial_snapshots', {
  id: serial('id').primaryKey(),
  bookingId: integer('booking_id').references(() => bookings.id).notNull(),
  serviceId: integer('service_id').references(() => services.id).notNull(),
  customerTotal: integer('customer_total').notNull(),
  platformFee: integer('platform_fee').notNull().default(0),
  platformCommission: integer('platform_commission').notNull(),
  providerAmount: integer('provider_amount').notNull(),
  currency: text('currency').default('INR'),
  commissionType: text('commission_type').notNull(), // FIXED or PERCENTAGE
  commissionValue: numeric('commission_value').notNull(),
  commissionRuleId: text('commission_rule_id'),
  paymentStatus: text('payment_status').notNull(),
  payoutStatus: text('payout_status').default('pending'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Custom Quotes (Phase 3 Section 9)
export const customQuotes = pgTable('custom_quotes', {
  id: serial('id').primaryKey(),
  bookingId: integer('booking_id').references(() => bookings.id).notNull(),
  providerId: integer('provider_id').references(() => providers.id).notNull(),
  quoteAmount: integer('quote_amount').notNull(),
  platformFee: integer('platform_fee').default(0),
  totalAmount: integer('total_amount').notNull(),
  status: text('status').default('pending_approval'), // pending_approval, approved, rejected
  details: text('details'),
  createdAt: timestamp('created_at').defaultNow(),
  approvedAt: timestamp('approved_at'),
});

// Price Changes & Additional Work Charges (Phase 3 Section 10)
export const priceChanges = pgTable('price_changes', {
  id: serial('id').primaryKey(),
  bookingId: integer('booking_id').references(() => bookings.id).notNull(),
  providerId: integer('provider_id').references(() => providers.id).notNull(),
  originalAmount: integer('original_amount').notNull(),
  additionalAmount: integer('additional_amount').notNull(),
  newTotal: integer('new_total').notNull(),
  reason: text('reason'),
  status: text('status').default('pending'), // pending, approved, rejected
  createdAt: timestamp('created_at').defaultNow(),
  respondedAt: timestamp('responded_at'),
});

// Audit Logs (Phase 3 Section 24)
export const auditLogs = pgTable('audit_logs', {
  id: serial('id').primaryKey(),
  adminId: text('admin_id').references(() => users.uid),
  action: text('action').notNull(),
  entity: text('entity').notNull(),
  entityId: text('entity_id').notNull(),
  oldValue: jsonb('old_value'),
  newValue: jsonb('new_value'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Booking Status History
export const bookingStatusHistory = pgTable('booking_status_history', {
  id: serial('id').primaryKey(),
  bookingId: integer('booking_id').references(() => bookings.id).notNull(),
  status: text('status').notNull(),
  note: text('note'),
  updatedBy: text('updated_by'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Transactions
export const transactions = pgTable('transactions', {
  id: serial('id').primaryKey(),
  bookingId: integer('booking_id').references(() => bookings.id),
  userId: text('user_id').references(() => users.uid),
  amount: integer('amount').notNull(),
  type: text('type').notNull(),
  gateway: text('gateway').default('razorpay'),
  gatewayPaymentId: text('gateway_payment_id'),
  status: text('status').default('success'),
  metadata: jsonb('metadata'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Provider Financial Ledger
export const providerLedger = pgTable('provider_ledger', {
  id: serial('id').primaryKey(),
  providerId: integer('provider_id').references(() => providers.id).notNull(),
  bookingId: integer('booking_id').references(() => bookings.id),
  entryType: text('entry_type').notNull(),
  amount: integer('amount').notNull(),
  balanceAfter: integer('balance_after').notNull(),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Provider Payout Requests
export const payouts = pgTable('payouts', {
  id: serial('id').primaryKey(),
  providerId: integer('provider_id').references(() => providers.id).notNull(),
  amount: integer('amount').notNull(),
  status: text('status').default('pending'),
  bankReference: text('bank_reference'),
  requestedAt: timestamp('requested_at').defaultNow(),
  processedAt: timestamp('processed_at'),
  rejectionReason: text('rejection_reason'),
});

// Jobs & Career
export const jobs = pgTable('jobs', {
  id: serial('id').primaryKey(),
  recruiterId: text('recruiter_id').references(() => users.uid).notNull(),
  title: text('title').notNull(),
  companyName: text('company_name').notNull(),
  category: text('category').notNull(),
  location: text('location').notNull(),
  salaryMin: integer('salary_min'),
  salaryMax: integer('salary_max'),
  experienceMin: integer('experience_min').default(0),
  jobType: text('job_type').default('full_time'),
  workMode: text('work_mode').default('on_site'),
  skillsRequired: jsonb('skills_required').default([]),
  description: text('description').notNull(),
  status: text('status').default('active'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Job Applications
export const jobApplications = pgTable('job_applications', {
  id: serial('id').primaryKey(),
  jobId: integer('job_id').references(() => jobs.id).notNull(),
  candidateId: text('candidate_id').references(() => users.uid).notNull(),
  applicantName: text('applicant_name').notNull(),
  applicantEmail: text('applicant_email').notNull(),
  applicantPhone: text('applicant_phone').notNull(),
  resumeUrl: text('resume_url'),
  status: text('status').default('applied'),
  matchScore: integer('match_score'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Resumes
export const resumes = pgTable('resumes', {
  id: serial('id').primaryKey(),
  userId: text('user_id').references(() => users.uid).notNull(),
  title: text('title').notNull(),
  summary: text('summary'),
  skills: jsonb('skills').default([]),
  experience: jsonb('experience').default([]),
  education: jsonb('education').default([]),
  aiAnalysis: jsonb('ai_analysis'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Reviews and Ratings
export const reviews = pgTable('reviews', {
  id: serial('id').primaryKey(),
  bookingId: integer('booking_id').references(() => bookings.id).notNull(),
  providerId: integer('provider_id').references(() => providers.id).notNull(),
  customerId: text('customer_id').references(() => users.uid).notNull(),
  rating: integer('rating').notNull(),
  comment: text('comment'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Disputes
export const disputes = pgTable('disputes', {
  id: serial('id').primaryKey(),
  bookingId: integer('booking_id').references(() => bookings.id).notNull(),
  raisedBy: text('raised_by').references(() => users.uid).notNull(),
  reason: text('reason').notNull(),
  status: text('status').default('open'),
  resolution: text('resolution'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Support Tickets
export const supportTickets = pgTable('support_tickets', {
  id: serial('id').primaryKey(),
  userId: text('user_id').references(() => users.uid).notNull(),
  subject: text('subject').notNull(),
  message: text('message').notNull(),
  category: text('category').default('general'),
  status: text('status').default('open'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Notifications
export const notifications = pgTable('notifications', {
  id: serial('id').primaryKey(),
  userId: text('user_id').references(() => users.uid).notNull(),
  title: text('title').notNull(),
  message: text('message').notNull(),
  type: text('type').notNull(),
  read: boolean('read').default(false),
  metadata: jsonb('metadata'),
  createdAt: timestamp('created_at').defaultNow(),
});

// In-app Messages
export const messages = pgTable('messages', {
  id: serial('id').primaryKey(),
  bookingId: integer('booking_id').references(() => bookings.id),
  senderId: text('sender_id').references(() => users.uid).notNull(),
  receiverId: text('receiver_id').references(() => users.uid).notNull(),
  content: text('content').notNull(),
  read: boolean('read').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Admin Activity Logs
export const adminActivityLogs = pgTable('admin_activity_logs', {
  id: serial('id').primaryKey(),
  adminId: text('admin_id').references(() => users.uid),
  action: text('action').notNull(),
  targetType: text('target_type').notNull(),
  targetId: text('target_id'),
  details: jsonb('details'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Drizzle Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [users.uid],
    references: [profiles.userId],
  }),
  provider: one(providers, {
    fields: [users.uid],
    references: [providers.userId],
  }),
  languagePreference: one(userLanguagePreferences, {
    fields: [users.uid],
    references: [userLanguagePreferences.userId],
  }),
  addresses: many(addresses),
  bookings: many(bookings),
  notifications: many(notifications),
}));

export const bookingsRelations = relations(bookings, ({ one, many }) => ({
  customer: one(users, {
    fields: [bookings.customerId],
    references: [users.uid],
  }),
  service: one(services, {
    fields: [bookings.serviceId],
    references: [services.id],
  }),
  provider: one(providers, {
    fields: [bookings.providerId],
    references: [providers.id],
  }),
  address: one(addresses, {
    fields: [bookings.addressId],
    references: [addresses.id],
  }),
  statusHistory: many(bookingStatusHistory),
  transactions: many(transactions),
  review: one(reviews, {
    fields: [bookings.id],
    references: [reviews.bookingId],
  }),
}));

export const servicesRelations = relations(services, ({ one, many }) => ({
  category: one(serviceCategories, {
    fields: [services.categoryId],
    references: [serviceCategories.id],
  }),
  bookings: many(bookings),
  translations: many(serviceTranslations),
}));

export const serviceCategoriesRelations = relations(serviceCategories, ({ many }) => ({
  services: many(services),
  translations: many(categoryTranslations),
}));

export const providersRelations = relations(providers, ({ one, many }) => ({
  user: one(users, {
    fields: [providers.userId],
    references: [users.uid],
  }),
  workingHours: many(providerWorkingHours),
  bookings: many(bookings),
  ledger: many(providerLedger),
  payouts: many(payouts),
  reviews: many(reviews),
}));
