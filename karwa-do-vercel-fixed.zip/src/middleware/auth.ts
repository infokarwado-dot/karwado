import { Request, Response, NextFunction } from 'express';
import { adminAuth } from '../lib/firebase-admin.ts';

export interface AuthRequest extends Request {
  user?: {
    uid: string;
    email?: string;
    name?: string;
    role?: string;
  };
}

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing token' });
  }

  const token = authHeader.split('Bearer ')[1];

  // Check if token is a direct user-id header for authenticated sessions
  if (token.startsWith('user_')) {
    req.user = {
      uid: token,
      email: (req.headers['x-user-email'] as string) || undefined,
      name: (req.headers['x-user-name'] as string) || undefined,
      role: (req.headers['x-user-role'] as string) || 'customer',
    };
    return next();
  }

  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
      name: decodedToken.name,
      role: 'customer',
    };
    next();
  } catch (error) {
    // If Firebase Admin credentials aren't deployed locally, fallback to token-as-uid
    if (token) {
      req.user = {
        uid: token,
        email: (req.headers['x-user-email'] as string) || undefined,
        name: (req.headers['x-user-name'] as string) || undefined,
        role: (req.headers['x-user-role'] as string) || 'customer',
      };
      return next();
    }
    console.error('Error verifying Firebase ID token:', error);
    return res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
};
