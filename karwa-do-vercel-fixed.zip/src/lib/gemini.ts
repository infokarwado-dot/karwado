import { GoogleGenAI } from '@google/genai';

// Initialize Gemini client with process.env.GEMINI_API_KEY
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export interface AdditionalQuestion {
  question: string;
  options?: string[];
  default?: string;
}

export interface TaskClassificationResult {
  intent: string;
  category: string;
  categorySlug: string;
  possible_service: string;
  serviceSlug: string;
  confidence: number;
  additional_questions: AdditionalQuestion[];
  urgency: 'low' | 'medium' | 'high' | 'emergency';
  location_required: boolean;
  understoodProblem: string;
  summary: string;
}

export async function classifyTaskWithAI(
  userInput: string,
  availableCategories: { slug: string; name: string }[],
  availableServices: { slug: string; name: string; categorySlug?: string; categoryId?: number }[]
): Promise<TaskClassificationResult> {
  const categoriesList = availableCategories.map((c) => `${c.slug} (${c.name})`).join(', ');
  const servicesList = availableServices.map((s) => `${s.slug} (${s.name})`).join(', ');

  const systemInstruction = `
You are the AI Task Classification Engine for "KARWA DO" (Tagline: “Kaam Koi Bhi Ho. KARWA DO.”), an on-demand service marketplace across India.
Customers describe their needs in natural Hindi, Hinglish, English, or Indian regional languages.
Examples:
- "Meri bike start nahi ho rahi" -> category: bike-car-repair, service: bike-general-inspection, urgency: high, location_required: true, questions: ["Bike model/brand?", "Fuel level ok?"]
- "AC cooling nahi kar rahi" -> category: home-services, service: ac-repair, urgency: medium, location_required: true, questions: ["AC type? (Split / Window)", "Problem duration?"]
- "Rent agreement banana hai" -> category: rent-agreement, service: rent-agreement-digital-draft, urgency: low, location_required: false, questions: ["State of property? (Maharashtra / Delhi / Karnataka / Other)", "Biometric home visit needed?"]
- "Mujhe job chahiye" -> category: jobs-career, service: job-search-application-assistance, urgency: medium, location_required: false, questions: ["Target job role?", "Experience in years?"]
- "Resume banana hai" -> category: jobs-career, service: professional-resume-creation, urgency: medium, location_required: false, questions: ["Fresh graduate or experienced?"]
- "Ghar shifting karni hai" -> category: packers-movers, service: household-shifting-packers-movers, urgency: medium, location_required: true, questions: ["Apartment size? (1BHK / 2BHK / 3BHK)", "Shifting within city or intercity?"]

Given database categories: [${categoriesList}]
And database services: [${servicesList}]

Return a JSON object conforming to:
{
  "intent": "Brief description of the customer's intent",
  "category": "Clean human-readable category name",
  "categorySlug": "exact slug from provided categories",
  "possible_service": "Clean human-readable service name",
  "serviceSlug": "exact slug from provided services",
  "confidence": 0.95,
  "additional_questions": [
    { "question": "Question text", "options": ["Option 1", "Option 2"] }
  ],
  "urgency": "low" | "medium" | "high" | "emergency",
  "location_required": true | false,
  "understoodProblem": "A concise statement of what is needed in clean English",
  "summary": "1-sentence summary of solution"
}
Output valid JSON only without markdown formatting.
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Customer task description: "${userInput}"`,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim() || '{}';
    const parsed = JSON.parse(text);

    // Validate matched category and service against real database catalog
    let matchedCat = availableCategories.find((c) => c.slug === parsed.categorySlug) || availableCategories[0];
    let matchedServ = availableServices.find((s) => s.slug === parsed.serviceSlug) || availableServices[0];

    return {
      intent: parsed.intent || `Request for ${matchedServ?.name || 'Service'}`,
      category: matchedCat?.name || 'General Services',
      categorySlug: matchedCat?.slug || 'home-services',
      possible_service: matchedServ?.name || 'General Service Inspection',
      serviceSlug: matchedServ?.slug || 'ac-repair',
      confidence: typeof parsed.confidence === 'number' ? parsed.confidence : 0.92,
      additional_questions: Array.isArray(parsed.additional_questions) && parsed.additional_questions.length > 0
        ? parsed.additional_questions
        : [{ question: 'Any specific brand or model preferences?' }],
      urgency: parsed.urgency || 'medium',
      location_required: parsed.location_required !== undefined ? Boolean(parsed.location_required) : true,
      understoodProblem: parsed.understoodProblem || userInput,
      summary: parsed.summary || `Recommended service: ${matchedServ?.name || 'Inspection'}`,
    };
  } catch (error) {
    console.error('Gemini task classification fallback:', error);
    const lower = userInput.toLowerCase();
    let catSlug = 'home-services';
    let servSlug = 'ac-repair';
    let urgency: 'low' | 'medium' | 'high' | 'emergency' = 'medium';
    let locReq = true;
    let questions: AdditionalQuestion[] = [];

    if (lower.includes('bike') || lower.includes('car') || lower.includes('puncture') || lower.includes('tow') || lower.includes('battery')) {
      catSlug = 'bike-car-repair';
      if (lower.includes('puncture')) {
        servSlug = 'puncture-repair-doorstep';
        questions = [{ question: 'Vehicle type?', options: ['Two Wheeler', 'Four Wheeler'] }];
      } else if (lower.includes('tow')) {
        servSlug = 'vehicle-towing-service';
        questions = [{ question: 'Towing destination distance?', options: ['Under 5 km', '5 - 15 km', 'Over 15 km'] }];
      } else if (lower.includes('battery')) {
        servSlug = 'battery-jumpstart-service';
      } else if (lower.includes('start nahi') || lower.includes('emergency')) {
        servSlug = 'emergency-roadside-assistance';
        urgency = 'emergency';
        questions = [{ question: 'Are you stranded on a highway or city road?', options: ['City Road', 'Highway / Expressway', 'Home / Parking'] }];
      } else {
        servSlug = 'bike-general-inspection';
        questions = [{ question: 'Bike Brand / Model?', options: ['Honda / Hero', 'Bajaj / TVS', 'Royal Enfield', 'Other'] }];
      }
    } else if (lower.includes('rent') || lower.includes('agreement') || lower.includes('kiraya')) {
      catSlug = 'rent-agreement';
      servSlug = lower.includes('home') || lower.includes('biometric') ? 'rent-agreement-biometric-home' : 'rent-agreement-digital-draft';
      locReq = false;
      questions = [
        { question: 'Property State Jurisdiction?', options: ['Maharashtra', 'Delhi NCR', 'Karnataka', 'Gujarat', 'Tamil Nadu', 'Other'] },
        { question: 'Agreement Tenure?', options: ['11 Months', '22 Months', '33 Months'] }
      ];
    } else if (lower.includes('job') || lower.includes('resume') || lower.includes('career') || lower.includes('naukri')) {
      catSlug = 'jobs-career';
      locReq = false;
      if (lower.includes('resume')) {
        servSlug = 'professional-resume-creation';
        questions = [{ question: 'Current experience level?', options: ['Fresher (0 - 1 yr)', 'Mid Level (2 - 5 yrs)', 'Senior (5+ yrs)'] }];
      } else {
        servSlug = 'job-search-application-assistance';
        questions = [{ question: 'Preferred Job Domain?', options: ['Sales & Marketing', 'Customer Support', 'IT & Software', 'Operations & Logistics', 'Finance / Accounts'] }];
      }
    } else if (lower.includes('clean') || lower.includes('safai')) {
      catSlug = 'cleaning-services';
      servSlug = 'home-deep-cleaning';
      questions = [{ question: 'Apartment Size?', options: ['1 BHK', '2 BHK', '3 BHK', 'Villa / Independent'] }];
    } else if (lower.includes('shift') || lower.includes('pack') || lower.includes('mover')) {
      catSlug = 'packers-movers';
      servSlug = 'household-shifting-packers-movers';
      questions = [{ question: 'Shifting distance?', options: ['Within city', 'Inter-city / Relocation'] }];
    } else if (lower.includes('shop') || lower.includes('online') || lower.includes('dukan') || lower.includes('business')) {
      catSlug = 'business-services';
      servSlug = 'shop-to-online-commerce-setup';
      locReq = false;
      questions = [{ question: 'Business type?', options: ['Retail Grocery / Kirana', 'Apparel / Fashion', 'Restaurant / Food', 'Services / Clinic'] }];
    } else if (lower.includes('doc') || lower.includes('affidavit') || lower.includes('notary')) {
      catSlug = 'document-services';
      servSlug = 'affidavit-notary-drafting';
      locReq = false;
      questions = [{ question: 'Document type?', options: ['General Affidavit', 'Name Change', 'Address Proof', 'Other Notarized Draft'] }];
    } else {
      catSlug = 'home-services';
      servSlug = 'ac-repair';
      questions = [{ question: 'AC Type?', options: ['Split AC', 'Window AC'] }, { question: 'Problem duration?', options: ['Today', 'Past few days', 'More than a week'] }];
    }

    const matchedCat = availableCategories.find((c) => c.slug === catSlug) || availableCategories[0];
    const matchedServ = availableServices.find((s) => s.slug === servSlug) || availableServices[0];

    return {
      intent: `Assistance with ${matchedServ?.name || 'Service'}`,
      category: matchedCat?.name || 'Home Services',
      categorySlug: matchedCat?.slug || 'home-services',
      possible_service: matchedServ?.name || 'AC Repair',
      serviceSlug: matchedServ?.slug || 'ac-repair',
      confidence: 0.9,
      additional_questions: questions,
      urgency,
      location_required: locReq,
      understoodProblem: userInput,
      summary: `Identified ${matchedServ?.name || 'service'} from your description.`,
    };
  }
}

export async function analyzeResumeWithAI(
  resumeText: string,
  targetRole: string = 'General'
): Promise<{ atsScore: number; strengths: string[]; improvements: string[]; suggestions: string }> {
  try {
    const prompt = `
Analyze the following resume for the target job role "${targetRole}".
Provide:
1. ATS Score between 0 and 100
2. Key strengths (list of 3 items)
3. Areas for improvement (list of 3 items)
4. Overall career suggestion (1-2 sentences)

Resume text:
"""
${resumeText.slice(0, 3000)}
"""

Return valid JSON in this format:
{
  "atsScore": 78,
  "strengths": ["...", "...", "..."],
  "improvements": ["...", "...", "..."],
  "suggestions": "..."
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{}');
    return {
      atsScore: parsed.atsScore || 75,
      strengths: parsed.strengths || ['Clear experience summary', 'Direct contact details', 'Relevant background'],
      improvements: parsed.improvements || ['Add measurable achievements', 'Include more role-specific keywords', 'Highlight certifications'],
      suggestions: parsed.suggestions || 'Optimize formatting for ATS parsing and highlight quantified impact in recent projects.',
    };
  } catch (error) {
    console.error('Resume AI analysis fallback:', error);
    return {
      atsScore: 72,
      strengths: ['Relevant background', 'Clear contact information', 'Organized work timeline'],
      improvements: ['Include quantified KPIs', 'Add specific skill certifications', 'Expand project accomplishments'],
      suggestions: 'Add measurable impact numbers and align skills keywords to job descriptions.',
    };
  }
}
