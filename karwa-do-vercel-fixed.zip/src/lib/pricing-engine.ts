/**
 * KARWA DO Secure Backend Pricing Engine
 * (Phase 3 Section 4, 5, 14, 15)
 *
 * All pricing and commission calculations are executed strictly server-side.
 * No prices or commission percentages received from browsers are ever trusted.
 */

export interface PricingInput {
  serviceId?: number;
  customerPrice: number;
  commissionType: 'FIXED' | 'PERCENTAGE' | 'FIXED_AMOUNT' | string;
  commissionValue: number | string;
  platformFee?: number;
}

export interface PricingCalculationResult {
  customerPrice: number;
  platformCommission: number;
  platformFee: number;
  providerAmount: number;
  commissionType: 'FIXED' | 'PERCENTAGE';
  commissionValue: number;
}

/**
 * Validates and computes server-side pricing breakdown
 */
export function calculatePricingEngine({
  customerPrice,
  commissionType,
  commissionValue,
  platformFee = 0,
}: PricingInput): PricingCalculationResult {
  const price = Number(customerPrice);
  const val = Number(commissionValue);
  const fee = Number(platformFee) || 0;

  if (isNaN(price) || price < 0) {
    throw new Error('Customer price must be a valid non-negative number.');
  }

  if (isNaN(val) || val < 0) {
    throw new Error('Platform commission cannot be negative.');
  }

  const isPercentage = String(commissionType).toUpperCase() === 'PERCENTAGE';
  let platformCommission = 0;

  if (isPercentage) {
    if (val > 100) {
      throw new Error('Platform commission percentage cannot exceed 100%.');
    }
    // Percentage formula: Customer Price * (Commission% / 100)
    platformCommission = Math.round(((price * val) / 100) * 100) / 100;
  } else {
    // Fixed amount formula: Direct Commission ₹
    platformCommission = Math.round(val * 100) / 100;
  }

  // Commission cannot exceed customer price
  if (platformCommission > price) {
    throw new Error('Platform commission cannot exceed customer price.');
  }

  // Provider amount = Customer Price - Platform Commission - Platform Fee
  const providerAmount = Math.max(0, Math.round((price - platformCommission - fee) * 100) / 100);

  return {
    customerPrice: price,
    platformCommission,
    platformFee: fee,
    providerAmount,
    commissionType: isPercentage ? 'PERCENTAGE' : 'FIXED',
    commissionValue: val,
  };
}
