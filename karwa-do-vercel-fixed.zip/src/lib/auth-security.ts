import crypto from 'crypto';

export function generateSalt(length = 16): string {
  return crypto.randomBytes(length).toString('hex');
}

export function hashPassword(password: string, salt = generateSalt()): { hash: string; salt: string } {
  const hash = crypto.scryptSync(password, salt, 32).toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, storedHash: string, salt: string): boolean {
  try {
    const computedHash = crypto.scryptSync(password, salt, 32).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(computedHash, 'hex'), Buffer.from(storedHash, 'hex'));
  } catch (e) {
    return false;
  }
}

export function generateSecureOtp(): string {
  // Generate random 6-digit OTP between 100000 and 999999
  const buf = crypto.randomBytes(4);
  const num = buf.readUInt32BE(0) % 900000 + 100000;
  return num.toString();
}

export function hashOtp(otp: string, salt: string): string {
  return crypto.scryptSync(otp, salt, 32).toString('hex');
}

export function verifyOtp(enteredOtp: string, storedHash: string, salt: string): boolean {
  try {
    const computedHash = crypto.scryptSync(enteredOtp, salt, 32).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(computedHash, 'hex'), Buffer.from(storedHash, 'hex'));
  } catch (e) {
    return false;
  }
}

export function generateSecureToken(bytes = 24): string {
  return crypto.randomBytes(bytes).toString('hex');
}

export function hashToken(token: string, salt: string): string {
  return crypto.scryptSync(token, salt, 32).toString('hex');
}

export function verifyToken(token: string, storedHash: string, salt: string): boolean {
  try {
    const computedHash = crypto.scryptSync(token, salt, 32).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(computedHash, 'hex'), Buffer.from(storedHash, 'hex'));
  } catch (e) {
    return false;
  }
}

