import React, { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { Booking } from '../types/index.ts';
import { BookingProgressTracker } from './BookingProgressTracker.tsx';
import {
  CalendarCheck,
  Clock,
  MapPin,
  CheckCircle,
  AlertCircle,
  Star,
  ShieldAlert,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface CustomerBookingsViewProps {
  onOpenExplore: () => void;
  onOpenAuth: () => void;
}

export const CustomerBookingsView: React.FC<CustomerBookingsViewProps> = ({
  onOpenExplore,
  onOpenAuth,
}) => {
  const { t } = useLanguage();
  const { user } = useAuth();

  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewBookingId, setReviewBookingId] = useState<number | null>(null);
  const [ratingVal, setRatingVal] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [disputeBookingId, setDisputeBookingId] = useState<number | null>(null);
  const [disputeReason, setDisputeReason] = useState('');

  useEffect(() => {
    if (user?.uid) {
      fetchBookings();
    } else {
      setLoading(false);
    }
  }, [user]);

  // Periodic polling for active bookings to keep real-time progress synced
  useEffect(() => {
    if (!user?.uid) return;

    const hasActiveBooking = bookings.some((b) => {
      const status = b.booking?.status;
      return (
        status &&
        status !== 'completed' &&
        status !== 'cancelled' &&
        status !== 'disputed'
      );
    });

    if (!hasActiveBooking) return;

    const interval = setInterval(() => {
      fetchBookings(true);
    }, 10000);

    return () => clearInterval(interval);
  }, [user, bookings]);

  const fetchBookings = async (silent = false) => {
    if (!user) return;
    try {
      if (!silent) setLoading(true);
      const res = await fetch('/api/bookings', {
        headers: {
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
      });
      if (res.ok) {
        const data = await res.json();
        setBookings(data);
      }
    } catch (err) {
      console.error('Error fetching bookings:', err);
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const handleApproveExtraCharge = async (bookingId: number, approved: boolean) => {
    if (!user) return;
    try {
      const res = await fetch(`/api/bookings/${bookingId}/approve-charge`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({ approved }),
      });
      if (res.ok) fetchBookings();
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubmitReview = async (bookingId: number) => {
    if (!user) return;
    try {
      const res = await fetch(`/api/bookings/${bookingId}/review`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({ rating: ratingVal, comment: reviewComment }),
      });
      if (res.ok) {
        setReviewBookingId(null);
        setReviewComment('');
        fetchBookings();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubmitDispute = async (bookingId: number) => {
    if (!user || !disputeReason) return;
    try {
      const res = await fetch('/api/support/dispute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({ bookingId, reason: disputeReason }),
      });
      if (res.ok) {
        setDisputeBookingId(null);
        setDisputeReason('');
        fetchBookings();
      }
    } catch (e) {
      console.error(e);
    }
  };

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto py-16 px-4 text-center">
        <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
          <CalendarCheck className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-bold text-slate-900 mb-2">Track Your Bookings</h3>
        <p className="text-xs text-slate-500 mb-6">
          Sign in to view your scheduled services, status updates, and transparent invoices.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition"
        >
          {t('login')}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            {t('bookings')}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time status updates and immutable financial snapshots.
          </p>
        </div>
        <button
          onClick={onOpenExplore}
          className="px-4 py-2 rounded-xl bg-blue-50 text-blue-700 font-bold text-xs hover:bg-blue-100 transition"
        >
          + Book Another Service
        </button>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <div key={i} className="h-40 bg-slate-100 rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : bookings.length === 0 ? (
        /* Truthful Empty State (Section 20: NO DEMO DATA) */
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center max-w-lg mx-auto shadow-sm">
          <div className="w-16 h-16 rounded-3xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-4">
            <CalendarCheck className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 mb-1">{t('noBookingsYet')}</h3>
          <p className="text-xs text-slate-500 mb-6">
            You haven't requested any tasks yet. Describe your problem on the home screen or choose from popular services.
          </p>
          <button
            onClick={onOpenExplore}
            className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition"
          >
            {t('bookNow')}
          </button>
        </div>
      ) : (
        <div className="space-y-5">
          {bookings.map((item) => {
            const b = item.booking;
            const s = item.service;
            const a = item.address;

            const isExtraRequested = b.additionalChargeRequested > 0 && !b.additionalChargeApproved;

            return (
              <div
                key={b.id}
                className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-5 sm:p-6 space-y-4 hover:border-slate-300 transition"
              >
                {/* Top Row: Booking Number & Status Badge */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Booking ID
                    </span>
                    <span className="text-sm font-extrabold text-slate-900 font-mono">
                      #{b.bookingNumber}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold capitalize ${
                        b.status === 'completed'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : b.status === 'cancelled'
                          ? 'bg-red-50 text-red-700 border border-red-200'
                          : b.status === 'disputed'
                          ? 'bg-purple-50 text-purple-700 border border-purple-200'
                          : 'bg-blue-50 text-blue-700 border border-blue-200'
                      }`}
                    >
                      {b.status.replace(/_/g, ' ')}
                    </span>

                    <span
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                        b.paymentStatus === 'paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      Payment: {b.paymentStatus}
                    </span>
                  </div>
                </div>

                {/* Service Details & Schedule */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400 block font-semibold text-[11px] mb-0.5">Service</span>
                    <span className="font-extrabold text-slate-900 text-sm block">{s?.name || 'Custom Service'}</span>
                    <span className="text-slate-500 mt-1 block line-clamp-1">{b.problemDescription}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block font-semibold text-[11px] mb-0.5">Scheduled</span>
                    <div className="flex items-center gap-1.5 font-bold text-slate-800">
                      <Clock className="w-3.5 h-3.5 text-blue-600" />
                      <span>{b.scheduledDate} ({b.scheduledTime})</span>
                    </div>
                    {a && (
                      <div className="flex items-center gap-1.5 text-slate-500 mt-1">
                        <MapPin className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{a.fullAddress}, {a.city}</span>
                      </div>
                    )}
                  </div>

                  {/* Financial Snapshot */}
                  <div className="bg-slate-50 rounded-2xl p-3 border border-slate-100 text-[11px]">
                    <div className="flex justify-between text-slate-500 mb-1">
                      <span>Customer Price:</span>
                      <span className="font-bold text-slate-900">₹{b.snapshotCustomerTotal}</span>
                    </div>
                    <div className="flex justify-between text-slate-500 mb-1">
                      <span>KARWA DO Fee:</span>
                      <span className="text-amber-700">₹{b.snapshotPlatformCommission}</span>
                    </div>
                    <div className="flex justify-between text-slate-500 border-t border-slate-200/60 pt-1 font-bold text-slate-800">
                      <span>Provider Amount:</span>
                      <span className="text-emerald-700">₹{b.snapshotProviderAmount}</span>
                    </div>
                  </div>
                </div>

                {/* Visual Progress Tracker (Dynamic Timeline & Real-Time Simulation) */}
                <BookingProgressTracker
                  booking={b}
                  service={s}
                  address={a}
                  onStatusUpdated={fetchBookings}
                />

                {/* Extra Charge Approval Banner (Phase 3 Section 10: Price Change) */}
                {isExtraRequested && (
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 text-xs text-amber-950 space-y-3">
                    <div className="flex items-start gap-2.5">
                      <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-extrabold text-sm block text-amber-950">
                          Price Change Request (Additional Work / Parts)
                        </span>
                        <p className="text-amber-800 text-xs mt-0.5">
                          Reason: {b.additionalChargeReason || 'Additional work / spare parts required'}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 bg-white/80 p-3 rounded-xl border border-amber-200 text-center">
                      <div>
                        <span className="text-[10px] font-bold text-slate-500 uppercase block">Original Amount</span>
                        <span className="text-sm font-black text-slate-900 block mt-0.5">₹{b.snapshotCustomerTotal}</span>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-amber-700 uppercase block">+ Additional Amount</span>
                        <span className="text-sm font-black text-amber-700 block mt-0.5">₹{b.additionalChargeRequested}</span>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-blue-700 uppercase block">New Total</span>
                        <span className="text-sm font-black text-blue-900 block mt-0.5">
                          ₹{b.snapshotCustomerTotal + (b.additionalChargeRequested || 0)}
                        </span>
                      </div>
                    </div>

                    <div className="flex justify-end items-center gap-2 pt-1">
                      <button
                        onClick={() => handleApproveExtraCharge(b.id, false)}
                        className="px-4 py-2 rounded-xl border border-red-200 bg-white text-red-700 font-bold hover:bg-red-50 text-xs transition cursor-pointer"
                      >
                        Reject
                      </button>
                      <button
                        onClick={() => handleApproveExtraCharge(b.id, true)}
                        className="px-5 py-2 rounded-xl bg-amber-600 text-white font-bold hover:bg-amber-700 shadow-sm text-xs transition cursor-pointer"
                      >
                        Approve ₹{b.additionalChargeRequested}
                      </button>
                    </div>
                  </div>
                )}

                {/* Bottom Actions: Review & Dispute */}
                <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex gap-2">
                    {b.status === 'completed' && (
                      <button
                        onClick={() => setReviewBookingId(reviewBookingId === b.id ? null : b.id)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 text-amber-800 hover:bg-amber-100 font-bold transition"
                      >
                        <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                        <span>Rate & Review</span>
                      </button>
                    )}

                    <button
                      onClick={() => setDisputeBookingId(disputeBookingId === b.id ? null : b.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-slate-500 hover:text-red-600 hover:bg-slate-50 font-semibold transition"
                    >
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>{t('raiseDispute')}</span>
                    </button>
                  </div>

                  <span className="text-[11px] text-slate-400">
                    Created: {new Date(b.createdAt).toLocaleDateString()}
                  </span>
                </div>

                {/* Inline Review Drawer */}
                {reviewBookingId === b.id && (
                  <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200 text-xs space-y-3">
                    <span className="font-bold text-slate-900 block">Rate Provider Service</span>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRatingVal(star)}
                          className="p-1 hover:scale-110 transition"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              star <= ratingVal
                                ? 'fill-amber-400 text-amber-400'
                                : 'text-slate-300'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                    <textarea
                      placeholder="Share your experience (punctuality, workmanship, transparency)..."
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setReviewBookingId(null)}
                        className="px-3 py-1.5 text-slate-500 font-bold"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSubmitReview(b.id)}
                        className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold"
                      >
                        Submit Rating
                      </button>
                    </div>
                  </div>
                )}

                {/* Inline Dispute Drawer */}
                {disputeBookingId === b.id && (
                  <div className="p-4 rounded-2xl bg-red-50/50 border border-red-200 text-xs space-y-3">
                    <span className="font-bold text-red-900 block">Report Issue / Raise Dispute</span>
                    <textarea
                      placeholder="Describe what went wrong. Our Trust & Safety team will review immediately..."
                      value={disputeReason}
                      onChange={(e) => setDisputeReason(e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-red-300 bg-white"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setDisputeBookingId(null)}
                        className="px-3 py-1.5 text-slate-500 font-bold"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSubmitDispute(b.id)}
                        className="px-4 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold"
                      >
                        Submit Dispute
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
