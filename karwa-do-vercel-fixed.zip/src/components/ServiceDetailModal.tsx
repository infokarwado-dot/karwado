import React from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { Service } from '../types/index.ts';
import {
  X,
  Clock,
  MapPin,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  HelpCircle,
  FileText,
  ArrowRight,
  ChevronDown,
} from 'lucide-react';

interface ServiceDetailModalProps {
  service: Service;
  onClose: () => void;
  onBook: (service: Service) => void;
}

export const ServiceDetailModal: React.FC<ServiceDetailModalProps> = ({
  service,
  onClose,
  onBook,
}) => {
  const { t } = useLanguage();
  const isCustomQuote =
    service.pricingType === 'CUSTOM_QUOTE' ||
    service.pricingType === 'quote' ||
    (service as any).pricing_type === 'CUSTOM_QUOTE';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white p-6 sm:p-8 flex items-start justify-between">
          <div className="space-y-1">
            <span className="inline-block px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-400/30 uppercase tracking-wider">
              {service.categoryName || 'Verified Service'}
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-white">{service.name}</h2>
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 pt-1">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <span>Duration: {service.estimatedDuration || '60 mins'}</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                <span>Area: {service.serviceArea || 'Pan-City (Doorstep)'}</span>
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* Price Banner */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                {isCustomQuote ? 'Pricing Model' : 'Customer Price'}
              </span>
              {isCustomQuote ? (
                <div className="text-sm font-bold text-slate-800 mt-0.5">
                  Price will be confirmed after provider inspection.
                </div>
              ) : (
                <div className="flex items-baseline gap-2 mt-0.5">
                  <span className="text-3xl font-black text-slate-950">₹{service.customerPrice}</span>
                  {service.pricingType === 'STARTING_FROM' && (
                    <span className="text-xs text-slate-500 font-semibold">(Starting price)</span>
                  )}
                  {service.minPrice && service.maxPrice && (
                    <span className="text-xs text-slate-500">
                      (Range: ₹{service.minPrice} - ₹{service.maxPrice})
                    </span>
                  )}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-semibold">KARWA DO 30-Day Guarantee</span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              About This Service
            </h4>
            <p className="text-sm text-slate-700 leading-relaxed">
              {service.description ||
                'Professional on-demand service delivered by verified, background-checked specialists.'}
            </p>
          </div>

          {/* What's Included */}
          {service.whatsIncluded && service.whatsIncluded.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
                What's Included
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {service.whatsIncluded.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-2 p-2.5 rounded-xl bg-blue-50/50 border border-blue-100 text-xs text-slate-800 font-medium"
                  >
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Requirements & Customer Instructions */}
          {((service.requirements && service.requirements.length > 0) ||
            service.customerInstructions) && (
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-xs text-amber-950 space-y-2">
              <div className="flex items-center gap-1.5 font-bold uppercase text-[11px] tracking-wider text-amber-900">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span>Important Instructions & Requirements</span>
              </div>
              {service.customerInstructions && (
                <p className="text-slate-700">{service.customerInstructions}</p>
              )}
              {service.requirements && service.requirements.length > 0 && (
                <ul className="list-disc list-inside space-y-1 text-slate-700 pt-1">
                  {service.requirements.map((req, i) => (
                    <li key={i}>{req}</li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {/* Cancellation Policy */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1 text-slate-600">
            <span className="font-bold text-slate-900 uppercase text-[11px] tracking-wider block">
              Cancellation Policy
            </span>
            <p>
              {service.cancellationPolicy ||
                'Free cancellation up to 2 hours before the scheduled time slot. Nominal fee applies if provider is already en route.'}
            </p>
          </div>

          {/* FAQ */}
          {service.faq && service.faq.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5 flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-slate-500" />
                <span>Frequently Asked Questions</span>
              </h4>
              <div className="space-y-2">
                {service.faq.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl border border-slate-200 bg-white text-xs space-y-1"
                  >
                    <p className="font-bold text-slate-900">{item.question || (item as any).q}</p>
                    <p className="text-slate-600">{item.answer || (item as any).a}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer CTA (Phase 3 Section 17) */}
        <div className="p-5 sm:p-6 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-4">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">
              {isCustomQuote ? 'Estimated Pricing' : 'Total Amount'}
            </span>
            <span className="text-xl font-black text-slate-900">
              {isCustomQuote ? 'Quote upon inspection' : `₹${service.customerPrice}`}
            </span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-slate-600 hover:bg-slate-200 text-xs font-bold transition cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onBook(service);
              }}
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-md transition flex items-center gap-2 cursor-pointer"
            >
              <span>{isCustomQuote ? 'Get a Quote' : 'Book Now'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
