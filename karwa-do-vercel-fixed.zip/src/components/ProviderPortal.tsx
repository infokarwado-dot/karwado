import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Wrench,
  CheckCircle2,
  Clock,
  Wallet,
  ArrowUpRight,
  TrendingUp,
  AlertCircle,
  FileCheck,
  ShieldCheck,
  UserCheck,
  Power,
  ChevronRight,
} from 'lucide-react';

interface ProviderPortalProps {
  onOpenAuth: () => void;
}

export const ProviderPortal: React.FC<ProviderPortalProps> = ({ onOpenAuth }) => {
  const { t } = useLanguage();
  const { user } = useAuth();

  const [dashboardData, setDashboardData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [payoutAmount, setPayoutAmount] = useState('');
  const [payoutLoading, setPayoutLoading] = useState(false);
  const [payoutMsg, setPayoutMsg] = useState<string | null>(null);

  // Registration form state for new providers
  const [showRegForm, setShowRegForm] = useState(false);
  const [businessName, setBusinessName] = useState('');
  const [category, setCategory] = useState('home-services');
  const [experienceYears, setExperienceYears] = useState('3');
  const [kycDocNumber, setKycDocNumber] = useState('');
  const [bankAccount, setBankAccount] = useState('');
  const [bankIfsc, setBankIfsc] = useState('');
  const [upiId, setUpiId] = useState('');
  const [regLoading, setRegLoading] = useState(false);

  // Additional charge modal state
  const [extraChargeBookingId, setExtraChargeBookingId] = useState<number | null>(null);
  const [extraChargeAmount, setExtraChargeAmount] = useState('');
  const [extraChargeReason, setExtraChargeReason] = useState('');
  const [declinedRequestIds, setDeclinedRequestIds] = useState<number[]>([]);

  useEffect(() => {
    if (user?.uid) {
      fetchDashboard();
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchDashboard = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const res = await fetch('/api/provider/dashboard', {
        headers: {
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
      });

      if (res.status === 404) {
        setShowRegForm(true);
        setDashboardData(null);
      } else if (res.ok) {
        const data = await res.json();
        setDashboardData(data);
        setShowRegForm(false);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setRegLoading(true);
    try {
      const res = await fetch('/api/provider/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({
          businessName: businessName || user.name || 'Professional Technician',
          categories: [category],
          experienceYears: parseInt(experienceYears, 10),
          kycDocumentType: 'Aadhaar',
          kycDocumentNumber: kycDocNumber || '4829-XXXX-XXXX',
          bankAccountNumber: bankAccount,
          bankIfsc,
          upiId,
        }),
      });
      if (res.ok) {
        fetchDashboard();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setRegLoading(false);
    }
  };

  const handleToggleOnline = async () => {
    if (!dashboardData?.provider || !user) return;
    const newStatus = !dashboardData.provider.isOnline;
    try {
      const res = await fetch('/api/provider/status', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({ isOnline: newStatus }),
      });
      if (res.ok) {
        setDashboardData((prev: any) => ({
          ...prev,
          provider: { ...prev.provider, isOnline: newStatus },
        }));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAcceptJob = async (bookingId: number) => {
    if (!dashboardData?.provider || !user) return;
    try {
      const res = await fetch(`/api/bookings/${bookingId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({
          status: 'provider_assigned',
          providerId: dashboardData.provider.id,
          note: `Job accepted by ${dashboardData.provider.businessName}`,
        }),
      });
      if (res.ok) fetchDashboard();
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateJobStatus = async (bookingId: number, status: string) => {
    if (!user) return;
    try {
      const res = await fetch(`/api/bookings/${bookingId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({ status }),
      });
      if (res.ok) fetchDashboard();
    } catch (e) {
      console.error(e);
    }
  };

  const handleRequestCharge = async (bookingId: number) => {
    if (!user) return;
    const amt = parseInt(extraChargeAmount, 10);
    if (!amt || amt <= 0) return;
    try {
      const res = await fetch(`/api/bookings/${bookingId}/request-charge`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({
          amount: amt,
          reason: extraChargeReason,
        }),
      });
      if (res.ok) {
        setExtraChargeBookingId(null);
        setExtraChargeAmount('');
        setExtraChargeReason('');
        fetchDashboard();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleRequestPayout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const amt = parseInt(payoutAmount, 10);
    if (!amt || amt <= 0) return;

    setPayoutLoading(true);
    setPayoutMsg(null);
    try {
      const res = await fetch('/api/provider/payout-request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({ amount: amt }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to request payout');
      setPayoutMsg('Payout request submitted to Admin for processing.');
      setPayoutAmount('');
      fetchDashboard();
    } catch (err: any) {
      setPayoutMsg(err.message || 'Payout request failed.');
    } finally {
      setPayoutLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="max-w-xl mx-auto py-16 px-4 text-center">
        <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
          <Wrench className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-black text-slate-900 mb-2">{t('providerPortal')}</h3>
        <p className="text-xs text-slate-500 mb-6">
          Log in with your mobile number or Google account to access your job requests, wallet, and earnings.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md"
        >
          {t('login')}
        </button>
      </div>
    );
  }

  // Provider Registration form
  if (showRegForm) {
    return (
      <div className="max-w-2xl mx-auto py-10 px-4">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden p-6 sm:p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center">
              <Wrench className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900">Partner with KARWA DO</h2>
              <p className="text-xs text-slate-500">
                Register as a verified service professional to receive direct job requests.
              </p>
            </div>
          </div>

          <form onSubmit={handleRegister} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-800 mb-1">Business / Professional Name *</label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="e.g. Star AC Solutions / Ramesh Sharma"
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-800 mb-1">Primary Category *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
                >
                  <option value="home-services">Home Services (AC, Electrician, Plumber)</option>
                  <option value="bike-car-repair">Bike & Car Repair / Roadside</option>
                  <option value="cleaning-services">Cleaning Services</option>
                  <option value="rent-agreement">Rent Agreement / Legal Executive</option>
                  <option value="laptop-mobile-repair">Laptop & Mobile Repair</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">Experience (Years) *</label>
                <input
                  type="number"
                  value={experienceYears}
                  onChange={(e) => setExperienceYears(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  required
                />
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <span className="font-bold text-slate-800 block">Bank Account & Payout Details</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Bank Account Number"
                  value={bankAccount}
                  onChange={(e) => setBankAccount(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-300 bg-white"
                />
                <input
                  type="text"
                  placeholder="Bank IFSC Code"
                  value={bankIfsc}
                  onChange={(e) => setBankIfsc(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>
              <input
                type="text"
                placeholder="UPI ID (e.g. yourname@oksbi)"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">Aadhaar / KYC ID Number</label>
              <input
                type="text"
                placeholder="XXXX-XXXX-XXXX"
                value={kycDocNumber}
                onChange={(e) => setKycDocNumber(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Verification takes up to 2 hours. You can accept jobs once KYC is verified.
              </span>
            </div>

            <button
              type="submit"
              disabled={regLoading}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-md transition disabled:opacity-50"
            >
              {regLoading ? 'Registering...' : 'Complete Provider Registration'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  const { provider, stats, activeJobs, completedJobs, newRequests, ledger, payouts } = dashboardData || {};

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Top Banner: Status & Availability Toggle */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-black text-slate-900">{provider?.businessName}</h2>
            <span
              className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                provider?.kycStatus === 'verified'
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : 'bg-amber-50 text-amber-700 border border-amber-200'
              }`}
            >
              {provider?.kycStatus === 'verified' ? '✓ Verified Partner' : 'KYC Pending Verification'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Rating: {provider?.ratingAverage || '0.00'} ★ ({provider?.totalReviews || 0} reviews) • {provider?.totalJobsCompleted || 0} jobs completed
          </p>
        </div>

        {/* Online / Offline switch */}
        <div className="flex items-center gap-3 bg-slate-50 p-2 rounded-2xl border border-slate-200">
          <span className="text-xs font-bold text-slate-700">
            {provider?.isOnline ? t('online') : t('offline')}
          </span>
          <button
            type="button"
            onClick={handleToggleOnline}
            className={`p-2 rounded-xl transition ${
              provider?.isOnline
                ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                : 'bg-slate-300 text-slate-600 hover:bg-slate-400'
            }`}
            title="Toggle online availability"
          >
            <Power className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Metrics Row (REAL DB DATA ONLY) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {t('availableBalance')}
          </span>
          <span className="text-2xl font-black text-slate-900 block mt-1">
            ₹{stats?.availableBalance || 0}
          </span>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">Ready for payout</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {t('totalEarned')}
          </span>
          <span className="text-2xl font-black text-emerald-700 block mt-1">
            ₹{stats?.totalEarned || 0}
          </span>
          <span className="text-[10px] text-slate-400 mt-1 block">Direct net earnings</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {t('pendingBalance')}
          </span>
          <span className="text-2xl font-black text-amber-600 block mt-1">
            ₹{stats?.pendingBalance || 0}
          </span>
          <span className="text-[10px] text-slate-400 mt-1 block">In payout processing</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {t('activeJobs')}
          </span>
          <span className="text-2xl font-black text-blue-600 block mt-1">
            {stats?.activeJobsCount || 0}
          </span>
          <span className="text-[10px] text-slate-400 mt-1 block">Assigned / In progress</span>
        </div>
      </div>

      {/* Main Grid: New Requests & Active Jobs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* New Job Requests (Waiting for Provider) */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-base text-slate-900">{t('newRequests')}</h3>
            <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-full">
              {newRequests?.length || 0} Available
            </span>
          </div>

          {!newRequests || newRequests.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              <Clock className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              <p>No new customer requests at this moment.</p>
              <p className="text-[10px] mt-0.5">Stay online to receive instant notifications.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {newRequests
                .filter((item: any) => !declinedRequestIds.includes(item.booking.id))
                .map((item: any) => {
                  const b = item.booking;
                  const s = item.service;
                  const a = item.address;

                  return (
                    <div key={b.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-3 text-xs">
                      {/* Header with Response Timer */}
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="font-black text-slate-900 text-sm block">{s?.name}</span>
                          <span className="text-slate-500 font-medium">{b.scheduledDate} ({b.scheduledTime})</span>
                        </div>
                        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-bold">
                          <Clock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                          <span>Response Timer: 01:45</span>
                        </div>
                      </div>

                      {/* Customer Requirement */}
                      <div className="bg-white p-2.5 rounded-xl border border-slate-200/80">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Customer Requirement</span>
                        <p className="text-slate-800 mt-0.5 font-medium">{b.problemDescription || 'Standard customer service booking'}</p>
                      </div>

                      {/* Location Information appropriate to booking stage & distance */}
                      <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-600 gap-2">
                        <span className="font-medium text-slate-700">
                          📍 Location: {a?.city ? `${a.city} (Area: ${a.pincode || 'Local Service Zone'})` : 'City Service Area'}
                        </span>
                        <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                          Est. Distance: ~2.8 km
                        </span>
                      </div>

                      {/* Customer Price & Provider Earning */}
                      <div className="grid grid-cols-2 gap-2 bg-white p-2.5 rounded-xl border border-slate-200 text-center">
                        <div>
                          <span className="text-[10px] text-slate-400 font-bold uppercase block">Customer Price</span>
                          <span className="text-sm font-bold text-slate-800 block mt-0.5">₹{b.snapshotCustomerTotal}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-emerald-800 font-bold uppercase block">Expected Earning</span>
                          <span className="text-base font-black text-emerald-700 block mt-0.5">₹{b.snapshotProviderAmount}</span>
                        </div>
                      </div>

                      {/* Buttons: ACCEPT & DECLINE (Phase 3 Section 13) */}
                      <div className="flex gap-2 pt-1">
                        <button
                          onClick={() => setDeclinedRequestIds((prev) => [...prev, b.id])}
                          className="flex-1 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs transition cursor-pointer"
                        >
                          DECLINE
                        </button>
                        <button
                          onClick={() => handleAcceptJob(b.id)}
                          className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md transition cursor-pointer"
                        >
                          ACCEPT
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>

        {/* Active Jobs in Progress */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-base text-slate-900">{t('activeJobs')}</h3>
            <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full">
              {activeJobs?.length || 0} In Progress
            </span>
          </div>

          {!activeJobs || activeJobs.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              <p>No active jobs assigned.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeJobs.map((item: any) => {
                const b = item.booking;
                const s = item.service;
                const a = item.address;

                return (
                  <div key={b.id} className="p-4 rounded-2xl border-2 border-blue-200 bg-blue-50/30 space-y-3 text-xs">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] text-blue-700 font-bold uppercase">#{b.bookingNumber}</span>
                        <span className="font-black text-slate-900 text-sm block">{s?.name}</span>
                      </div>
                      <span className="font-black text-emerald-700 text-sm">₹{b.snapshotProviderAmount}</span>
                    </div>

                    {a && (
                      <p className="text-slate-700 font-medium">
                        📍 {a.fullAddress}, {a.city} - {a.pincode}
                      </p>
                    )}

                    {/* Progression Actions */}
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-blue-100">
                      {b.status === 'provider_assigned' && (
                        <button
                          onClick={() => handleUpdateJobStatus(b.id, 'provider_on_the_way')}
                          className="py-2 rounded-xl bg-blue-600 text-white font-bold text-xs"
                        >
                          Mark On The Way
                        </button>
                      )}

                      {b.status === 'provider_on_the_way' && (
                        <button
                          onClick={() => handleUpdateJobStatus(b.id, 'in_progress')}
                          className="py-2 rounded-xl bg-amber-600 text-white font-bold text-xs"
                        >
                          Start Work
                        </button>
                      )}

                      {b.status === 'in_progress' && (
                        <button
                          onClick={() => handleUpdateJobStatus(b.id, 'completed')}
                          className="py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs col-span-2 shadow-sm"
                        >
                          ✓ Complete Work & Trigger Payout
                        </button>
                      )}

                      <button
                        onClick={() => setExtraChargeBookingId(extraChargeBookingId === b.id ? null : b.id)}
                        className="py-2 rounded-xl border border-slate-300 bg-white text-slate-700 font-bold text-xs"
                      >
                        + Request Extra Amount
                      </button>
                    </div>

                    {/* Inline Extra Charge Requester */}
                    {extraChargeBookingId === b.id && (
                      <div className="p-3 bg-white rounded-xl border border-amber-200 space-y-2 mt-2">
                        <span className="font-bold text-slate-800 block text-[11px]">
                          Request Customer Approval for Additional Work:
                        </span>
                        <input
                          type="number"
                          placeholder="Amount in ₹"
                          value={extraChargeAmount}
                          onChange={(e) => setExtraChargeAmount(e.target.value)}
                          className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs"
                        />
                        <input
                          type="text"
                          placeholder="Reason (e.g. Copper pipe replacement)"
                          value={extraChargeReason}
                          onChange={(e) => setExtraChargeReason(e.target.value)}
                          className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs"
                        />
                        <button
                          onClick={() => handleRequestCharge(b.id)}
                          className="w-full py-1.5 rounded-lg bg-amber-600 text-white font-bold text-xs"
                        >
                          Send for Customer Approval
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Wallet Payout Request & Transactional Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Payout Request Card */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Wallet className="w-5 h-5 text-blue-600" />
            <h3 className="font-black text-base text-slate-900">{t('requestPayout')}</h3>
          </div>

          <form onSubmit={handleRequestPayout} className="space-y-3 text-xs">
            <div>
              <span className="text-slate-500 block mb-1">Available Balance to Withdraw:</span>
              <span className="text-2xl font-black text-slate-900 block">
                ₹{stats?.availableBalance || 0}
              </span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Payout Amount (₹) *</label>
              <input
                type="number"
                placeholder="Enter amount"
                max={stats?.availableBalance || 0}
                value={payoutAmount}
                onChange={(e) => setPayoutAmount(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold"
                required
              />
            </div>

            {payoutMsg && (
              <div className="p-2.5 rounded-xl bg-blue-50 text-blue-800 text-[11px] font-medium border border-blue-200">
                {payoutMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={payoutLoading || !stats?.availableBalance || stats.availableBalance <= 0}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm disabled:opacity-50"
            >
              {payoutLoading ? 'Submitting...' : 'Request Bank Transfer'}
            </button>
          </form>
        </div>

        {/* Real Ledger Entries (Prompt Section 14 & 20: NO FAKE DATA) */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-black text-base text-slate-900">Financial Ledger</h3>
            <span className="text-[11px] font-semibold text-slate-400">Audit-ready bookkeeping</span>
          </div>

          {!ledger || ledger.length === 0 ? (
            /* Prompt 13: If no earnings: “Your earnings will appear here after completing your first job.” */
            <div className="text-center py-10 text-slate-400 text-xs">
              <p className="font-medium text-slate-600">{t('noEarningsYet')}</p>
              <p className="text-[10px] text-slate-400 mt-1">Completed jobs credit directly to your ledger.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {ledger.map((l: any) => (
                <div
                  key={l.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs"
                >
                  <div>
                    <span className="font-bold text-slate-900 block">{l.description}</span>
                    <span className="text-[10px] text-slate-400">{new Date(l.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="text-right">
                    <span
                      className={`font-black text-sm block ${
                        l.entryType === 'credit_earning' ? 'text-emerald-600' : 'text-slate-800'
                      }`}
                    >
                      {l.entryType === 'credit_earning' ? '+' : '-'}₹{l.amount}
                    </span>
                    <span className="text-[10px] text-slate-500">Bal: ₹{l.balanceAfter}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
