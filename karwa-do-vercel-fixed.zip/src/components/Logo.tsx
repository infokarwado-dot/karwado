import React from 'react';

export interface LogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'full' | 'compact' | 'mark-only';
  inverted?: boolean;
  className?: string;
  showTagline?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  variant = 'compact',
  inverted = false,
  className = '',
  showTagline = true,
}) => {
  // Dimensions based on size
  const iconDimensions = {
    xs: { w: 26, h: 26 },
    sm: { w: 34, h: 34 },
    md: { w: 42, h: 42 },
    lg: { w: 56, h: 56 },
    xl: { w: 84, h: 84 },
  }[size];

  const textSize = {
    xs: 'text-sm',
    sm: 'text-base',
    md: 'text-xl sm:text-2xl',
    lg: 'text-2xl sm:text-3xl',
    xl: 'text-4xl sm:text-5xl',
  }[size];

  const taglineSize = {
    xs: 'text-[8px]',
    sm: 'text-[9px]',
    md: 'text-[10px] sm:text-[11px]',
    lg: 'text-xs',
    xl: 'text-sm',
  }[size];

  return (
    <div className={`inline-flex items-center gap-2.5 sm:gap-3 group select-none ${className}`}>
      {/* 1. EMBLEM: The Iconic 3D 'K' with Lightning Bolt, House Cutout, & Running Technician */}
      <div
        style={{ width: iconDimensions.w, height: iconDimensions.h }}
        className="relative shrink-0 flex items-center justify-center transition-transform duration-300 group-hover:scale-105"
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full drop-shadow-sm"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="logo-orange-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffb732" />
              <stop offset="50%" stopColor="#ff7a00" />
              <stop offset="100%" stopColor="#e05300" />
            </linearGradient>

            <linearGradient id="logo-blue-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e5296" />
              <stop offset="60%" stopColor="#0c2f64" />
              <stop offset="100%" stopColor="#071b3b" />
            </linearGradient>

            <linearGradient id="logo-bolt-grad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ffd54f" />
              <stop offset="100%" stopColor="#ff8f00" />
            </linearGradient>
          </defs>

          {/* Left Vertical Stem of 'K' (Glossy Orange Pill) */}
          <rect
            x="14"
            y="10"
            width="20"
            height="80"
            rx="8"
            fill="url(#logo-orange-grad)"
          />
          {/* Stem Highlight */}
          <line
            x1="18"
            y1="16"
            x2="18"
            y2="55"
            stroke="#ffffff"
            strokeWidth="2.5"
            strokeLinecap="round"
            opacity="0.5"
          />

          {/* Upper Right Diagonal Arm of 'K' (Deep Royal Navy Blue) */}
          <path
            d="M 33 46 L 68 12 A 7 7 0 0 1 78 12 L 85 18 A 6 6 0 0 1 84 27 L 45 64 Z"
            fill="url(#logo-blue-grad)"
          />
          <path
            d="M 68 13 L 78 13 L 84 19"
            stroke="#ffb732"
            strokeWidth="2"
            strokeLinecap="round"
            fill="none"
            opacity="0.8"
          />

          {/* Lower Right Diagonal Arm of 'K' (Deep Navy Blue) */}
          <path
            d="M 37 54 L 75 84 A 6 6 0 0 1 76 92 L 69 98 A 6 6 0 0 1 60 97 L 26 70 Z"
            fill="#081e3d"
          />

          {/* House Cutout on lower arm */}
          <g transform="translate(23, 67) scale(0.48)">
            <path d="M 12 18 L 30 2 L 48 18 L 48 42 L 12 42 Z" fill="#ffffff" />
            <rect x="18" y="16" width="9" height="9" rx="1.5" fill="#081e3d" />
            <rect x="33" y="16" width="9" height="9" rx="1.5" fill="#081e3d" />
            <rect x="18" y="28" width="9" height="9" rx="1.5" fill="#081e3d" />
            <rect x="33" y="28" width="9" height="9" rx="1.5" fill="#081e3d" />
          </g>

          {/* Central Lightning Bolt */}
          <polygon
            points="14,64 36,46 38,58 64,30 55,50 60,48 30,76 33,64"
            fill="url(#logo-bolt-grad)"
          />

          {/* Running Technician Character */}
          <g transform="translate(62, 34) scale(0.46)">
            {/* Speed Lines */}
            <line x1="-15" y1="18" x2="8" y2="18" stroke="#ff7a00" strokeWidth="4" strokeLinecap="round" />
            <line x1="-22" y1="28" x2="0" y2="28" stroke="#ff7a00" strokeWidth="4.5" strokeLinecap="round" />
            {/* Head & Cap */}
            <circle cx="48" cy="14" r="12" fill="#ff7a00" />
            <path d="M 42 6 Q 58 4 70 10 Q 60 12 48 12 Z" fill="#e05300" />
            {/* Body */}
            <path d="M 40 28 Q 45 46 54 58" stroke="#ff7a00" strokeWidth="10" strokeLinecap="round" />
            {/* Running Legs */}
            <path d="M 54 56 L 68 70 L 72 86" stroke="#ff7a00" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M 50 56 L 34 70 L 20 68" stroke="#ff7a00" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" />
            {/* Toolbox with Wrench */}
            <g transform="translate(10, 36) rotate(-8)">
              <rect x="0" y="5" width="28" height="20" rx="4" fill="#0c2f64" />
              <path d="M 10 10 C 8 12, 9 14, 11 16 L 18 21 L 20 19 L 13 13 C 14 11, 13 9, 11 9 Z" fill="#ffffff" />
            </g>
          </g>
        </svg>
      </div>

      {/* 2. BRAND TYPOGRAPHY & TAGLINE */}
      {variant !== 'mark-only' && (
        <div className="flex flex-col leading-none">
          {/* Main Brand Name */}
          <div className="flex items-baseline tracking-tight font-black">
            <span
              className={`${textSize} font-black ${
                inverted ? 'text-white' : 'text-slate-900'
              }`}
            >
              KARWA
            </span>
            <span className={`${textSize} ml-1 font-black text-amber-500 flex items-center`}>
              D
              {/* O with Checkmark inside */}
              <span className="relative inline-flex items-center justify-center mx-0.5">
                <span className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 rounded-full border-2 border-amber-500 inline-flex items-center justify-center">
                  <svg
                    className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-amber-500 stroke-[3.5]"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </span>
              </span>
            </span>
            <span className="text-[9px] font-bold text-slate-400 ml-0.5 -translate-y-1 sm:-translate-y-1.5">
              TM
            </span>
          </div>

          {/* Tagline: "Kaam Koi Bhi Ho. KARWA DO." */}
          {showTagline && (
            <div className={`mt-0.5 flex items-center gap-1 font-bold ${taglineSize}`}>
              <span className={inverted ? 'text-slate-300' : 'text-slate-500'}>
                Kaam Koi Bhi Ho.
              </span>
              <span className="text-amber-500 font-extrabold">KARWA DO.</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
