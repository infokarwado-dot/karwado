import React, { useState } from 'react';
import { Logo } from './Logo.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Globe,
  User,
  ShieldCheck,
  ChevronDown,
  LogOut,
  Check,
  Briefcase,
  ShieldAlert,
  Calendar,
  Home,
  FileCheck,
} from 'lucide-react';

interface NavbarProps {
  onOpenAuth: () => void;
  onOpenSafety: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAuth,
  onOpenSafety,
  activeTab,
  setActiveTab,
}) => {
  const { language, setLanguage, languages, t } = useLanguage();
  const { user, logout, activeRole } = useAuth();
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const currentLang = languages.find((l) => l.code === language) || languages[0];

  const handleDashboardNavigate = () => {
    if (user?.role === 'admin') {
      setActiveTab('admin-panel');
    } else if (user?.role === 'provider') {
      setActiveTab('provider-portal');
    } else {
      setActiveTab('home');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & Tagline */}
          <button
            onClick={handleDashboardNavigate}
            className="flex items-center text-left focus:outline-none"
          >
            <Logo size="md" />
          </button>

          {/* Desktop Navigation according to Active User Role */}
          <nav className="hidden md:flex items-center gap-1.5 lg:gap-3 text-sm font-semibold text-slate-700">
            {/* If Admin */}
            {user?.role === 'admin' ? (
              <>
                <button
                  onClick={() => setActiveTab('admin-panel')}
                  className={`px-3 py-1.5 rounded-xl transition-colors flex items-center gap-1.5 ${
                    activeTab === 'admin-panel'
                      ? 'bg-amber-100 text-amber-900 font-black'
                      : 'hover:text-amber-800 hover:bg-amber-50'
                  }`}
                >
                  <ShieldAlert className="w-4 h-4 text-amber-700" />
                  <span>Admin Dashboard</span>
                </button>
                <button
                  onClick={() => setActiveTab('home')}
                  className={`px-3 py-1.5 rounded-xl transition-colors ${
                    activeTab === 'home'
                      ? 'bg-blue-50 text-blue-700 font-bold'
                      : 'hover:text-blue-600 hover:bg-slate-50'
                  }`}
                >
                  Marketplace Preview
                </button>
              </>
            ) : user?.role === 'provider' ? (
              /* If Provider */
              <>
                <button
                  onClick={() => setActiveTab('provider-portal')}
                  className={`px-3.5 py-1.5 rounded-xl transition-colors flex items-center gap-1.5 ${
                    activeTab === 'provider-portal'
                      ? 'bg-amber-100 text-amber-900 font-black'
                      : 'hover:text-amber-800 hover:bg-amber-50'
                  }`}
                >
                  <Briefcase className="w-4 h-4 text-amber-700" />
                  <span>Provider Dashboard</span>
                </button>
                <button
                  onClick={() => setActiveTab('home')}
                  className={`px-3 py-1.5 rounded-xl transition-colors ${
                    activeTab === 'home'
                      ? 'bg-blue-50 text-blue-700 font-bold'
                      : 'hover:text-blue-600 hover:bg-slate-50'
                  }`}
                >
                  Explore Services
                </button>
                <button
                  onClick={onOpenSafety}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-slate-600 hover:text-emerald-700 rounded-xl hover:bg-emerald-50 transition-colors"
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Verified Standards</span>
                </button>
              </>
            ) : (
              /* If Customer or Guest */
              <>
                <button
                  onClick={() => setActiveTab('home')}
                  className={`px-3 py-1.5 rounded-xl transition-colors flex items-center gap-1.5 ${
                    activeTab === 'home'
                      ? 'bg-blue-50 text-blue-700 font-bold'
                      : 'hover:text-blue-600 hover:bg-slate-50'
                  }`}
                >
                  <Home className="w-4 h-4 text-blue-600" />
                  <span>{t('home')}</span>
                </button>

                <button
                  onClick={() => setActiveTab('bookings')}
                  className={`px-3 py-1.5 rounded-xl transition-colors flex items-center gap-1.5 ${
                    activeTab === 'bookings'
                      ? 'bg-blue-50 text-blue-700 font-bold'
                      : 'hover:text-blue-600 hover:bg-slate-50'
                  }`}
                >
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span>{t('bookings')}</span>
                </button>

                <button
                  onClick={() => setActiveTab('jobs')}
                  className={`px-3 py-1.5 rounded-xl transition-colors flex items-center gap-1.5 ${
                    activeTab === 'jobs'
                      ? 'bg-blue-50 text-blue-700 font-bold'
                      : 'hover:text-blue-600 hover:bg-slate-50'
                  }`}
                >
                  <Briefcase className="w-4 h-4 text-blue-600" />
                  <span>{t('jobs')}</span>
                </button>

                <button
                  onClick={onOpenSafety}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-slate-600 hover:text-emerald-700 rounded-xl hover:bg-emerald-50 transition-colors"
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{t('customerSafety')}</span>
                </button>
              </>
            )}
          </nav>

          {/* Right Action Bar */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* If not logged in as provider, show subtle Become a Partner link */}
            {!user && (
              <button
                onClick={onOpenAuth}
                className="hidden lg:inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-slate-600 hover:text-amber-800 hover:bg-amber-50 rounded-xl border border-transparent hover:border-amber-200 transition"
              >
                <span>Become a Partner</span>
              </button>
            )}

            {/* User Active Role Pill (Strictly for authenticated user) */}
            {user && (
              <span
                className={`hidden sm:inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black tracking-wide uppercase ${
                  user.role === 'admin'
                    ? 'bg-amber-100 text-amber-900 border border-amber-300'
                    : user.role === 'provider'
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                    : 'bg-blue-100 text-blue-900 border border-blue-200'
                }`}
              >
                {user.role === 'admin' && '👑 Admin'}
                {user.role === 'provider' && '⚡ Partner'}
                {user.role === 'customer' && '👤 Customer'}
              </span>
            )}

            {/* Language Selector Dropdown (Phase 2 Section 6: 7 Indian Languages) */}
            <div className="relative">
              <button
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-bold text-slate-800 shadow-sm transition"
                title="Select language"
                aria-label="Select language"
              >
                <Globe className="w-3.5 h-3.5 text-blue-600" />
                <span>{currentLang.flag} {currentLang.nativeName}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {langMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-2xl shadow-2xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100"
                  onMouseLeave={() => setLangMenuOpen(false)}
                >
                  <div className="px-3.5 py-1.5 text-[11px] font-extrabold text-slate-400 uppercase tracking-wider">
                    {t('selectLanguage')}
                  </div>
                  {languages.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => {
                        setLanguage(l.code);
                        setLangMenuOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-xs flex items-center justify-between transition ${
                        language === l.code
                          ? 'bg-blue-50 text-blue-700 font-black'
                          : 'text-slate-700 hover:bg-slate-50 font-semibold'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-sm">{l.flag}</span>
                        <div>
                          <span className="block leading-tight">{l.nativeName}</span>
                          <span className="text-slate-400 text-[10px] font-normal leading-tight">{l.name}</span>
                        </div>
                      </div>
                      {language === l.code && <Check className="w-4 h-4 text-blue-600 shrink-0" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* User Profile or Login */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 pl-2 pr-2.5 py-1.5 rounded-full border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-800 transition shadow-sm"
                >
                  <div className="w-7 h-7 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs uppercase shadow-sm">
                    {user.name ? user.name.charAt(0) : 'U'}
                  </div>
                  <span className="hidden sm:inline max-w-[110px] truncate">{user.name || 'User'}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {userMenuOpen && (
                  <div
                    className="absolute right-0 mt-2 w-56 bg-white border border-slate-200 rounded-2xl shadow-2xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100"
                    onMouseLeave={() => setUserMenuOpen(false)}
                  >
                    <div className="px-4 py-2.5 border-b border-slate-100">
                      <p className="text-xs font-black text-slate-900 truncate">{user.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{user.phone ? `+91 ${user.phone}` : user.email || user.uid}</p>
                      <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 capitalize">
                        Role: {user.role}
                      </span>
                    </div>

                    {/* Role-specific dashboard shortcut */}
                    {user.role === 'admin' && (
                      <button
                        onClick={() => {
                          setActiveTab('admin-panel');
                          setUserMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-amber-800 font-bold hover:bg-amber-50 flex items-center gap-2"
                      >
                        <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                        <span>Admin Dashboard</span>
                      </button>
                    )}

                    {user.role === 'provider' && (
                      <button
                        onClick={() => {
                          setActiveTab('provider-portal');
                          setUserMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-emerald-800 font-bold hover:bg-emerald-50 flex items-center gap-2"
                      >
                        <Briefcase className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Provider Dashboard</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setActiveTab('profile');
                        setUserMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <User className="w-3.5 h-3.5 text-slate-500" />
                      <span>{t('profile')}</span>
                    </button>

                    <button
                      onClick={() => {
                        logout();
                        setActiveTab('home');
                        setUserMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-red-600 hover:bg-red-50 flex items-center gap-2 border-t border-slate-100"
                    >
                      <LogOut className="w-3.5 h-3.5 text-red-500" />
                      <span>{t('logout')}</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-md shadow-blue-600/25 transition active:scale-95"
              >
                {t('login')}
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
