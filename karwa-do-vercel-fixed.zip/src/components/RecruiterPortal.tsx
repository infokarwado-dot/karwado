import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { Job, JobApplication } from '../types/index.ts';
import { Briefcase, Plus, Users, Building, MapPin, CheckCircle, Mail, Phone, Calendar } from 'lucide-react';

interface RecruiterPortalProps {
  onOpenAuth: () => void;
}

export const RecruiterPortal: React.FC<RecruiterPortalProps> = ({ onOpenAuth }) => {
  const { t } = useLanguage();
  const { user } = useAuth();

  const [jobs, setJobs] = useState<Job[]>([]);
  const [applications, setApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPostModal, setShowPostModal] = useState(false);

  // New Job form
  const [title, setTitle] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [category, setCategory] = useState('home-services');
  const [location, setLocation] = useState('Mumbai, Maharashtra');
  const [salaryMin, setSalaryMin] = useState('25000');
  const [salaryMax, setSalaryMax] = useState('40000');
  const [workMode, setWorkMode] = useState<'on_site' | 'remote' | 'hybrid'>('on_site');
  const [description, setDescription] = useState('');
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    if (user?.uid) {
      fetchRecruiterData();
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchRecruiterData = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const res = await fetch('/api/recruiter/jobs', {
        headers: {
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
      });
      if (res.ok) {
        const data = await res.json();
        setJobs(data.jobs || []);
        setApplications(data.applications || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setPosting(true);
    try {
      const res = await fetch('/api/jobs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({
          title,
          companyName: companyName || user.name || 'Hiring Enterprise',
          category,
          location,
          salaryMin: parseInt(salaryMin, 10),
          salaryMax: parseInt(salaryMax, 10),
          workMode,
          description,
        }),
      });
      if (res.ok) {
        setShowPostModal(false);
        setTitle('');
        setDescription('');
        fetchRecruiterData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setPosting(false);
    }
  };

  if (!user) {
    return (
      <div className="max-w-xl mx-auto py-16 px-4 text-center">
        <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
          <Briefcase className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-black text-slate-900 mb-2">{t('recruiterPortal')}</h3>
        <p className="text-xs text-slate-500 mb-6">
          Sign in to post job vacancies, manage candidate applications, and schedule interviews.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md"
        >
          {t('login')}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block mb-1">
            Enterprise Hiring Suite
          </span>
          <h2 className="text-2xl font-black text-slate-900">{t('recruiterPortal')}</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Post verified jobs and connect with real candidates across India.
          </p>
        </div>

        <button
          onClick={() => setShowPostModal(true)}
          className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 shadow-md self-start sm:self-center"
        >
          <Plus className="w-4 h-4" />
          <span>{t('postJob')}</span>
        </button>
      </div>

      {/* Grid: Posted Jobs & Candidate Applications */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Posted Jobs */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-base text-slate-900">Your Posted Jobs</h3>
            <span className="text-xs font-bold text-slate-500">{jobs.length} Active</span>
          </div>

          {loading ? (
            <div className="h-40 bg-slate-100 rounded-2xl animate-pulse" />
          ) : jobs.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              <Briefcase className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              <p>{t('noJobsPostedYet')}</p>
              <button
                onClick={() => setShowPostModal(true)}
                className="mt-3 px-4 py-2 rounded-xl bg-blue-50 text-blue-600 font-bold text-xs"
              >
                + Post Your First Job
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {jobs.map((j) => (
                <div key={j.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-1.5 text-xs">
                  <div className="flex justify-between items-start">
                    <span className="font-extrabold text-slate-900 text-sm">{j.title}</span>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                      {j.status}
                    </span>
                  </div>
                  <p className="text-slate-500 line-clamp-1">{j.companyName} • {j.location}</p>
                  <div className="text-[11px] text-slate-600 font-semibold pt-1">
                    ₹{j.salaryMin} - ₹{j.salaryMax}/month • {j.workMode}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Candidate Applications */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-base text-slate-900">Candidate Applications</h3>
            <span className="text-xs font-bold text-slate-500">{applications.length} Received</span>
          </div>

          {loading ? (
            <div className="h-40 bg-slate-100 rounded-2xl animate-pulse" />
          ) : applications.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              <Users className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              <p>No candidate applications received yet.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {applications.map((item: any) => {
                const app = item.application;
                const j = item.job;
                return (
                  <div key={app.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2 text-xs">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-bold text-slate-900 text-sm block">{app.applicantName}</span>
                        <span className="text-slate-500">Applied for: {j?.title}</span>
                      </div>
                      <span className="text-blue-700 font-black bg-blue-50 px-2 py-0.5 rounded">
                        Match: {app.matchScore}%
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-slate-600 text-[11px]">
                      <span className="flex items-center gap-1">
                        <Mail className="w-3 h-3 text-slate-400" />
                        <span>{app.applicantEmail}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{app.applicantPhone}</span>
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Post Job Modal */}
      {showPostModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-8 max-w-lg w-full space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <h3 className="text-xl font-black text-slate-900">{t('postJob')}</h3>

            <form onSubmit={handleCreateJob} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Job Title *</label>
                <input
                  type="text"
                  placeholder="e.g. Certified AC Technician / Field Mechanic"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Company Name *</label>
                  <input
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Company or Business"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Location *</label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Min Salary (₹)</label>
                  <input
                    type="number"
                    value={salaryMin}
                    onChange={(e) => setSalaryMin(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Max Salary (₹)</label>
                  <input
                    type="number"
                    value={salaryMax}
                    onChange={(e) => setSalaryMax(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Work Mode</label>
                  <select
                    value={workMode}
                    onChange={(e) => setWorkMode(e.target.value as any)}
                    className="w-full px-2 py-2 rounded-xl border border-slate-300 font-semibold"
                  >
                    <option value="on_site">On-Site</option>
                    <option value="remote">Remote</option>
                    <option value="hybrid">Hybrid</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Job Description *</label>
                <textarea
                  rows={3}
                  placeholder="Responsibilities, required certifications, working hours..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPostModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={posting}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md disabled:opacity-50"
                >
                  {posting ? 'Publishing...' : 'Publish Job'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
