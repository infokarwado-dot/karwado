import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { Service, Address, Booking } from '../types/index.ts';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  CreditCard,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Plus,
  ArrowRight,
} from 'lucide-react';

interface BookingModalProps {
  service: Service;
  initialProblemText?: string;
  onClose: () => void;
  onBookingSuccess: (booking: Booking) => void;
  onOpenAuth: () => void;
}

const TIME_SLOTS = [
  '09:00 AM - 11:00 AM',
  '11:00 AM - 01:00 PM',
  '02:00 PM - 04:00 PM',
  '04:00 PM - 06:00 PM',
  '06:00 PM - 08:00 PM',
];

export const BookingModal: React.FC<BookingModalProps> = ({
  service,
  initialProblemText = '',
  onClose,
  onBookingSuccess,
  onOpenAuth,
}) => {
  const { t } = useLanguage();
  const { user, addresses, addAddress } = useAuth();

  const [scheduledDate, setScheduledDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [scheduledTime, setScheduledTime] = useState(TIME_SLOTS[1]);
  const [problemDescription, setProblemDescription] = useState(initialProblemText);
  const [selectedAddressId, setSelectedAddressId] = useState<number | null>(
    addresses.length > 0 ? addresses[0].id : null
  );

  // Quick Address add form toggle
  const [showAddAddress, setShowAddAddress] = useState(addresses.length === 0);
  const [newFullAddress, setNewFullAddress] = useState('');
  const [newCity, setNewCity] = useState('Mumbai');
  const [newState, setNewState] = useState('Maharashtra');
  const [newPincode, setNewPincode] = useState('400001');

  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSaveNewAddress = async () => {
    if (!newFullAddress || !newCity || !newPincode) return;
    const created = await addAddress({
      label: 'Home',
      fullAddress: newFullAddress,
      city: newCity,
      state: newState,
      pincode: newPincode,
    });
    if (created) {
      setSelectedAddressId(created.id);
      setShowAddAddress(false);
    }
  };

  const handleConfirmBooking = async () => {
    if (!user) {
      onOpenAuth();
      return;
    }

    if (showAddAddress && !selectedAddressId) {
      if (!newFullAddress || !newCity || !newPincode) {
        setErrorMsg('Please enter your service address details.');
        return;
      }
      const created = await addAddress({
        label: 'Home',
        fullAddress: newFullAddress,
        city: newCity,
        state: newState,
        pincode: newPincode,
      });
      if (created) setSelectedAddressId(created.id);
    }

    setLoading(true);
    setErrorMsg(null);

    const isCustomQuote =
      service.pricingType === 'CUSTOM_QUOTE' ||
      service.pricingType === 'quote' ||
      (service as any).pricing_type === 'CUSTOM_QUOTE';

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({
          serviceId: service.id,
          scheduledDate,
          scheduledTime,
          problemDescription: problemDescription || `Requested ${service.name}`,
          addressId: selectedAddressId || undefined,
          serviceType: 'standard',
          paymentMethod: isCustomQuote ? 'quote_inspection' : paymentMethod,
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to place booking');
      }

      const booking = await res.json();

      // Initiate payment step ONLY for fixed / non-quote bookings.
      // Phase 3 Section 9: No payment captured for unapproved quote!
      if (!isCustomQuote) {
        const payRes = await fetch(`/api/bookings/${booking.id}/payment`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${user.uid}`,
            'x-user-id': user.uid,
          },
          body: JSON.stringify({
            paymentMethod,
            transactionId: `RZP-${Date.now()}`,
          }),
        });

        if (payRes.ok) {
          const payData = await payRes.json();
          onBookingSuccess(payData.booking);
        } else {
          onBookingSuccess(booking);
        }
      } else {
        onBookingSuccess(booking);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Booking submission error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const isCustomQuote =
    service.pricingType === 'CUSTOM_QUOTE' ||
    service.pricingType === 'quote' ||
    (service as any).pricing_type === 'CUSTOM_QUOTE';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 flex items-start justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-400 block mb-1">
              {service.categoryName || 'Service'} Booking
            </span>
            <h3 className="text-xl sm:text-2xl font-black">{service.name}</h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Duration: {service.estimatedDuration || '60 mins'} • 30-day Service Guarantee
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Phase 3 Section 9: CUSTOM QUOTE vs Fixed Pricing */}
          {isCustomQuote ? (
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-xs space-y-1.5">
              <div className="flex items-center gap-2 font-bold text-amber-950">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Custom Quote Service</span>
              </div>
              <p className="text-amber-900 font-semibold text-sm">
                Price will be confirmed after provider inspection.
              </p>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                A verified technician will inspect the premises, assess parts & labor, and submit a transparent quote for your review. No upfront payment is required.
              </p>
            </div>
          ) : (
            <div className="bg-blue-50/70 border border-blue-200/80 rounded-2xl p-4 text-xs">
              <div className="flex items-center justify-between font-bold text-blue-900 mb-2">
                <span>Transparent Price Breakdown</span>
                <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded-full">
                  Zero Hidden Charges
                </span>
              </div>
              <div className="space-y-1.5 text-slate-700">
                <div className="flex justify-between">
                  <span>Service Total ({service.name}):</span>
                  <span className="font-semibold">₹{service.customerPrice}</span>
                </div>
                <div className="flex justify-between text-slate-500 text-[11px]">
                  <span>Platform Commission & Taxes:</span>
                  <span>₹{service.platformCommission}</span>
                </div>
                <div className="flex justify-between text-slate-500 text-[11px]">
                  <span>Direct Provider Payout:</span>
                  <span className="text-emerald-700 font-semibold">₹{service.providerAmount}</span>
                </div>
                <div className="border-t border-blue-200/60 pt-2 flex justify-between font-black text-slate-900 text-sm">
                  <span>{t('totalAmount')} Payable:</span>
                  <span className="text-blue-700 text-base">₹{service.customerPrice}</span>
                </div>
              </div>
            </div>
          )}

          {/* Date & Time Slot Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
                <span>{t('scheduledDate')}</span>
              </label>
              <input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-semibold"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide mb-1.5 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-600" />
                <span>{t('scheduledTime')}</span>
              </label>
              <select
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-semibold"
              >
                {TIME_SLOTS.map((slot) => (
                  <option key={slot} value={slot}>
                    {slot}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Problem / Custom Requirements */}
          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide mb-1.5">
              Specific problem or instructions:
            </label>
            <input
              type="text"
              placeholder="e.g. AC cooling low, noise from outdoor unit, 2nd floor..."
              value={problemDescription}
              onChange={(e) => setProblemDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
            />
          </div>

          {/* Service Address Selection */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-blue-600" />
                <span>{t('address')}</span>
              </label>
              {addresses.length > 0 && (
                <button
                  type="button"
                  onClick={() => setShowAddAddress(!showAddAddress)}
                  className="text-xs font-bold text-blue-600 hover:text-blue-700"
                >
                  {showAddAddress ? 'Use Saved Address' : t('addNewAddress')}
                </button>
              )}
            </div>

            {/* Existing addresses */}
            {!showAddAddress && addresses.length > 0 ? (
              <div className="space-y-2">
                {addresses.map((addr) => (
                  <div
                    key={addr.id}
                    onClick={() => setSelectedAddressId(addr.id)}
                    className={`p-3 rounded-xl border-2 text-xs cursor-pointer transition ${
                      selectedAddressId === addr.id
                        ? 'border-blue-600 bg-blue-50/50'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-bold text-slate-900 block">{addr.label}</span>
                    <span className="text-slate-600">{addr.fullAddress}, {addr.city} - {addr.pincode}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2.5">
                <textarea
                  placeholder="Door / Flat No., Apartment / Building Name, Street Area *"
                  value={newFullAddress}
                  onChange={(e) => setNewFullAddress(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                  required
                />
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="City *"
                    value={newCity}
                    onChange={(e) => setNewCity(e.target.value)}
                    className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white"
                  />
                  <input
                    type="text"
                    placeholder="State *"
                    value={newState}
                    onChange={(e) => setNewState(e.target.value)}
                    className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white"
                  />
                  <input
                    type="text"
                    placeholder="Pincode *"
                    value={newPincode}
                    onChange={(e) => setNewPincode(e.target.value)}
                    className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Payment Method & Gateway Integration Status */}
          {isCustomQuote ? (
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1">
              <span className="font-bold text-slate-800 block">Inspection & Quote Workflow</span>
              <p className="text-slate-500 text-[11px]">
                No payment is captured at this stage. You will receive an itemized quote on your dashboard after the provider inspection for your explicit approval.
              </p>
            </div>
          ) : (
            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide mb-2 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-blue-600" />
                <span>Select Payment Method</span>
              </label>
              <div className="grid grid-cols-3 gap-2 mb-3">
                {[
                  { id: 'upi', label: 'UPI / QR', icon: '⚡' },
                  { id: 'card', label: 'Cards / Netbanking', icon: '💳' },
                  { id: 'cash', label: 'Pay After Service', icon: '💵' },
                ].map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPaymentMethod(p.id as any)}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1 ${
                      paymentMethod === p.id
                        ? 'border-blue-600 bg-blue-50 text-blue-900'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-base">{p.icon}</span>
                    <span>{p.label}</span>
                  </button>
                ))}
              </div>

              {/* Integration notice per prompt */}
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
                <span>Payment Gateway: Indian Gateway (Razorpay/UPI Architecture)</span>
                <span className="font-semibold text-blue-700 bg-blue-100/70 px-2 py-0.5 rounded">
                  Test Mode Ready
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Action Button */}
        <div className="p-5 sm:p-6 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">
              {isCustomQuote ? 'Price Status' : t('totalAmount')}
            </span>
            <span className="text-xl font-black text-slate-900">
              {isCustomQuote ? 'Quote upon inspection' : `₹${service.customerPrice}`}
            </span>
          </div>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-200 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleConfirmBooking}
              disabled={loading}
              className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-md transition flex items-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <span>{isCustomQuote ? 'Request Inspection & Quote' : t('confirmBooking')}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
