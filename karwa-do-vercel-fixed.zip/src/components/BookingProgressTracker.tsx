import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  CheckCircle2,
  Clock,
  Navigation,
  Wrench,
  ShieldCheck,
  UserCheck,
  Play,
  Pause,
  FastForward,
  RotateCcw,
  Radio,
  Phone,
  ChevronDown,
  ChevronUp,
  Sparkles,
  AlertTriangle,
  MapPin,
  Check,
  Flame,
  Activity,
  Award,
} from 'lucide-react';

export interface BookingProgressTrackerProps {
  booking: any;
  service?: any;
  address?: any;
  onStatusUpdated?: () => void;
}

interface StepConfig {
  id: string;
  label: string;
  sublabel: string;
  icon: React.ComponentType<{ className?: string }>;
}

const STEPS: StepConfig[] = [
  {
    id: 'requested',
    label: 'Requested',
    sublabel: 'Booking Queued',
    icon: Clock,
  },
  {
    id: 'provider_assigned',
    label: 'Partner Assigned',
    sublabel: 'Verified Pro Allocated',
    icon: UserCheck,
  },
  {
    id: 'provider_on_the_way',
    label: 'On The Way',
    sublabel: 'En Route to Location',
    icon: Navigation,
  },
  {
    id: 'in_progress',
    label: 'In Progress',
    sublabel: 'Work Underway',
    icon: Wrench,
  },
  {
    id: 'completed',
    label: 'Completed',
    sublabel: 'Service Finished',
    icon: ShieldCheck,
  },
];

export const BookingProgressTracker: React.FC<BookingProgressTrackerProps> = ({
  booking,
  service,
  address,
  onStatusUpdated,
}) => {
  const { user } = useAuth();

  const [currentStatus, setCurrentStatus] = useState<string>(booking.status || 'requested');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationCountdown, setSimulationCountdown] = useState<number>(8);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [showLogs, setShowLogs] = useState<boolean>(false);
  const [historyLogs, setHistoryLogs] = useState<any[]>([]);
  const [loadingLogs, setLoadingLogs] = useState<boolean>(false);

  // Live ETA countdown timer for 'provider_on_the_way'
  const [etaSeconds, setEtaSeconds] = useState<number>(720); // 12 minutes
  // Live job timer for 'in_progress'
  const [elapsedJobSeconds, setElapsedJobSeconds] = useState<number>(450); // 7m 30s

  const simulationTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Keep internal status synced if parent booking status changes
  useEffect(() => {
    setCurrentStatus(booking.status || 'requested');
  }, [booking.status]);

  // Live ETA countdown tick
  useEffect(() => {
    if (currentStatus !== 'provider_on_the_way') return;
    const interval = setInterval(() => {
      setEtaSeconds((prev) => (prev > 10 ? prev - 1 : 10));
    }, 1000);
    return () => clearInterval(interval);
  }, [currentStatus]);

  // Live Job Elapsed timer tick
  useEffect(() => {
    if (currentStatus !== 'in_progress') return;
    const interval = setInterval(() => {
      setElapsedJobSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [currentStatus]);

  // Fetch status logs whenever logs drawer is opened or status changes
  const fetchStatusLogs = async () => {
    if (!booking.id) return;
    try {
      setLoadingLogs(true);
      const res = await fetch(`/api/bookings/${booking.id}`);
      if (res.ok) {
        const data = await res.json();
        if (data.history) {
          setHistoryLogs(data.history);
        }
      }
    } catch (err) {
      console.error('Error fetching booking history:', err);
    } finally {
      setLoadingLogs(false);
    }
  };

  useEffect(() => {
    if (showLogs) {
      fetchStatusLogs();
    }
  }, [showLogs, currentStatus]);

  // Auto-simulation ticker
  useEffect(() => {
    if (!isSimulating) {
      if (simulationTimerRef.current) clearInterval(simulationTimerRef.current);
      return;
    }

    setSimulationCountdown(8);
    simulationTimerRef.current = setInterval(() => {
      setSimulationCountdown((prev) => {
        if (prev <= 1) {
          // Trigger next step
          advanceSimulationStep();
          return 8;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (simulationTimerRef.current) clearInterval(simulationTimerRef.current);
    };
  }, [isSimulating, currentStatus]);

  const advanceSimulationStep = async (target?: string, action?: 'advance' | 'reset') => {
    if (isUpdating || !booking.id) return;

    try {
      setIsUpdating(true);
      const res = await fetch(`/api/bookings/${booking.id}/simulate-step`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: user ? `Bearer ${user.uid}` : '',
          'x-user-id': user ? user.uid : 'guest',
        },
        body: JSON.stringify({
          targetStatus: target,
          stepAction: action || 'advance',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.booking) {
          setCurrentStatus(data.booking.status);
          if (data.booking.status === 'completed') {
            setIsSimulating(false);
          }
          if (data.booking.status === 'provider_on_the_way') {
            setEtaSeconds(720);
          }
          if (data.booking.status === 'in_progress') {
            setElapsedJobSeconds(60);
          }
        }
        if (onStatusUpdated) onStatusUpdated();
        if (showLogs) fetchStatusLogs();
      }
    } catch (err) {
      console.error('Simulation step error:', err);
    } finally {
      setIsUpdating(false);
    }
  };

  // Calculate current active step index
  const getStepIndex = (status: string) => {
    switch (status) {
      case 'requested':
      case 'inspection_scheduled':
        return 0;
      case 'provider_assigned':
      case 'quote_submitted':
        return 1;
      case 'provider_on_the_way':
      case 'quote_approved':
        return 2;
      case 'in_progress':
        return 3;
      case 'completed':
        return 4;
      default:
        return 0;
    }
  };

  const activeIndex = getStepIndex(currentStatus);
  const isTerminated = currentStatus === 'cancelled' || currentStatus === 'disputed';
  const progressPercent = isTerminated ? 100 : (activeIndex / (STEPS.length - 1)) * 100;

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="rounded-2xl border border-slate-200/90 bg-gradient-to-b from-slate-50/70 to-white p-4 sm:p-5 space-y-4 shadow-sm">
      {/* Header Row: Title & Simulation Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="relative flex items-center justify-center">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping absolute" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 relative" />
          </div>
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
              <span>Live Progress Tracker</span>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                Real-Time Telemetry
              </span>
            </h4>
            <p className="text-[11px] text-slate-500">
              Simulated dispatch tracking & milestone timeline
            </p>
          </div>
        </div>

        {/* Real-time simulation controller toolbar */}
        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Auto-simulation toggle */}
          <button
            type="button"
            onClick={() => setIsSimulating(!isSimulating)}
            disabled={isUpdating || currentStatus === 'completed'}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-[11px] transition shadow-xs cursor-pointer ${
              isSimulating
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-600 animate-pulse'
                : 'bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50'
            }`}
            title="Simulate real-time provider movement and stage progression"
          >
            {isSimulating ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Simulating ({simulationCountdown}s)</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>Simulate Live Updates</span>
              </>
            )}
          </button>

          {/* Advance Step Button */}
          <button
            type="button"
            onClick={() => advanceSimulationStep(undefined, 'advance')}
            disabled={isUpdating || currentStatus === 'completed'}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-blue-600 font-bold text-[11px] transition disabled:opacity-40 cursor-pointer"
            title="Immediately advance to next stage"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Next Stage</span>
          </button>

          {/* Reset Simulation */}
          <button
            type="button"
            onClick={() => advanceSimulationStep(undefined, 'reset')}
            disabled={isUpdating}
            className="flex items-center gap-1 px-2 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-slate-800 text-[11px] transition cursor-pointer"
            title="Reset simulation to initial requested stage"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset</span>
          </button>
        </div>
      </div>

      {/* Dynamic Visual Timeline Component */}
      <div className="pt-2 pb-1">
        {/* Horizontal Progress Bar Track */}
        <div className="relative">
          {/* Base Track */}
          <div className="absolute top-4 left-6 right-6 h-1 bg-slate-200 -z-0 rounded-full" />
          {/* Animated Filled Progress */}
          <div
            className="absolute top-4 left-6 h-1 bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-500 rounded-full transition-all duration-700 ease-out -z-0"
            style={{ width: `calc(${progressPercent}% * 0.88)` }}
          />

          {/* Milestone Nodes */}
          <div className="grid grid-cols-5 relative z-10 gap-1 text-center">
            {STEPS.map((step, idx) => {
              const IconComp = step.icon;
              const isPast = idx < activeIndex;
              const isCurrent = idx === activeIndex && !isTerminated;
              const isFuture = idx > activeIndex;

              return (
                <div key={step.id} className="flex flex-col items-center group">
                  {/* Circle Indicator */}
                  <div
                    className={`relative w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                      isPast
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : isCurrent
                        ? 'bg-blue-600 text-white ring-4 ring-blue-100 shadow-md scale-110'
                        : 'bg-white border-2 border-slate-300 text-slate-400'
                    }`}
                  >
                    {isCurrent && (
                      <span className="absolute -inset-1 rounded-full border border-blue-400 animate-ping opacity-75" />
                    )}

                    {isPast ? (
                      <Check className="w-4 h-4 stroke-[3]" />
                    ) : (
                      <IconComp className="w-4 h-4" />
                    )}
                  </div>

                  {/* Step Label */}
                  <div className="mt-2 space-y-0.5">
                    <span
                      className={`block text-[11px] font-bold leading-tight ${
                        isCurrent
                          ? 'text-blue-700 font-extrabold'
                          : isPast
                          ? 'text-slate-800'
                          : 'text-slate-400'
                      }`}
                    >
                      {step.label}
                    </span>
                    <span className="hidden md:block text-[9px] text-slate-400 leading-none">
                      {step.sublabel}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Dynamic Simulated Telemetry Station (Content changes based on current stage) */}
      <div className="mt-3">
        {/* Stage 0: Requested / Scanning */}
        {activeIndex === 0 && (
          <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-100 text-xs flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Radio className="w-5 h-5 animate-spin" />
              </div>
              <div>
                <span className="font-extrabold text-blue-950 block text-xs">
                  Dispatch Radar Searching Nearest Verified Partner
                </span>
                <p className="text-[11px] text-blue-700 mt-0.5">
                  Matching with vetted specialists in your vicinity. Average match time: &lt; 2 minutes.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-[11px] font-bold text-blue-800 bg-white/90 px-3 py-1.5 rounded-lg border border-blue-200">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Smart Dispatch Queue</span>
            </div>
          </div>
        )}

        {/* Stage 1: Partner Assigned */}
        {activeIndex === 1 && (
          <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-emerald-600 text-white font-black flex items-center justify-center text-sm shadow-xs">
                  RS
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-slate-900">Rajesh Sharma</span>
                    <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                      Verified Specialist
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 block">
                    Rating: 4.9 ★ (342 completed jobs) • Police Verified & KYC Checked
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href="tel:+919820011223"
                  onClick={(e) => {
                    e.preventDefault();
                    alert('Connecting call with partner Rajesh Sharma via virtual masked number...');
                  }}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white border border-emerald-300 text-emerald-800 font-bold hover:bg-emerald-100 text-xs transition cursor-pointer"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Call Partner</span>
                </a>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 border-t border-emerald-100 text-[11px] text-emerald-950">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Uniform & Safety Kit</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Calibrated Diagnostic Tools</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Zero-Contact Option</span>
              </div>
            </div>
          </div>
        )}

        {/* Stage 2: Provider On The Way */}
        {activeIndex === 2 && (
          <div className="p-3.5 rounded-xl bg-indigo-50/70 border border-indigo-200 text-xs space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs relative">
                  <Navigation className="w-5 h-5 animate-pulse" />
                  <span className="w-2 h-2 rounded-full bg-emerald-400 absolute top-1 right-1" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-indigo-950 text-sm">
                      Partner is En Route
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-200/70 text-indigo-900 animate-pulse">
                      Live GPS Ping
                    </span>
                  </div>
                  <p className="text-[11px] text-indigo-700 mt-0.5">
                    Traveling via arterial roads • Moving towards your scheduled address
                  </p>
                </div>
              </div>

              {/* Dynamic Live ETA Counter */}
              <div className="bg-white px-4 py-2 rounded-xl border border-indigo-200 text-center shadow-xs">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Estimated Arrival
                </span>
                <span className="text-base font-black text-indigo-600 font-mono">
                  {formatTime(etaSeconds)}
                </span>
              </div>
            </div>

            {/* Simulated Live Route Bar */}
            <div className="p-2.5 rounded-lg bg-white/80 border border-indigo-100 flex items-center justify-between text-[11px] text-slate-600">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-indigo-600" />
                <span className="font-semibold text-slate-800">Current Position:</span>
                <span>~2.4 km away (Approx. 6 signals)</span>
              </div>
              <span className="text-emerald-700 font-bold hidden sm:inline">
                Traffic: Smooth Flow
              </span>
            </div>
          </div>
        )}

        {/* Stage 3: In Progress */}
        {activeIndex === 3 && (
          <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 text-xs space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 shadow-xs">
                  <Wrench className="w-5 h-5 animate-spin" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-amber-950 text-sm">
                      Service In Progress on Site
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-200 text-amber-900">
                      Work Verified
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-800 mt-0.5">
                    Partner has arrived, verified safety protocol, and active work is underway.
                  </p>
                </div>
              </div>

              {/* Live Elapsed Work Timer */}
              <div className="bg-white px-4 py-2 rounded-xl border border-amber-200 text-center shadow-xs">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Time on Site
                </span>
                <span className="text-base font-black text-amber-600 font-mono">
                  {formatTime(elapsedJobSeconds)}
                </span>
              </div>
            </div>

            {/* Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 bg-white/80 p-2.5 rounded-lg border border-amber-100 text-[11px]">
              <div className="flex items-center gap-1.5 text-emerald-800 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>OTP Verified & Check-in</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-800 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Scope & Diagnostics Validated</span>
              </div>
              <div className="flex items-center gap-1.5 text-amber-800 font-medium">
                <Activity className="w-3.5 h-3.5 text-amber-600 shrink-0 animate-pulse" />
                <span>Work Underway</span>
              </div>
            </div>
          </div>
        )}

        {/* Stage 4: Completed */}
        {activeIndex === 4 && (
          <div className="p-3.5 rounded-xl bg-emerald-50/80 border border-emerald-200 text-xs flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <span className="font-extrabold text-emerald-950 block text-xs">
                  Service Completed with 100% Assurance
                </span>
                <p className="text-[11px] text-emerald-800 mt-0.5">
                  Inspection checklist approved. 30-Day KARWA DO Service Warranty is now activated.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold text-emerald-800 bg-white px-3 py-1.5 rounded-lg border border-emerald-200">
                Invoice & Warranty Ready
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Collapsible Status Audit Trail & Event Logs */}
      <div className="pt-1">
        <button
          type="button"
          onClick={() => setShowLogs(!showLogs)}
          className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500 hover:text-slate-800 transition cursor-pointer"
        >
          {showLogs ? (
            <ChevronUp className="w-3.5 h-3.5" />
          ) : (
            <ChevronDown className="w-3.5 h-3.5" />
          )}
          <span>
            {showLogs ? 'Hide Live Timeline Audit Logs' : 'View Live Timeline Audit Logs'}
          </span>
          {historyLogs.length > 0 && (
            <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-200 text-slate-700">
              {historyLogs.length} events
            </span>
          )}
        </button>

        {showLogs && (
          <div className="mt-2 p-3 bg-slate-100/70 rounded-xl border border-slate-200/80 space-y-2 text-[11px]">
            {loadingLogs ? (
              <div className="text-slate-400 py-2 text-center">Loading audit log entries...</div>
            ) : historyLogs.length === 0 ? (
              <div className="text-slate-500 py-1 text-center">
                Initial booking request recorded. Status updates will log here in real time.
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {historyLogs.map((log: any, i: number) => (
                  <div
                    key={log.id || i}
                    className="flex items-start gap-2 bg-white p-2 rounded-lg border border-slate-200 shadow-xs"
                  >
                    <span className="w-2 h-2 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="font-bold text-slate-900 uppercase">
                          {log.status.replace(/_/g, ' ')}
                        </span>
                        <span className="text-slate-400">
                          {new Date(log.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <p className="text-slate-600 mt-0.5 text-[11px] leading-tight">
                        {log.note || 'Milestone achieved'}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
