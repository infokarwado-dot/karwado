import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { Service, Booking } from '../types/index.ts';
import {
  Wrench,
  AlertCircle,
  CheckCircle2,
  Clock,
  MapPin,
  ArrowRight,
  ShieldCheck,
  PhoneCall,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface BikeRepairFlowProps {
  onSuccess: (booking: Booking) => void;
  onCancel: () => void;
  onOpenAuth: () => void;
}

const ISSUE_OPTIONS = [
  { id: 'wont_start', label: "Bike won't start", icon: '⚡', desc: 'Starting trouble, self clicking or silent' },
  { id: 'puncture', label: 'Puncture', icon: '🛞', desc: 'Flat tyre, tubeless repair or tube puncture' },
  { id: 'battery', label: 'Battery issue', icon: '🔋', desc: 'Dead battery, jumpstart or replacement' },
  { id: 'engine', label: 'Engine issue', icon: '⚙️', desc: 'Smoke, overheating, missing pickup or noise' },
  { id: 'general', label: 'General repair', icon: '🔧', desc: 'Brakes, chain, clutch or regular tune-up' },
  { id: 'towing', label: 'Pickup/towing', icon: '🚚', desc: 'Breakdown flatbed or towing to nearest garage' },
  { id: 'other', label: 'Other', icon: '❓', desc: 'Describe custom bike issue' },
];

export const BikeRepairFlow: React.FC<BikeRepairFlowProps> = ({
  onSuccess,
  onCancel,
  onOpenAuth,
}) => {
  const { t } = useLanguage();
  const { user, addresses } = useAuth();

  const [selectedIssue, setSelectedIssue] = useState<string>('wont_start');
  const [step, setStep] = useState<1 | 2 | 3>(1); // 1: Issue & Questions, 2: Recommendation & Provider Matching, 3: Address & Confirmation

  // Relevant questions based on issue
  const [bikeBrandModel, setBikeBrandModel] = useState('');
  const [punctureType, setPunctureType] = useState<'tubeless' | 'tube'>('tubeless');
  const [punctureWheel, setPunctureWheel] = useState<'front' | 'rear'>('rear');
  const [wontStartType, setWontStartType] = useState<'clicking' | 'dead_silent' | 'kicking_hard'>('clicking');
  const [batteryAction, setBatteryAction] = useState<'jumpstart' | 'new_battery_check'>('jumpstart');
  const [locationAddress, setLocationAddress] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState(user?.phone || '');
  const [additionalNotes, setAdditionalNotes] = useState('');

  // Provider matching state
  const [checkingProviders, setCheckingProviders] = useState(false);
  const [availableProviders, setAvailableProviders] = useState<any[]>([]);
  const [matchedService, setMatchedService] = useState<Service | null>(null);
  const [noProviderFound, setNoProviderFound] = useState(false);
  const [callbackRequested, setCallbackRequested] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleCalculateRecommendation = async () => {
    setCheckingProviders(true);
    setErrorMsg(null);
    setNoProviderFound(false);

    try {
      // Find matching real service from database
      const res = await fetch('/api/services');
      const allServices: Service[] = await res.json();

      let targetSlug = 'bike-repair';
      if (selectedIssue === 'puncture') targetSlug = 'roadside-puncture';
      else if (selectedIssue === 'battery') targetSlug = 'battery-jumpstart';
      else if (selectedIssue === 'towing') targetSlug = 'towing-service';
      else if (selectedIssue === 'engine' || selectedIssue === 'general') targetSlug = 'bike-repair';
      else if (selectedIssue === 'wont_start') targetSlug = 'bike-repair';

      const s = allServices.find((item) => item.slug === targetSlug) || allServices[0];
      setMatchedService(s);

      // Check real provider matching from backend
      const provRes = await fetch(`/api/services/${s.id}/availability`);
      if (provRes.ok) {
        const provData = await provRes.json();
        setAvailableProviders(provData.providers || []);
        if (!provData.available || provData.providers.length === 0) {
          setNoProviderFound(true);
        }
      }
      setStep(2);
    } catch (err) {
      console.error(err);
      setErrorMsg('Failed to fetch service details. Please try again.');
    } finally {
      setCheckingProviders(false);
    }
  };

  const handleConfirmBooking = async () => {
    if (!user) {
      onOpenAuth();
      return;
    }
    if (!matchedService) return;

    setBookingLoading(true);
    setErrorMsg(null);

    const problemDesc = [
      `Bike Issue: ${ISSUE_OPTIONS.find((o) => o.id === selectedIssue)?.label}`,
      bikeBrandModel ? `Model: ${bikeBrandModel}` : null,
      selectedIssue === 'puncture' ? `Wheel: ${punctureWheel} (${punctureType})` : null,
      selectedIssue === 'wont_start' ? `Symptom: ${wontStartType}` : null,
      selectedIssue === 'battery' ? `Requirement: ${batteryAction}` : null,
      additionalNotes ? `Notes: ${additionalNotes}` : null,
      locationAddress ? `Location: ${locationAddress}` : null,
    ]
      .filter(Boolean)
      .join(' | ');

    try {
      const today = new Date().toISOString().split('T')[0];
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({
          serviceId: matchedService.id,
          scheduledDate: today,
          scheduledTime: 'Immediate Dispatch (30 mins)',
          problemDescription: problemDesc,
          serviceType: 'bike_repair',
          paymentMethod: 'upi',
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to place bike repair booking');
      }

      const booking = await res.json();
      onSuccess(booking);
    } catch (err: any) {
      setErrorMsg(err.message || 'Booking submission failed.');
    } finally {
      setBookingLoading(false);
    }
  };

  const handleRequestCallback = async () => {
    if (!emergencyPhone || !matchedService) return;
    try {
      await fetch('/api/bookings/callback-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          serviceId: matchedService.id,
          phone: emergencyPhone,
          notes: `Bike Repair (${selectedIssue}) at ${locationAddress || 'Roadside'}`,
        }),
      });
      setCallbackRequested(true);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white p-6 sm:p-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-400/30 uppercase tracking-wider mb-2">
          <Wrench className="w-3.5 h-3.5 text-amber-400" />
          <span>Dedicated Bike Repair Service</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black">Two-Wheeler Breakdown & Repair</h2>
        <p className="text-xs sm:text-sm text-slate-300 mt-1">
          Select your bike issue. We will ask only relevant questions and connect you with a verified doorstep mechanic.
        </p>
      </div>

      <div className="p-6 sm:p-8 space-y-6">
        {errorMsg && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* STEP 1: Select Bike Issue & Answer Only Relevant Questions */}
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div>
              <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
                1. What is the issue with your bike? *
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {ISSUE_OPTIONS.map((opt) => {
                  const isSelected = selectedIssue === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setSelectedIssue(opt.id)}
                      className={`p-3.5 rounded-2xl border text-left transition cursor-pointer flex items-start gap-3 ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/70 shadow-sm'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <span className="text-2xl shrink-0">{opt.icon}</span>
                      <div>
                        <span className={`text-xs font-extrabold block ${isSelected ? 'text-blue-900' : 'text-slate-900'}`}>
                          {opt.label}
                        </span>
                        <span className="text-[11px] text-slate-500 line-clamp-1">{opt.desc}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Relevant Questions based strictly on selection */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600 block">
                2. Quick Details
              </span>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Bike Brand & Model (e.g. Honda Activa, Royal Enfield, Pulsar):
                </label>
                <input
                  type="text"
                  placeholder="Enter bike model..."
                  value={bikeBrandModel}
                  onChange={(e) => setBikeBrandModel(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                />
              </div>

              {selectedIssue === 'puncture' && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Tyre Type:</label>
                    <div className="flex gap-2">
                      {(['tubeless', 'tube'] as const).map((tType) => (
                        <button
                          key={tType}
                          type="button"
                          onClick={() => setPunctureType(tType)}
                          className={`flex-1 py-1.5 rounded-lg border text-xs font-bold uppercase ${
                            punctureType === tType
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-white text-slate-700 border-slate-300'
                          }`}
                        >
                          {tType}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Which Wheel:</label>
                    <div className="flex gap-2">
                      {(['front', 'rear'] as const).map((wheel) => (
                        <button
                          key={wheel}
                          type="button"
                          onClick={() => setPunctureWheel(wheel)}
                          className={`flex-1 py-1.5 rounded-lg border text-xs font-bold capitalize ${
                            punctureWheel === wheel
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-white text-slate-700 border-slate-300'
                          }`}
                        >
                          {wheel}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {selectedIssue === 'wont_start' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    What happens when you try to start?
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'clicking', label: 'Clicking sound' },
                      { id: 'dead_silent', label: 'Completely silent' },
                      { id: 'kicking_hard', label: 'Kick slip / Hard' },
                    ].map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setWontStartType(opt.id as any)}
                        className={`p-2 rounded-xl border text-[11px] font-bold text-center ${
                          wontStartType === opt.id
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-white text-slate-700 border-slate-300'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {selectedIssue === 'battery' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Battery Requirement:
                  </label>
                  <div className="flex gap-2">
                    {[
                      { id: 'jumpstart', label: 'Quick Jumpstart' },
                      { id: 'new_battery_check', label: 'Battery Health Check & Replace' },
                    ].map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setBatteryAction(opt.id as any)}
                        className={`flex-1 p-2 rounded-xl border text-xs font-bold ${
                          batteryAction === opt.id
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-white text-slate-700 border-slate-300'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Location / Landmark (Breakdown spot) *:
                </label>
                <input
                  type="text"
                  placeholder="e.g. Near Metro Station / Home / Office..."
                  value={locationAddress}
                  onChange={(e) => setLocationAddress(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                  required
                />
              </div>
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleCalculateRecommendation}
                disabled={checkingProviders}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
              >
                {checkingProviders ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Matching Verified Mechanics...</span>
                  </>
                ) : (
                  <>
                    <span>Next: View Price & Providers</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Service Recommendation, Price & Provider Matching */}
        {step === 2 && matchedService && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="p-5 rounded-2xl bg-blue-50/60 border border-blue-100 space-y-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Recommended Solution</span>
              </div>
              <h3 className="text-xl font-black text-slate-900">{matchedService.name}</h3>
              <p className="text-xs text-slate-600">{matchedService.description}</p>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="bg-white p-3 rounded-xl border border-blue-100">
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Customer Price</span>
                  <span className="text-2xl font-black text-slate-950">₹{matchedService.customerPrice}</span>
                </div>
                <div className="bg-white p-3 rounded-xl border border-blue-100">
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">ETA</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span className="text-base font-extrabold text-slate-900">20-30 Mins</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Provider Matching Result (Phase 3 Section 12) */}
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Verified Technician Matching
              </span>

              {availableProviders.length > 0 ? (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs space-y-2">
                  <div className="flex items-center gap-2 font-bold text-emerald-900">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>{availableProviders.length} Verified Two-Wheeler Mechanics Online</span>
                  </div>
                  <p className="text-emerald-800 text-[11px]">
                    Technicians are active in your area and ready for immediate dispatch.
                  </p>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-slate-100 border border-slate-300 text-xs space-y-3">
                  <div className="flex items-start gap-2 text-slate-700">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block text-slate-900">
                        No provider is currently available for this service.
                      </span>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Our technicians in your vicinity are currently attending to active jobs. Request a callback and dispatch will coordinate manually.
                      </p>
                    </div>
                  </div>

                  {callbackRequested ? (
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold">
                      ✓ Callback requested. Dispatch team will call within 5 minutes.
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <input
                        type="tel"
                        placeholder="Mobile number..."
                        value={emergencyPhone}
                        onChange={(e) => setEmergencyPhone(e.target.value)}
                        className="px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-xs flex-1"
                      />
                      <button
                        type="button"
                        onClick={handleRequestCallback}
                        className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-1.5"
                      >
                        <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                        <span>Request Callback</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Back to Details
              </button>
              <button
                type="button"
                onClick={handleConfirmBooking}
                disabled={bookingLoading}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-md transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {bookingLoading ? 'Placing Booking...' : `Book Mechanic Now (₹${matchedService.customerPrice})`}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
