import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { SupportedLanguage, LANGUAGES } from '../lib/translations.ts';
import {
  User,
  Phone,
  Mail,
  MapPin,
  Globe,
  Bell,
  CheckCircle,
  Plus,
  Trash2,
  ShieldCheck,
  LogOut,
} from 'lucide-react';

interface CustomerProfileViewProps {
  onOpenAuth: () => void;
}

export const CustomerProfileView: React.FC<CustomerProfileViewProps> = ({ onOpenAuth }) => {
  const { language, setLanguage, languages, t } = useLanguage();
  const { user, addresses, addAddress, logout, refreshProfile } = useAuth();

  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [savedMsg, setSavedMsg] = useState(false);

  // Address modal
  const [showAddAddr, setShowAddAddr] = useState(false);
  const [label, setLabel] = useState('Home');
  const [fullAddress, setFullAddress] = useState('');
  const [city, setCity] = useState('Mumbai');
  const [state, setState] = useState('Maharashtra');
  const [pincode, setPincode] = useState('400001');

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setEmail(user.email || '');
      setPhone(user.phone || '');
    }
  }, [user]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    try {
      const res = await fetch('/api/user/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({
          name,
          email,
          phone,
          preferredLanguage: language,
        }),
      });
      if (res.ok) {
        setSavedMsg(true);
        setTimeout(() => setSavedMsg(false), 2500);
        refreshProfile();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullAddress || !city || !pincode) return;
    const res = await addAddress({
      label,
      fullAddress,
      city,
      state,
      pincode,
    });
    if (res) {
      setShowAddAddr(false);
      setFullAddress('');
    }
  };

  if (!user) {
    return (
      <div className="max-w-xl mx-auto py-16 px-4 text-center">
        <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
          <User className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-black text-slate-900 mb-2">{t('profile')}</h3>
        <p className="text-xs text-slate-500 mb-6">
          Sign in to manage your addresses, language preferences, and notification settings.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md"
        >
          {t('login')}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-10 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-700 to-blue-500 text-white flex items-center justify-center text-xl font-black uppercase shadow-md">
            {user.name ? user.name.charAt(0) : 'U'}
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900">{user.name || 'User Profile'}</h2>
            <p className="text-xs text-slate-500">{user.phone || user.email || user.uid}</p>
            <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 text-[10px] font-bold uppercase">
              Role: {user.role}
            </span>
          </div>
        </div>

        <button
          onClick={logout}
          className="px-4 py-2 rounded-xl text-red-600 hover:bg-red-50 text-xs font-bold flex items-center gap-1.5 self-start sm:self-center transition"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>{t('logout')}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Profile Details Form */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-sm">
          <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-3">
            Personal Details
          </h3>

          {savedMsg && (
            <div className="p-2.5 bg-emerald-50 text-emerald-700 text-xs rounded-xl flex items-center gap-2 border border-emerald-200">
              <CheckCircle className="w-4 h-4" />
              <span>Profile details updated successfully!</span>
            </div>
          )}

          <form onSubmit={handleUpdateProfile} className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Mobile Number</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
              />
            </div>

            {/* Language Selector in Profile (Section 2 Requirement) */}
            <div>
              <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-blue-600" />
                <span>Preferred Language (Stored in Profile)</span>
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
              >
                {languages.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.flag} {l.nativeName} ({l.name})
                  </option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition"
            >
              {t('saveChanges')}
            </button>
          </form>
        </div>

        {/* Saved Addresses (Section 4 Requirement) */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-base text-slate-900">Saved Addresses</h3>
            <button
              onClick={() => setShowAddAddr(true)}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New</span>
            </button>
          </div>

          {addresses.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              <MapPin className="w-6 h-6 mx-auto mb-1.5 opacity-40" />
              <p>No addresses saved yet.</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {addresses.map((a) => (
                <div key={a.id} className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-900">{a.label}</span>
                    <span className="text-[10px] text-slate-400">{a.city}</span>
                  </div>
                  <p className="text-slate-600">{a.fullAddress}</p>
                  <p className="text-slate-400 text-[11px] mt-0.5">{a.state} - {a.pincode}</p>
                </div>
              ))}
            </div>
          )}

          {/* Add Address Dialog */}
          {showAddAddr && (
            <form onSubmit={handleAddAddress} className="p-3.5 bg-blue-50/50 rounded-2xl border border-blue-200 space-y-2.5 text-xs">
              <span className="font-bold text-slate-900 block">Add New Address</span>
              <input
                type="text"
                placeholder="Label (e.g. Home, Office, Parents)"
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                required
              />
              <textarea
                placeholder="Full Street Address"
                value={fullAddress}
                onChange={(e) => setFullAddress(e.target.value)}
                rows={2}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                required
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="City"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                  required
                />
                <input
                  type="text"
                  placeholder="Pincode"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                  required
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddAddr(false)}
                  className="px-3 py-1 text-slate-500 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-blue-600 text-white font-bold"
                >
                  Save Address
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
