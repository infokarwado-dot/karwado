import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  ShieldAlert,
  TrendingUp,
  DollarSign,
  Users,
  Briefcase,
  CheckCircle,
  XCircle,
  AlertCircle,
  Edit,
  Plus,
  Power,
  RotateCcw,
  Search,
  Globe,
  Layers,
  Percent,
  Check,
  Save,
  ArrowRight,
  Clock,
  Sparkles,
  FileText,
} from 'lucide-react';

const INITIAL_CATEGORY_TEMPLATES = [
  { name: 'Home Services', slug: 'home-services', icon: 'Home', order: 1 },
  { name: 'Bike & Car Repair', slug: 'bike-car-repair', icon: 'Wrench', order: 2 },
  { name: 'Rent Agreement', slug: 'rent-agreement', icon: 'FileText', order: 3 },
  { name: 'Laptop & Mobile Repair', slug: 'laptop-mobile-repair', icon: 'Laptop', order: 4 },
  { name: 'Jobs & Career', slug: 'jobs-career', icon: 'Briefcase', order: 5 },
  { name: 'Cleaning Services', slug: 'cleaning-services', icon: 'Sparkles', order: 6 },
  { name: 'Packers & Movers', slug: 'packers-movers', icon: 'Truck', order: 7 },
  { name: 'Business Services', slug: 'business-services', icon: 'Building', order: 8 },
  { name: 'Document Services', slug: 'document-services', icon: 'FileCheck', order: 9 },
  { name: 'Roadside Assistance', slug: 'roadside-assistance', icon: 'Wrench', order: 10 },
  { name: 'Other Services', slug: 'other-services', icon: 'Sparkles', order: 11 },
];

const SUPPORTED_LANGS = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'Hindi (हिन्दी)' },
  { code: 'mr', label: 'Marathi (मराठी)' },
  { code: 'gu', label: 'Gujarati (ગુજરાતી)' },
  { code: 'ta', label: 'Tamil (தமிழ்)' },
  { code: 'te', label: 'Telugu (తెలుగు)' },
  { code: 'bn', label: 'Bengali (বাংলা)' },
];

export const AdminPortal: React.FC = () => {
  const { t } = useLanguage();
  const { user } = useAuth();

  const [activeTab, setActiveTab] = useState<
    'services' | 'categories' | 'pricing' | 'translations' | 'overview' | 'payouts'
  >('services');

  const [metrics, setMetrics] = useState<any | null>(null);
  const [services, setServices] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [payouts, setPayouts] = useState<any[]>([]);
  const [providers, setProviders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Search filter
  const [serviceSearch, setServiceSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  // Service Edit / Create Modal
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [editingServiceId, setEditingServiceId] = useState<number | null>(null);
  const [formServiceName, setFormServiceName] = useState('');
  const [formCategorySlug, setFormCategorySlug] = useState('1');
  const [formDescription, setFormDescription] = useState('');
  const [formPricingType, setFormPricingType] = useState<'FIXED' | 'STARTING_FROM' | 'CUSTOM_QUOTE'>('FIXED');
  const [formCustomerPrice, setFormCustomerPrice] = useState('3299');
  const [formMinPrice, setFormMinPrice] = useState('');
  const [formMaxPrice, setFormMaxPrice] = useState('');
  const [formCommissionType, setFormCommissionType] = useState<'FIXED' | 'PERCENTAGE'>('FIXED');
  const [formCommissionValue, setFormCommissionValue] = useState('600');
  const [formServiceArea, setFormServiceArea] = useState('Pan-City (All Zones)');
  const [formProviderEligibility, setFormProviderEligibility] = useState('Verified Technicians');
  const [formEstimatedDuration, setFormEstimatedDuration] = useState('60 mins');
  const [formRequiredDocs, setFormRequiredDocs] = useState('');
  const [formCustomerInstructions, setFormCustomerInstructions] = useState('');
  const [formWhatsIncluded, setFormWhatsIncluded] = useState('');
  const [formIsActive, setFormIsActive] = useState(true);
  const [serviceModalError, setServiceModalError] = useState<string | null>(null);
  const [serviceSaving, setServiceSaving] = useState(false);

  // Category Edit / Create Modal
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [editingCategoryId, setEditingCategoryId] = useState<number | null>(null);
  const [catName, setCatName] = useState('');
  const [catSlug, setCatSlug] = useState('');
  const [catIcon, setCatIcon] = useState('Sparkles');
  const [catDescription, setCatDescription] = useState('');
  const [catOrder, setCatOrder] = useState('1');
  const [catIsActive, setCatIsActive] = useState(true);
  const [catSaving, setCatSaving] = useState(false);
  const [catError, setCatError] = useState<string | null>(null);

  // Pricing & Commission Tab State (Phase 3 Section 14 & 15)
  const [selectedPricingServiceId, setSelectedPricingServiceId] = useState<number | null>(null);
  const [pricingCommissionType, setPricingCommissionType] = useState<'FIXED' | 'PERCENTAGE'>('FIXED');
  const [pricingCommissionValue, setPricingCommissionValue] = useState('600');
  const [pricingCustomerPrice, setPricingCustomerPrice] = useState('3299');
  const [pricingValidationMsg, setPricingValidationMsg] = useState<string | null>(null);
  const [pricingSaveSuccess, setPricingSaveSuccess] = useState<string | null>(null);
  const [pricingSaving, setPricingSaving] = useState(false);

  // Translations Tab State (Phase 3 Section 3)
  const [transServiceId, setTransServiceId] = useState<number | null>(null);
  const [transLang, setTransLang] = useState('hi');
  const [transName, setTransName] = useState('');
  const [transShortDesc, setTransShortDesc] = useState('');
  const [transDetailedDesc, setTransDetailedDesc] = useState('');
  const [transInstructions, setTransInstructions] = useState('');
  const [transSaving, setTransSaving] = useState(false);
  const [transMsg, setTransMsg] = useState<string | null>(null);

  useEffect(() => {
    fetchAdminData();
  }, []);

  const fetchAdminData = async () => {
    try {
      setLoading(true);
      const [mRes, sRes, cRes, pRes, provRes] = await Promise.all([
        fetch('/api/admin/metrics'),
        fetch('/api/admin/services'),
        fetch('/api/admin/categories'),
        fetch('/api/admin/payouts'),
        fetch('/api/admin/providers'),
      ]);

      if (mRes.ok) setMetrics(await mRes.json());
      if (sRes.ok) {
        const sData = await sRes.json();
        setServices(sData);
        if (sData.length > 0 && !selectedPricingServiceId) {
          const first = sData[0].service;
          setSelectedPricingServiceId(first.id);
          setPricingCustomerPrice(String(first.customerPrice));
          setPricingCommissionType((first.commissionType as any) || 'FIXED');
          setPricingCommissionValue(String(first.commissionValue || first.platformCommission));
          setTransServiceId(first.id);
        }
      }
      if (cRes.ok) setCategories(await cRes.json());
      if (pRes.ok) setPayouts(await pRes.json());
      if (provRes.ok) setProviders(await provRes.json());
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Open Service Modal for Create
  const handleOpenCreateService = () => {
    setEditingServiceId(null);
    setFormServiceName('');
    setFormCategorySlug(categories[0]?.id ? String(categories[0].id) : '1');
    setFormDescription('');
    setFormPricingType('FIXED');
    setFormCustomerPrice('1999');
    setFormMinPrice('');
    setFormMaxPrice('');
    setFormCommissionType('FIXED');
    setFormCommissionValue('400');
    setFormServiceArea('Pan-City (All Zones)');
    setFormProviderEligibility('Verified Technicians');
    setFormEstimatedDuration('60 mins');
    setFormRequiredDocs('');
    setFormCustomerInstructions('');
    setFormWhatsIncluded('Doorstep Inspection\nStandard Toolkit & Tools\n30-day Post-Service Guarantee');
    setFormIsActive(true);
    setServiceModalError(null);
    setShowServiceModal(true);
  };

  // Open Service Modal for Edit
  const handleOpenEditService = (s: any) => {
    setEditingServiceId(s.id);
    setFormServiceName(s.name);
    setFormCategorySlug(String(s.categoryId));
    setFormDescription(s.description || '');
    setFormPricingType(
      s.pricingType === 'CUSTOM_QUOTE' || s.pricingType === 'quote'
        ? 'CUSTOM_QUOTE'
        : s.pricingType === 'STARTING_FROM'
        ? 'STARTING_FROM'
        : 'FIXED'
    );
    setFormCustomerPrice(String(s.customerPrice));
    setFormMinPrice(s.minPrice ? String(s.minPrice) : '');
    setFormMaxPrice(s.maxPrice ? String(s.maxPrice) : '');
    setFormCommissionType((s.commissionType as any) || 'FIXED');
    setFormCommissionValue(String(s.commissionValue || s.platformCommission));
    setFormServiceArea(s.serviceArea || 'Pan-City (All Zones)');
    setFormProviderEligibility(s.providerEligibility || 'Verified Technicians');
    setFormEstimatedDuration(s.estimatedDuration || '60 mins');
    setFormRequiredDocs(Array.isArray(s.requiredDocuments) ? s.requiredDocuments.join(', ') : '');
    setFormCustomerInstructions(s.customerInstructions || '');
    setFormWhatsIncluded(Array.isArray(s.whatsIncluded) ? s.whatsIncluded.join('\n') : '');
    setFormIsActive(Boolean(s.isActive));
    setServiceModalError(null);
    setShowServiceModal(true);
  };

  // Save Service (Create or Update)
  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    setServiceModalError(null);

    const price = parseInt(formCustomerPrice, 10);
    const commVal = parseFloat(formCommissionValue);

    // Commission Validation (Phase 3 Section 15)
    if (formPricingType !== 'CUSTOM_QUOTE') {
      if (isNaN(price) || price < 0) {
        setServiceModalError('Customer price must be a valid positive number.');
        return;
      }
      if (isNaN(commVal) || commVal < 0) {
        setServiceModalError('Commission cannot be negative.');
        return;
      }
      if (formCommissionType === 'FIXED' && commVal > price) {
        setServiceModalError('Platform commission cannot exceed customer price.');
        return;
      }
      if (formCommissionType === 'PERCENTAGE' && (commVal <= 0 || commVal >= 100)) {
        setServiceModalError('Percentage commission must be between 1% and 99%.');
        return;
      }
    }

    setServiceSaving(true);
    try {
      const payload = {
        name: formServiceName,
        slug: formServiceName.toLowerCase().trim().replace(/[^a-z0-9-]/g, '-'),
        categoryId: parseInt(formCategorySlug, 10),
        description: formDescription,
        pricingType: formPricingType,
        customerPrice: price,
        minPrice: formMinPrice ? parseInt(formMinPrice, 10) : null,
        maxPrice: formMaxPrice ? parseInt(formMaxPrice, 10) : null,
        commissionType: formCommissionType,
        commissionValue: commVal,
        serviceArea: formServiceArea,
        providerEligibility: formProviderEligibility,
        estimatedDuration: formEstimatedDuration,
        requiredDocuments: formRequiredDocs ? formRequiredDocs.split(',').map((s) => s.trim()) : [],
        customerInstructions: formCustomerInstructions,
        whatsIncluded: formWhatsIncluded ? formWhatsIncluded.split('\n').map((s) => s.trim()).filter(Boolean) : [],
        isActive: formIsActive,
      };

      const url = editingServiceId ? `/api/admin/services/${editingServiceId}` : '/api/admin/services';
      const method = editingServiceId ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to save service.');
      }

      setShowServiceModal(false);
      fetchAdminData();
    } catch (err: any) {
      setServiceModalError(err.message || 'Error saving service.');
    } finally {
      setServiceSaving(false);
    }
  };

  // Toggle Service Active
  const handleToggleServiceActive = async (service: any) => {
    try {
      const res = await fetch(`/api/admin/services/${service.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !service.isActive }),
      });
      if (res.ok) fetchAdminData();
    } catch (e) {
      console.error(e);
    }
  };

  // Category Save (Create or Update)
  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    setCatSaving(true);
    setCatError(null);

    try {
      const url = editingCategoryId ? `/api/admin/categories/${editingCategoryId}` : '/api/admin/categories';
      const method = editingCategoryId ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: catName,
          slug: catSlug || catName.toLowerCase().replace(/[^a-z0-9]/g, '-'),
          icon: catIcon || 'Sparkles',
          description: catDescription,
          displayOrder: parseInt(catOrder, 10),
          isActive: catIsActive,
        }),
      });

      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to save category.');
      }

      setShowCategoryModal(false);
      fetchAdminData();
    } catch (err: any) {
      setCatError(err.message || 'Error saving category.');
    } finally {
      setCatSaving(false);
    }
  };

  // Quick Add Template Category (Approved Production Action)
  const handleQuickAddCategory = async (tmpl: typeof INITIAL_CATEGORY_TEMPLATES[0]) => {
    try {
      const res = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: tmpl.name,
          slug: tmpl.slug,
          icon: tmpl.icon,
          displayOrder: tmpl.order,
          isActive: true,
          description: `Professional ${tmpl.name} services by verified specialists.`,
        }),
      });
      if (res.ok) fetchAdminData();
    } catch (e) {
      console.error(e);
    }
  };

  // Save Pricing & Commission (Phase 3 Section 14 & 15)
  const handleSavePricing = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPricingServiceId) return;

    setPricingValidationMsg(null);
    setPricingSaveSuccess(null);

    const price = parseInt(pricingCustomerPrice, 10);
    const commVal = parseFloat(pricingCommissionValue);

    // Strict Validation
    if (isNaN(price) || price <= 0) {
      setPricingValidationMsg('Customer price must be a valid positive amount.');
      return;
    }
    if (isNaN(commVal) || commVal < 0) {
      setPricingValidationMsg('Platform commission cannot be negative.');
      return;
    }
    if (pricingCommissionType === 'FIXED' && commVal > price) {
      setPricingValidationMsg('Platform commission cannot exceed customer price.');
      return;
    }
    if (pricingCommissionType === 'PERCENTAGE' && (commVal <= 0 || commVal >= 100)) {
      setPricingValidationMsg('Percentage commission must be between 1% and 99%.');
      return;
    }

    setPricingSaving(true);
    try {
      const res = await fetch(`/api/admin/services/${selectedPricingServiceId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerPrice: price,
          commissionType: pricingCommissionType,
          commissionValue: commVal,
        }),
      });

      const d = await res.json();
      if (!res.ok) throw new Error(d.error || 'Failed to update commission.');

      setPricingSaveSuccess('New commission saved. Applies to future bookings only.');
      fetchAdminData();
    } catch (err: any) {
      setPricingValidationMsg(err.message || 'Error updating commission.');
    } finally {
      setPricingSaving(false);
    }
  };

  // Save Service Translation (Phase 3 Section 3)
  const handleSaveTranslation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transServiceId || !transName) return;

    setTransSaving(true);
    setTransMsg(null);
    try {
      const res = await fetch(`/api/admin/services/${transServiceId}/translations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          languageCode: transLang,
          name: transName,
          shortDescription: transShortDesc,
          detailedDescription: transDetailedDesc,
          customerInstructions: transInstructions,
        }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || 'Failed to save translation');
      setTransMsg(`✓ Translation for ${transLang.toUpperCase()} saved successfully.`);
      fetchAdminData();
    } catch (err: any) {
      setTransMsg(`Error: ${err.message}`);
    } finally {
      setTransSaving(false);
    }
  };

  // Payout actions
  const handlePayoutAction = async (payoutId: number, status: 'completed' | 'rejected') => {
    try {
      const res = await fetch(`/api/admin/payouts/${payoutId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          bankReference: status === 'completed' ? `UTR-${Date.now()}` : null,
          rejectionReason: status === 'rejected' ? 'KYC details mismatch' : null,
        }),
      });
      if (res.ok) fetchAdminData();
    } catch (e) {
      console.error(e);
    }
  };

  // Provider KYC verification
  const handleVerifyProvider = async (providerId: number) => {
    try {
      const res = await fetch(`/api/admin/providers/${providerId}/verify`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kycStatus: 'verified' }),
      });
      if (res.ok) fetchAdminData();
    } catch (e) {
      console.error(e);
    }
  };

  // Computed Pricing Preview for Section 14
  const selectedServiceObj = services.find((item) => item.service.id === selectedPricingServiceId)?.service;
  const previewCustPrice = parseInt(pricingCustomerPrice, 10) || 0;
  const previewCommVal = parseFloat(pricingCommissionValue) || 0;
  let previewPlatformFee = 0;
  if (pricingCommissionType === 'FIXED') {
    previewPlatformFee = previewCommVal;
  } else {
    previewPlatformFee = Math.round((previewCustPrice * previewCommVal) / 100);
  }
  const previewProviderAmt = Math.max(0, previewCustPrice - previewPlatformFee);

  // Filtered Services List
  const filteredServices = services.filter((item) => {
    const s = item.service;
    const c = item.category;
    const matchCat = categoryFilter === 'all' || String(s.categoryId) === categoryFilter;
    const matchSearch =
      serviceSearch.trim() === '' ||
      s.name.toLowerCase().includes(serviceSearch.toLowerCase()) ||
      (c?.name && c.name.toLowerCase().includes(serviceSearch.toLowerCase()));
    return matchCat && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-400/30 uppercase tracking-wider mb-2">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>Real Database Engine</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black">Admin Governance & Pricing</h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Database-driven service categories, server-side pricing engine, immutable financial snapshots & multi-language controls.
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => {
              setEditingCategoryId(null);
              setCatName('');
              setCatSlug('');
              setCatIcon('Sparkles');
              setCatDescription('');
              setCatOrder(String(categories.length + 1));
              setCatIsActive(true);
              setCatError(null);
              setShowCategoryModal(true);
            }}
            className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-1.5 border border-white/20 transition cursor-pointer"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Add Category</span>
          </button>

          <button
            onClick={handleOpenCreateService}
            className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Service</span>
          </button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-slate-200 overflow-x-auto gap-2 text-xs font-bold text-slate-600">
        {[
          { id: 'services', label: 'Services Catalog', count: services.length },
          { id: 'categories', label: 'Service Categories', count: categories.length },
          { id: 'pricing', label: 'Pricing & Commission', icon: DollarSign },
          { id: 'translations', label: 'Multi-Language Services', icon: Globe },
          { id: 'overview', label: 'Financial Metrics' },
          { id: 'payouts', label: 'Payouts & KYC', count: payouts.filter((p) => p.payout.status === 'pending').length },
        ].map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-3 px-3.5 border-b-2 flex items-center gap-2 whitespace-nowrap transition cursor-pointer ${
                isActive
                  ? 'border-blue-600 text-blue-600 font-extrabold'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] ${
                    isActive ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ---------------------------------------------------------------- */}
      {/* TAB 1: SERVICES CATALOG (Phase 3 Section 2 & 16) */}
      {/* ---------------------------------------------------------------- */}
      {activeTab === 'services' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-5 shadow-sm">
          {/* Controls: Search & Category Filter */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div className="flex flex-1 items-center gap-3">
              <div className="relative flex-1 max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search service by name or category..."
                  value={serviceSearch}
                  onChange={(e) => setServiceSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 bg-white"
                />
              </div>

              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 bg-white"
              >
                <option value="all">All Categories</option>
                {categories.map((c) => (
                  <option key={c.id} value={String(c.id)}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleOpenCreateService}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Service</span>
            </button>
          </div>

          {/* Section 16: Table with Service, Category, Price, Commission, Provider Amount, Status, Last Updated, Actions */}
          {filteredServices.length === 0 ? (
            <div className="text-center py-16 bg-slate-50 rounded-2xl border border-slate-200 p-8 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-200 text-slate-500 flex items-center justify-center mx-auto mb-2">
                <Briefcase className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-slate-900">No services created yet.</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Define services with base prices and commission rules. No mock or fake records are inserted automatically.
              </p>
              <button
                onClick={handleOpenCreateService}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-md transition"
              >
                Create First Service
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-3">Service</th>
                    <th className="py-3 px-3">Category</th>
                    <th className="py-3 px-3">Price Type</th>
                    <th className="py-3 px-3">Customer Price</th>
                    <th className="py-3 px-3">Commission</th>
                    <th className="py-3 px-3">Provider Amount</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 px-3">Last Updated</th>
                    <th className="py-3 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredServices.map((item) => {
                    const s = item.service;
                    const c = item.category;
                    const isQuote = s.pricingType === 'CUSTOM_QUOTE' || s.pricingType === 'quote';

                    return (
                      <tr key={s.id} className="hover:bg-slate-50/80 transition">
                        <td className="py-3 px-3 font-extrabold text-slate-900">
                          <div>
                            <span className="block">{s.name}</span>
                            <span className="text-[10px] text-slate-400 font-normal font-mono">
                              {s.slug}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-slate-600 font-medium">
                          {c?.name || 'General'}
                        </td>
                        <td className="py-3 px-3">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                              isQuote
                                ? 'bg-purple-50 text-purple-700 border border-purple-200'
                                : s.pricingType === 'STARTING_FROM'
                                ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                : 'bg-blue-50 text-blue-700 border border-blue-200'
                            }`}
                          >
                            {isQuote ? 'Quote' : s.pricingType || 'Fixed'}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-black text-slate-900">
                          {isQuote ? (
                            <span className="text-slate-400 font-semibold italic text-[11px]">
                              Quote upon inspection
                            </span>
                          ) : (
                            `₹${s.customerPrice}`
                          )}
                        </td>
                        <td className="py-3 px-3 font-bold text-amber-700">
                          {isQuote ? '—' : `₹${s.platformCommission}`}
                        </td>
                        <td className="py-3 px-3 font-bold text-emerald-700">
                          {isQuote ? '—' : `₹${s.providerAmount}`}
                        </td>
                        <td className="py-3 px-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              s.isActive
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-slate-100 text-slate-500'
                            }`}
                          >
                            {s.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-slate-400 text-[11px]">
                          {s.updatedAt
                            ? new Date(s.updatedAt).toLocaleDateString()
                            : new Date(s.createdAt).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-3 text-right space-x-1.5 whitespace-nowrap">
                          <button
                            onClick={() => handleOpenEditService(s)}
                            className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 font-bold transition cursor-pointer"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => {
                              setSelectedPricingServiceId(s.id);
                              setPricingCustomerPrice(String(s.customerPrice));
                              setPricingCommissionType((s.commissionType as any) || 'FIXED');
                              setPricingCommissionValue(String(s.commissionValue || s.platformCommission));
                              setActiveTab('pricing');
                            }}
                            className="px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 hover:bg-amber-100 font-bold transition cursor-pointer"
                          >
                            Commission
                          </button>
                          <button
                            onClick={() => handleToggleServiceActive(s)}
                            className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                              s.isActive
                                ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                            }`}
                          >
                            {s.isActive ? 'Deactivate' : 'Activate'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* TAB 2: SERVICE CATEGORY SYSTEM (Phase 3 Section 1) */}
      {/* ---------------------------------------------------------------- */}
      {activeTab === 'categories' && (
        <div className="space-y-6">
          {/* Quick-add Initial Approved Categories Template */}
          <div className="bg-blue-50/70 rounded-3xl border border-blue-200/80 p-6 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-sm text-blue-950">
                  Section 1 Approved Production Categories
                </h3>
                <p className="text-xs text-blue-800/80">
                  Initial category specifications. Click any category to add it directly to the real database without fake records.
                </p>
              </div>
              <span className="text-xs font-bold text-blue-700">{categories.length} in Database</span>
            </div>

            <div className="flex flex-wrap gap-2 pt-1">
              {INITIAL_CATEGORY_TEMPLATES.map((tmpl) => {
                const alreadyExists = categories.some((c) => c.slug === tmpl.slug);
                return (
                  <button
                    key={tmpl.slug}
                    onClick={() => !alreadyExists && handleQuickAddCategory(tmpl)}
                    disabled={alreadyExists}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                      alreadyExists
                        ? 'bg-emerald-100/70 text-emerald-800 border border-emerald-200 cursor-default'
                        : 'bg-white hover:bg-blue-600 hover:text-white text-slate-800 border border-blue-200 shadow-sm cursor-pointer'
                    }`}
                  >
                    <span>{alreadyExists ? '✓' : '+'}</span>
                    <span>{tmpl.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Database Categories Table */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">
                Database-Driven Categories
              </h3>
              <button
                onClick={() => {
                  setEditingCategoryId(null);
                  setCatName('');
                  setCatSlug('');
                  setCatIcon('Sparkles');
                  setCatDescription('');
                  setCatOrder(String(categories.length + 1));
                  setCatIsActive(true);
                  setCatError(null);
                  setShowCategoryModal(true);
                }}
                className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Create New Category</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 uppercase text-[10px] tracking-wider">
                    <th className="py-2.5 px-3">Order</th>
                    <th className="py-2.5 px-3">Icon</th>
                    <th className="py-2.5 px-3">Category Name</th>
                    <th className="py-2.5 px-3">Slug</th>
                    <th className="py-2.5 px-3">Description</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {categories.map((cat) => (
                    <tr key={cat.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3 px-3 font-mono font-bold text-slate-500">
                        {cat.displayOrder || 0}
                      </td>
                      <td className="py-3 px-3 font-semibold text-blue-700">
                        {cat.icon || 'Sparkles'}
                      </td>
                      <td className="py-3 px-3 font-extrabold text-slate-900">{cat.name}</td>
                      <td className="py-3 px-3 font-mono text-slate-500">{cat.slug}</td>
                      <td className="py-3 px-3 text-slate-600 max-w-xs truncate">
                        {cat.description || '—'}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            cat.isActive
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-slate-100 text-slate-500'
                          }`}
                        >
                          {cat.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          onClick={() => {
                            setEditingCategoryId(cat.id);
                            setCatName(cat.name);
                            setCatSlug(cat.slug);
                            setCatIcon(cat.icon || 'Sparkles');
                            setCatDescription(cat.description || '');
                            setCatOrder(String(cat.displayOrder || 0));
                            setCatIsActive(Boolean(cat.isActive));
                            setCatError(null);
                            setShowCategoryModal(true);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 font-bold"
                        >
                          Edit
                        </button>
                        <button
                          onClick={async () => {
                            await fetch(`/api/admin/categories/${cat.id}`, {
                              method: 'PUT',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ isActive: !cat.isActive }),
                            });
                            fetchAdminData();
                          }}
                          className={`px-2.5 py-1 rounded-lg font-bold ${
                            cat.isActive
                              ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                          }`}
                        >
                          {cat.isActive ? 'Deactivate' : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* TAB 3: PRICING & COMMISSION ENGINE (Phase 3 Section 14 & 15) */}
      {/* ---------------------------------------------------------------- */}
      {activeTab === 'pricing' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Service Selector & Search */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-sm lg:col-span-1">
            <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <Search className="w-4 h-4 text-blue-600" />
              <span>Select Service to Configure</span>
            </h3>
            <div className="relative">
              <input
                type="text"
                placeholder="Search service..."
                value={serviceSearch}
                onChange={(e) => setServiceSearch(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white"
              />
            </div>

            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {filteredServices.map((item) => {
                const s = item.service;
                const isSelected = s.id === selectedPricingServiceId;
                return (
                  <button
                    key={s.id}
                    onClick={() => {
                      setSelectedPricingServiceId(s.id);
                      setPricingCustomerPrice(String(s.customerPrice));
                      setPricingCommissionType((s.commissionType as any) || 'FIXED');
                      setPricingCommissionValue(String(s.commissionValue || s.platformCommission));
                      setPricingValidationMsg(null);
                      setPricingSaveSuccess(null);
                    }}
                    className={`w-full p-3 rounded-2xl border text-left transition cursor-pointer ${
                      isSelected
                        ? 'bg-blue-50 border-blue-600 shadow-sm'
                        : 'bg-white hover:bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <span className="font-extrabold text-xs text-slate-900 block">{s.name}</span>
                      <span className="font-black text-slate-900 text-xs">₹{s.customerPrice}</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                      <span>KARWA DO: ₹{s.platformCommission}</span>
                      <span>Provider: ₹{s.providerAmount}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Pricing Calculation & Validation Editor (Section 14 & 15) */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-sm lg:col-span-2">
            <div>
              <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider block mb-1">
                Phase 3 Pricing Engine
              </span>
              <h3 className="text-xl font-black text-slate-900">
                Commission Configuration: {selectedServiceObj?.name || 'Select a Service'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Configure platform commission percentage or fixed fee. Live breakdown updates automatically.
              </p>
            </div>

            {pricingValidationMsg && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{pricingValidationMsg}</span>
              </div>
            )}
            {pricingSaveSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>{pricingSaveSuccess}</span>
              </div>
            )}

            <form onSubmit={handleSavePricing} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Customer Price (₹) *
                  </label>
                  <input
                    type="number"
                    value={pricingCustomerPrice}
                    onChange={(e) => setPricingCustomerPrice(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-black text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Commission Type *
                  </label>
                  <select
                    value={pricingCommissionType}
                    onChange={(e) => setPricingCommissionType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-bold"
                  >
                    <option value="FIXED">Fixed Amount (₹)</option>
                    <option value="PERCENTAGE">Percentage (%)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Commission Value *
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={pricingCommissionValue}
                    onChange={(e) => setPricingCommissionValue(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-bold text-amber-700"
                    placeholder={pricingCommissionType === 'FIXED' ? 'e.g. 600' : 'e.g. 20'}
                    required
                  />
                </div>
              </div>

              {/* Section 14: Interactive Live Preview Grid */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                  Live Financial Preview
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-400 uppercase block">
                      Customer Pays
                    </span>
                    <span className="text-xl font-black text-slate-900 block mt-0.5">
                      ₹{previewCustPrice}
                    </span>
                  </div>

                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                    <span className="text-[10px] font-bold text-amber-800 uppercase block">
                      KARWA DO Receives
                    </span>
                    <span className="text-xl font-black text-amber-700 block mt-0.5">
                      ₹{previewPlatformFee}
                    </span>
                    {pricingCommissionType === 'PERCENTAGE' && (
                      <span className="text-[10px] text-amber-600 block">({previewCommVal}%)</span>
                    )}
                  </div>

                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                    <span className="text-[10px] font-bold text-emerald-800 uppercase block">
                      Provider Receives
                    </span>
                    <span className="text-xl font-black text-emerald-700 block mt-0.5">
                      ₹{previewProviderAmt}
                    </span>
                  </div>
                </div>

                {/* Section 14 Mandatory Notice */}
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 shrink-0" />
                  <span className="font-semibold">
                    New commission applies to future bookings only. Existing bookings retain their immutable financial snapshot.
                  </span>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={pricingSaving || !selectedPricingServiceId}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-md transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{pricingSaving ? 'Saving...' : 'Save New Commission'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* TAB 4: MULTI-LANGUAGE SERVICES (Phase 3 Section 3) */}
      {/* ---------------------------------------------------------------- */}
      {activeTab === 'translations' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold mb-2">
              <Globe className="w-3.5 h-3.5" />
              <span>Multi-Language Services Engine</span>
            </div>
            <h3 className="text-xl font-black text-slate-900">Translate Service Metadata</h3>
            <p className="text-xs text-slate-500 mt-1">
              Configure localized names, short descriptions, and customer instructions across 7 Indian languages: English, Hindi, Marathi, Gujarati, Tamil, Telugu, and Bengali.
            </p>
          </div>

          {transMsg && (
            <div className="p-3 bg-blue-50 border border-blue-200 text-blue-900 text-xs rounded-xl font-semibold">
              {transMsg}
            </div>
          )}

          <form onSubmit={handleSaveTranslation} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Select Service *
                </label>
                <select
                  value={transServiceId || ''}
                  onChange={(e) => setTransServiceId(parseInt(e.target.value, 10))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-semibold"
                >
                  {services.map((item) => (
                    <option key={item.service.id} value={item.service.id}>
                      {item.service.name} ({item.category?.name || 'General'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Target Language *
                </label>
                <select
                  value={transLang}
                  onChange={(e) => setTransLang(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-bold"
                >
                  {SUPPORTED_LANGS.map((l) => (
                    <option key={l.code} value={l.code}>
                      {l.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Translated Service Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. एसी रिपेयर / एअर कंडिशनर दुरुस्ती"
                  value={transName}
                  onChange={(e) => setTransName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-bold text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Short Description
                </label>
                <input
                  type="text"
                  placeholder="Summary shown on catalog cards..."
                  value={transShortDesc}
                  onChange={(e) => setTransShortDesc(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Detailed Description
                </label>
                <textarea
                  rows={3}
                  placeholder="Full service overview..."
                  value={transDetailedDesc}
                  onChange={(e) => setTransDetailedDesc(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Customer Instructions
                </label>
                <textarea
                  rows={2}
                  placeholder="Specific instructions in localized language..."
                  value={transInstructions}
                  onChange={(e) => setTransInstructions(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                />
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={transSaving || !transName}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition disabled:opacity-50 cursor-pointer"
              >
                {transSaving ? 'Saving Translation...' : 'Save Translation'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* TAB 5: FINANCIAL METRICS OVERVIEW */}
      {/* ---------------------------------------------------------------- */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Platform GMV
              </span>
              <span className="text-2xl font-black text-slate-950 block mt-1">
                ₹{metrics?.gmv || 0}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Real customer payments</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                KARWA DO Net Revenue
              </span>
              <span className="text-2xl font-black text-emerald-700 block mt-1">
                ₹{metrics?.karwadoRevenue || 0}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Retained platform fees</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Provider Payable
              </span>
              <span className="text-2xl font-black text-blue-700 block mt-1">
                ₹{metrics?.providerPayable || 0}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Owed for completed jobs</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Pending Payouts
              </span>
              <span className="text-2xl font-black text-amber-600 block mt-1">
                ₹{metrics?.pendingPayoutsAmount || 0}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                {metrics?.pendingPayoutsCount || 0} withdrawal requests
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* TAB 6: PAYOUTS & KYC */}
      {/* ---------------------------------------------------------------- */}
      {activeTab === 'payouts' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-sm">
            <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-3">
              Provider Payout Requests ({payouts.length})
            </h3>
            {payouts.length === 0 ? (
              <p className="text-slate-400 text-xs py-8 text-center">No payout requests pending.</p>
            ) : (
              <div className="space-y-3">
                {payouts.map((item) => {
                  const p = item.payout;
                  const prov = item.provider;
                  return (
                    <div key={p.id} className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/50 text-xs space-y-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="font-bold text-slate-900 block">{prov?.businessName || 'Provider'}</span>
                          <span className="text-[10px] text-slate-400">
                            Requested: {new Date(p.requestedAt).toLocaleDateString()}
                          </span>
                        </div>
                        <span className="text-base font-black text-slate-900">₹{p.amount}</span>
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase bg-amber-100 text-amber-800">
                          {p.status}
                        </span>
                        {p.status === 'pending' && (
                          <div className="flex gap-1.5">
                            <button
                              onClick={() => handlePayoutAction(p.id, 'rejected')}
                              className="px-2.5 py-1 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 font-bold"
                            >
                              Reject
                            </button>
                            <button
                              onClick={() => handlePayoutAction(p.id, 'completed')}
                              className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                            >
                              Approve Transfer
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-sm">
            <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-3">
              Registered Providers ({providers.length})
            </h3>
            {providers.length === 0 ? (
              <p className="text-slate-400 text-xs py-8 text-center">No providers registered yet.</p>
            ) : (
              <div className="space-y-3">
                {providers.map((item) => {
                  const prov = item.provider;
                  const u = item.user;
                  return (
                    <div key={prov.id} className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/50 text-xs flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900 block">{prov.businessName}</span>
                        <span className="text-slate-500 text-[11px]">{u?.email || u?.phone || 'Partner'} • {prov.kycDocumentType}</span>
                      </div>
                      <div>
                        {prov.kycStatus === 'verified' ? (
                          <span className="text-emerald-700 font-bold text-xs bg-emerald-50 px-2 py-1 rounded-lg">
                            ✓ Verified
                          </span>
                        ) : (
                          <button
                            onClick={() => handleVerifyProvider(prov.id)}
                            className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold"
                          >
                            Verify KYC
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* MODAL: CREATE / EDIT SERVICE (Phase 3 Section 2) */}
      {/* ---------------------------------------------------------------- */}
      {showServiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-8 max-w-2xl w-full space-y-4 my-8 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div>
              <span className="text-[10px] font-bold text-blue-600 uppercase">
                {editingServiceId ? 'Edit Service' : 'Create New Service'}
              </span>
              <h3 className="text-xl font-black text-slate-900">
                {editingServiceId ? formServiceName : 'New Catalog Service'}
              </h3>
            </div>

            {serviceModalError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{serviceModalError}</span>
              </div>
            )}

            <form onSubmit={handleSaveService} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Service Name *</label>
                  <input
                    type="text"
                    value={formServiceName}
                    onChange={(e) => setFormServiceName(e.target.value)}
                    placeholder="e.g. AC Repair"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Category *</label>
                  <select
                    value={formCategorySlug}
                    onChange={(e) => setFormCategorySlug(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={String(c.id)}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Detailed customer-facing description..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              {/* Price Type & Pricing Configuration */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Price Type *</label>
                  <select
                    value={formPricingType}
                    onChange={(e) => setFormPricingType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-bold"
                  >
                    <option value="FIXED">FIXED</option>
                    <option value="STARTING_FROM">STARTING_FROM</option>
                    <option value="CUSTOM_QUOTE">CUSTOM_QUOTE</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Customer Price (₹) {formPricingType === 'CUSTOM_QUOTE' ? '(N/A)' : '*'}
                  </label>
                  <input
                    type="number"
                    value={formCustomerPrice}
                    onChange={(e) => setFormCustomerPrice(e.target.value)}
                    disabled={formPricingType === 'CUSTOM_QUOTE'}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-black text-slate-900 disabled:opacity-40"
                    required={formPricingType !== 'CUSTOM_QUOTE'}
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Service Area</label>
                  <input
                    type="text"
                    value={formServiceArea}
                    onChange={(e) => setFormServiceArea(e.target.value)}
                    placeholder="Pan-City / Local"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  />
                </div>
              </div>

              {/* Min & Max Price for STARTING_FROM */}
              {formPricingType === 'STARTING_FROM' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Minimum Price (₹)</label>
                    <input
                      type="number"
                      value={formMinPrice}
                      onChange={(e) => setFormMinPrice(e.target.value)}
                      placeholder="Optional"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Maximum Price (₹)</label>
                    <input
                      type="number"
                      value={formMaxPrice}
                      onChange={(e) => setFormMaxPrice(e.target.value)}
                      placeholder="Optional"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300"
                    />
                  </div>
                </div>
              )}

              {/* Platform Commission Controls */}
              {formPricingType !== 'CUSTOM_QUOTE' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200">
                  <div>
                    <label className="block font-bold text-amber-900 mb-1">Commission Type *</label>
                    <select
                      value={formCommissionType}
                      onChange={(e) => setFormCommissionType(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl border border-amber-300 bg-white font-bold"
                    >
                      <option value="FIXED">FIXED (Amount in ₹)</option>
                      <option value="PERCENTAGE">PERCENTAGE (%)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-amber-900 mb-1">Commission Value *</label>
                    <input
                      type="number"
                      step="any"
                      value={formCommissionValue}
                      onChange={(e) => setFormCommissionValue(e.target.value)}
                      placeholder={formCommissionType === 'FIXED' ? '₹600' : '20%'}
                      className="w-full px-3 py-2 rounded-xl border border-amber-300 bg-white font-black text-amber-800"
                      required
                    />
                  </div>
                </div>
              )}

              {/* Service Operations Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Estimated Duration</label>
                  <input
                    type="text"
                    value={formEstimatedDuration}
                    onChange={(e) => setFormEstimatedDuration(e.target.value)}
                    placeholder="e.g. 60 mins"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Provider Eligibility</label>
                  <input
                    type="text"
                    value={formProviderEligibility}
                    onChange={(e) => setFormProviderEligibility(e.target.value)}
                    placeholder="e.g. KYC Verified Technicians"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">What's Included (1 per line)</label>
                <textarea
                  rows={2}
                  value={formWhatsIncluded}
                  onChange={(e) => setFormWhatsIncluded(e.target.value)}
                  placeholder="Doorstep inspection&#10;Basic tools included"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Customer Instructions</label>
                <input
                  type="text"
                  value={formCustomerInstructions}
                  onChange={(e) => setFormCustomerInstructions(e.target.value)}
                  placeholder="Special instructions shown to customer"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="srvIsActive"
                  checked={formIsActive}
                  onChange={(e) => setFormIsActive(e.target.checked)}
                  className="rounded border-slate-300 w-4 h-4 text-blue-600"
                />
                <label htmlFor="srvIsActive" className="font-bold text-slate-700">
                  Service is Active in Catalog
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowServiceModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={serviceSaving}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition disabled:opacity-50 cursor-pointer"
                >
                  {serviceSaving ? 'Saving...' : editingServiceId ? 'Update Service' : 'Create Service'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* MODAL: CREATE / EDIT CATEGORY (Phase 3 Section 1) */}
      {/* ---------------------------------------------------------------- */}
      {showCategoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-8 max-w-md w-full space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div>
              <span className="text-[10px] font-bold text-blue-600 uppercase">Category Management</span>
              <h3 className="text-xl font-black text-slate-900">
                {editingCategoryId ? 'Edit Category' : 'Create Category'}
              </h3>
            </div>

            {catError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl">
                {catError}
              </div>
            )}

            <form onSubmit={handleSaveCategory} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Category Name *</label>
                <input
                  type="text"
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  placeholder="e.g. Home Services"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Slug *</label>
                <input
                  type="text"
                  value={catSlug}
                  onChange={(e) => setCatSlug(e.target.value)}
                  placeholder="e.g. home-services"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Icon Identifier</label>
                  <input
                    type="text"
                    value={catIcon}
                    onChange={(e) => setCatIcon(e.target.value)}
                    placeholder="Home, Wrench, etc."
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Display Order</label>
                  <input
                    type="number"
                    value={catOrder}
                    onChange={(e) => setCatOrder(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Description</label>
                <input
                  type="text"
                  value={catDescription}
                  onChange={(e) => setCatDescription(e.target.value)}
                  placeholder="Brief description..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="catActive"
                  checked={catIsActive}
                  onChange={(e) => setCatIsActive(e.target.checked)}
                  className="rounded border-slate-300 w-4 h-4 text-blue-600"
                />
                <label htmlFor="catActive" className="font-bold text-slate-700">
                  Category is Active
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCategoryModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={catSaving}
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md disabled:opacity-50"
                >
                  {catSaving ? 'Saving...' : 'Save Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
