import React from 'react';
import { Home, CalendarCheck, Briefcase, Wallet, User, ShieldAlert } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAuth: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab, onOpenAuth }) => {
  const { t } = useLanguage();
  const { user } = useAuth();

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 shadow-lg safe-area-pb">
      <div className="grid grid-cols-5 gap-1 items-center text-center">
        {/* Tab 1: Home / Main */}
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            activeTab === 'home' ? 'text-blue-600 font-bold' : 'text-slate-500'
          }`}
        >
          <Home className={`w-5 h-5 ${activeTab === 'home' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">{t('home')}</span>
        </button>

        {/* Tab 2: Bookings (or Provider Jobs if provider) */}
        {user?.role === 'provider' ? (
          <button
            onClick={() => setActiveTab('provider-portal')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'provider-portal' ? 'text-amber-600 font-bold' : 'text-slate-500'
            }`}
          >
            <Briefcase className={`w-5 h-5 ${activeTab === 'provider-portal' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            <span className="text-[10px] mt-0.5">Jobs</span>
          </button>
        ) : (
          <button
            onClick={() => setActiveTab('bookings')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'bookings' ? 'text-blue-600 font-bold' : 'text-slate-500'
            }`}
          >
            <CalendarCheck className={`w-5 h-5 ${activeTab === 'bookings' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            <span className="text-[10px] mt-0.5">{t('bookings')}</span>
          </button>
        )}

        {/* Tab 3: Careers / Jobs Portal */}
        <button
          onClick={() => setActiveTab('jobs')}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            activeTab === 'jobs' ? 'text-blue-600 font-bold' : 'text-slate-500'
          }`}
        >
          <Briefcase className={`w-5 h-5 ${activeTab === 'jobs' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">{t('jobs')}</span>
        </button>

        {/* Tab 4: Wallet or Admin Panel if admin */}
        {user?.role === 'admin' ? (
          <button
            onClick={() => setActiveTab('admin-panel')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'admin-panel' ? 'text-amber-700 font-bold' : 'text-slate-500'
            }`}
          >
            <ShieldAlert className={`w-5 h-5 ${activeTab === 'admin-panel' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            <span className="text-[10px] mt-0.5">Admin</span>
          </button>
        ) : (
          <button
            onClick={() => {
              if (user?.role === 'provider') setActiveTab('provider-portal');
              else setActiveTab('wallet');
            }}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'wallet' ? 'text-blue-600 font-bold' : 'text-slate-500'
            }`}
          >
            <Wallet className={`w-5 h-5 ${activeTab === 'wallet' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            <span className="text-[10px] mt-0.5">{t('wallet')}</span>
          </button>
        )}

        {/* Tab 5: Profile / Login */}
        <button
          onClick={() => {
            if (!user) onOpenAuth();
            else setActiveTab('profile');
          }}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            activeTab === 'profile' ? 'text-blue-600 font-bold' : 'text-slate-500'
          }`}
        >
          <User className={`w-5 h-5 ${activeTab === 'profile' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">{user ? t('profile') : t('login')}</span>
        </button>
      </div>
    </div>
  );
};
