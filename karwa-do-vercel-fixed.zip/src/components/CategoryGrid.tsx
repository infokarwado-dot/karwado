import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { Service, ServiceCategory } from '../types/index.ts';
import {
  Home,
  Wrench,
  FileText,
  Laptop,
  Briefcase,
  Sparkles,
  Truck,
  Building,
  FileCheck,
  ChevronRight,
  Clock,
  ShieldCheck,
  Search,
} from 'lucide-react';

interface CategoryGridProps {
  onSelectService: (service: Service) => void;
  onViewServiceDetails?: (service: Service) => void;
  onOpenRentAgreement: () => void;
  onOpenRoadside: () => void;
  onOpenBikeRepair?: () => void;
  onOpenJobs: () => void;
}

const ICON_MAP: Record<string, any> = {
  Home,
  Wrench,
  FileText,
  Laptop,
  Briefcase,
  Sparkles,
  Truck,
  Building,
  FileCheck,
};

export const CategoryGrid: React.FC<CategoryGridProps> = ({
  onSelectService,
  onViewServiceDetails,
  onOpenRentAgreement,
  onOpenRoadside,
  onOpenBikeRepair,
  onOpenJobs,
}) => {
  const { t } = useLanguage();
  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async (retries = 3) => {
    setLoading(true);
    setFetchError(null);

    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        const [catRes, servRes] = await Promise.all([
          fetch('/api/categories'),
          fetch('/api/services'),
        ]);

        if (catRes.ok && servRes.ok) {
          const catData = await catRes.json();
          const servData = await servRes.json();
          setCategories(catData);
          setServices(servData);
          setLoading(false);
          return;
        }
      } catch (err) {
        if (attempt === retries) {
          console.error('Error fetching catalog after retries:', err);
          setFetchError('Unable to load service catalog right now. Please check your connection.');
        } else {
          // Wait 600ms before retrying
          await new Promise((resolve) => setTimeout(resolve, 600));
        }
      }
    }
    setLoading(false);
  };

  const filteredServices = services.filter((s) => {
    const matchesCategory =
      selectedCategorySlug === 'all' || s.categorySlug === selectedCategorySlug;
    const matchesSearch =
      searchQuery.trim() === '' ||
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.description && s.description.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleCategoryClick = (slug: string) => {
    if (slug === 'rent-agreement') {
      onOpenRentAgreement();
      return;
    }
    if (slug === 'bike-car-repair') {
      if (onOpenBikeRepair) {
        onOpenBikeRepair();
      } else {
        onOpenRoadside();
      }
      return;
    }
    if (slug === 'jobs-career') {
      onOpenJobs();
      return;
    }
    setSelectedCategorySlug(slug);
  };

  return (
    <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            {t('popularCategories')}
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Choose a verified service category or explore services configured in the platform database.
          </p>
        </div>

        {/* Search within catalog */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search all services..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        </div>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4 mb-10">
        <button
          onClick={() => setSelectedCategorySlug('all')}
          className={`flex items-center gap-3 p-3.5 rounded-2xl border text-left transition-all ${
            selectedCategorySlug === 'all'
              ? 'bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-600/20'
              : 'bg-white border-slate-200/90 hover:border-slate-300 text-slate-800 hover:bg-slate-50'
          }`}
        >
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              selectedCategorySlug === 'all'
                ? 'bg-white/20 text-white'
                : 'bg-blue-50 text-blue-600'
            }`}
          >
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="font-bold text-xs sm:text-sm">{t('allCategories')}</div>
            <div
              className={`text-[10px] ${
                selectedCategorySlug === 'all' ? 'text-blue-100' : 'text-slate-400'
              }`}
            >
              All Services
            </div>
          </div>
        </button>

        {categories.map((cat) => {
          const IconComponent = ICON_MAP[cat.icon] || Sparkles;
          const isSelected = selectedCategorySlug === cat.slug;

          return (
            <button
              key={cat.id}
              onClick={() => handleCategoryClick(cat.slug)}
              className={`flex items-center gap-3 p-3.5 rounded-2xl border text-left transition-all ${
                isSelected
                  ? 'bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-600/20'
                  : 'bg-white border-slate-200/90 hover:border-slate-300 text-slate-800 hover:bg-slate-50'
              }`}
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'
                }`}
              >
                <IconComponent className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs sm:text-sm truncate">{cat.name}</div>
                <div
                  className={`text-[10px] truncate ${
                    isSelected ? 'text-blue-100' : 'text-slate-400'
                  }`}
                >
                  Direct Booking
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Services List for Category */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-extrabold text-slate-900">
            {selectedCategorySlug === 'all'
              ? 'Available Services'
              : categories.find((c) => c.slug === selectedCategorySlug)?.name || 'Services'}
          </h3>
          <span className="text-xs text-slate-500 font-semibold">
            {filteredServices.length} {filteredServices.length === 1 ? 'service' : 'services'} available
          </span>
        </div>

        {fetchError ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-red-200 p-8 space-y-3">
            <p className="text-red-700 font-semibold text-sm">{fetchError}</p>
            <button
              onClick={() => fetchData()}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow"
            >
              Try Again
            </button>
          </div>
        ) : loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-48 bg-slate-100 rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : filteredServices.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-8">
            <p className="text-slate-600 font-semibold">{t('noDataYet')}</p>
            <p className="text-xs text-slate-400 mt-1">No services match the current filter.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredServices.map((service) => {
              const isQuote =
                service.pricingType === 'CUSTOM_QUOTE' ||
                service.pricingType === 'quote' ||
                (service as any).pricing_type === 'CUSTOM_QUOTE';

              return (
                <div
                  key={service.id}
                  className="group flex flex-col justify-between bg-white rounded-2xl border border-slate-200/90 p-5 hover:border-blue-400 hover:shadow-xl transition-all duration-200"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div>
                        <span className="inline-block px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-bold uppercase tracking-wider mb-1">
                          {service.categoryName || 'Service'}
                        </span>
                        <h4 className="text-base font-extrabold text-slate-900 group-hover:text-blue-600 transition-colors">
                          {service.name}
                        </h4>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] font-bold text-slate-400 block uppercase">
                          {isQuote ? 'Pricing' : service.pricingType === 'STARTING_FROM' ? 'Starts at' : 'Price'}
                        </span>
                        {isQuote ? (
                          <span className="text-xs font-bold text-slate-700 block mt-1">
                            Quote on inspection
                          </span>
                        ) : (
                          <span className="text-xl font-black text-slate-900">
                            ₹{service.customerPrice}
                          </span>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 mb-3">
                      {service.description}
                    </p>

                    {/* Financial Breakdown Preview */}
                    {!isQuote && (
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-[11px] mb-3">
                        <div className="flex items-center justify-between text-slate-500 mb-1">
                          <span>{t('karwadoCommission')}</span>
                          <span className="font-semibold text-amber-700">₹{service.platformCommission}</span>
                        </div>
                        <div className="flex items-center justify-between text-slate-700">
                          <span>{t('providerAmount')}</span>
                          <span className="font-bold text-emerald-700">₹{service.providerAmount}</span>
                        </div>
                      </div>
                    )}

                    {/* Highlights */}
                    {service.whatsIncluded && service.whatsIncluded.length > 0 && (
                      <div className="mb-4">
                        <ul className="space-y-1">
                          {service.whatsIncluded.slice(0, 2).map((inc, idx) => (
                            <li key={idx} className="flex items-center gap-1.5 text-xs text-slate-600">
                              <span className="text-emerald-500 text-xs">✓</span>
                              <span className="truncate">{inc}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1 text-[11px] font-medium text-slate-400">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{service.estimatedDuration || '60 mins'}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {onViewServiceDetails && (
                        <button
                          onClick={() => onViewServiceDetails(service)}
                          className="px-2.5 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold text-xs transition cursor-pointer"
                        >
                          Details
                        </button>
                      )}
                      <button
                        onClick={() => onSelectService(service)}
                        className="flex items-center gap-1 px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition cursor-pointer"
                      >
                        <span>{isQuote ? 'Get a Quote' : t('bookNow')}</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
