import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { Job, Service } from '../types/index.ts';
import {
  Briefcase,
  Search,
  MapPin,
  Building2,
  Sparkles,
  FileCheck,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Filter,
} from 'lucide-react';

interface JobsSectionProps {
  onSelectPaidService: (service: Service) => void;
  onOpenRecruiterPortal: () => void;
  onOpenAuth: () => void;
}

export const JobsSection: React.FC<JobsSectionProps> = ({
  onSelectPaidService,
  onOpenRecruiterPortal,
  onOpenAuth,
}) => {
  const { t } = useLanguage();
  const { user } = useAuth();

  const [jobs, setJobs] = useState<Job[]>([]);
  const [careerServices, setCareerServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [workModeFilter, setWorkModeFilter] = useState('');

  // Apply Modal state
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [applicantName, setApplicantName] = useState(user?.name || '');
  const [applicantEmail, setApplicantEmail] = useState(user?.email || '');
  const [applicantPhone, setApplicantPhone] = useState(user?.phone || '');
  const [resumeText, setResumeText] = useState('');
  const [consentApproved, setConsentApproved] = useState(false);
  const [applyLoading, setApplyLoading] = useState(false);
  const [applySuccess, setApplySuccess] = useState(false);
  const [applyError, setApplyError] = useState<string | null>(null);

  // AI Resume Analyzer
  const [aiAnalysisTargetRole, setAiAnalysisTargetRole] = useState('Full Stack Developer');
  const [aiAnalysisResult, setAiAnalysisResult] = useState<any | null>(null);
  const [aiAnalyzing, setAiAnalyzing] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, [search, locationFilter, workModeFilter]);

  const fetchJobs = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (locationFilter) params.append('location', locationFilter);
      if (workModeFilter) params.append('workMode', workModeFilter);

      const [jobsRes, srvRes] = await Promise.all([
        fetch(`/api/jobs?${params.toString()}`),
        fetch('/api/services'),
      ]);

      if (jobsRes.ok) {
        const data = await jobsRes.json();
        setJobs(data);
      }

      if (srvRes.ok) {
        const srvData: Service[] = await srvRes.json();
        const careerList = srvData.filter(
          (s) => s.categorySlug === 'jobs-career' || s.categoryId === 5 || s.slug.includes('job') || s.slug.includes('resume') || s.slug.includes('interview')
        );
        setCareerServices(careerList);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedJob) return;

    // Prompt Section 11: Applications must NOT be submitted without user approval!
    if (!consentApproved) {
      setApplyError('You must review and explicitly agree before submitting your application.');
      return;
    }

    setApplyLoading(true);
    setApplyError(null);

    try {
      const res = await fetch(`/api/jobs/${selectedJob.id}/apply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user?.uid || 'guest'}`,
          'x-user-id': user?.uid || 'guest',
        },
        body: JSON.stringify({
          applicantName,
          applicantEmail,
          applicantPhone,
          userConfirmedConsent: consentApproved,
          resumeUrl: resumeText ? 'text_resume' : null,
        }),
      });

      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to submit application');
      }

      setApplySuccess(true);
      setTimeout(() => {
        setSelectedJob(null);
        setApplySuccess(false);
        setConsentApproved(false);
      }, 2000);
    } catch (err: any) {
      setApplyError(err.message || 'Application error. Please try again.');
    } finally {
      setApplyLoading(false);
    }
  };

  const handleRunAiResumeTest = async () => {
    if (!resumeText.trim()) return;
    setAiAnalyzing(true);
    try {
      const res = await fetch('/api/ai/optimize-resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resumeText,
          targetRole: aiAnalysisTargetRole,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setAiAnalysisResult(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setAiAnalyzing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8 space-y-10">
      {/* Hero Banner (Prompt Section 11) */}
      <div className="rounded-3xl bg-gradient-to-r from-blue-950 via-slate-900 to-blue-900 text-white p-8 sm:p-12 relative overflow-hidden shadow-xl">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold mb-4 border border-blue-400/30">
            <Briefcase className="w-3.5 h-3.5 text-amber-400" />
            <span>Jobs, Careers & Verification</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black tracking-tight text-white mb-3">
            {t('jobsHeroTitle')}
          </h2>
          <p className="text-sm sm:text-base text-slate-300 mb-6 leading-relaxed">
            {t('jobsHeroSubtext')}
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                const el = document.getElementById('resume-ai-tool');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs shadow-md transition"
            >
              ⚡ AI Resume ATS Check
            </button>

            <button
              onClick={onOpenRecruiterPortal}
              className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/20 transition"
            >
              💼 Recruiter Portal: Post Jobs
            </button>
          </div>
        </div>
      </div>

      {/* Career Boost Services (Phase 3 Section 20: Real prices from Admin DB) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-black text-slate-900">Career Boost & Job Services</h3>
            <p className="text-xs text-slate-500">
              Admin-controlled pricing. Direct professional career support and preparation.
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-500">
            {careerServices.length > 0 ? `${careerServices.length} Active Services` : 'Verified Specialists'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {[
            {
              defaultTitle: 'Resume Creation',
              slug: 'resume-creation',
              desc: 'Professional end-to-end resume building crafted for your target sector.',
              fallbackPrice: 799,
            },
            {
              defaultTitle: 'Resume Optimization',
              slug: 'resume-boost',
              desc: 'Keyword optimization against ATS algorithms and recruiter benchmarks.',
              fallbackPrice: 599,
            },
            {
              defaultTitle: 'Job Search Assistance',
              slug: 'job-search-assist',
              desc: 'Curated job openings matching your profile across trusted platforms.',
              fallbackPrice: 699,
            },
            {
              defaultTitle: 'Job Application Assistance',
              slug: 'job-apply-assistance',
              desc: 'Application submission tracking with explicit candidate consent.',
              fallbackPrice: 999,
            },
            {
              defaultTitle: 'Interview Preparation',
              slug: 'mock-interview',
              desc: '1-on-1 industry specialist mock interview with actionable feedback rubric.',
              fallbackPrice: 799,
            },
          ].map((svcDef) => {
            // Find matched real DB service if present
            const dbMatch = careerServices.find(
              (cs) => cs.slug === svcDef.slug || cs.name.toLowerCase().includes(svcDef.defaultTitle.toLowerCase())
            );
            const actualService: Service = dbMatch || {
              id: 14,
              categoryId: 5,
              slug: svcDef.slug,
              name: svcDef.defaultTitle,
              description: svcDef.desc,
              pricingType: 'fixed',
              customerPrice: svcDef.fallbackPrice,
              platformCommission: Math.round(svcDef.fallbackPrice * 0.2),
              platformFee: 0,
              providerAmount: Math.round(svcDef.fallbackPrice * 0.8),
              estimatedDuration: '24-48 Hours',
              whatsIncluded: ['Personal specialist review', 'Guaranteed turnaround'],
              requirements: [],
              isActive: true,
            };

            return (
              <div
                key={svcDef.slug}
                className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm hover:border-blue-400 transition flex flex-col justify-between"
              >
                <div>
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block mb-1">
                    Career Service
                  </span>
                  <h4 className="text-sm font-extrabold text-slate-900 mb-1">{actualService.name}</h4>
                  <p className="text-[11px] text-slate-500 mb-3 line-clamp-2">{actualService.description}</p>
                </div>
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-base font-black text-slate-900">₹{actualService.customerPrice}</span>
                  <button
                    onClick={() => onSelectPaidService(actualService)}
                    className="px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs cursor-pointer transition"
                  >
                    Book
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filter & Job Listings Header */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder={t('searchJobs')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={workModeFilter}
            onChange={(e) => setWorkModeFilter(e.target.value)}
            className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 bg-white"
          >
            <option value="">All Work Modes</option>
            <option value="on_site">On-Site</option>
            <option value="remote">Remote</option>
            <option value="hybrid">Hybrid</option>
          </select>
          <input
            type="text"
            placeholder="City filter..."
            value={locationFilter}
            onChange={(e) => setLocationFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white w-32"
          />
        </div>
      </div>

      {/* Job Cards (Section 20: NO DEMO DATA — True DB empty state) */}
      <div>
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-28 bg-slate-100 rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center shadow-sm">
            <div className="w-16 h-16 rounded-3xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <Briefcase className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-1">{t('noJobsPostedYet')}</h3>
            <p className="text-xs text-slate-500 mb-5 max-w-sm mx-auto">
              Recruiters can register and post verified job opportunities immediately via the Recruiter Portal.
            </p>
            <button
              onClick={onOpenRecruiterPortal}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs"
            >
              Post the First Job as Recruiter
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {jobs.map((j) => (
              <div
                key={j.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:border-blue-400 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <h4 className="text-base font-extrabold text-slate-900">{j.title}</h4>
                      <p className="text-xs font-semibold text-slate-600">{j.companyName}</p>
                    </div>
                    <span className="text-[11px] font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      {j.salaryMin && j.salaryMax
                        ? `₹${(j.salaryMin / 1000).toFixed(0)}k - ₹${(j.salaryMax / 1000).toFixed(0)}k/mo`
                        : 'Competitive'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 line-clamp-2 mb-3">{j.description}</p>

                  <div className="flex flex-wrap gap-2 text-[11px] text-slate-600 mb-4">
                    <span className="flex items-center gap-1 bg-slate-100 px-2.5 py-1 rounded-lg">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>{j.location}</span>
                    </span>
                    <span className="capitalize bg-slate-100 px-2.5 py-1 rounded-lg">
                      {j.workMode.replace('_', ' ')}
                    </span>
                    <span className="capitalize bg-slate-100 px-2.5 py-1 rounded-lg">
                      {j.jobType.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex justify-end">
                  <button
                    onClick={() => {
                      setSelectedJob(j);
                      setApplicantName(user?.name || '');
                      setApplicantEmail(user?.email || '');
                      setApplicantPhone(user?.phone || '');
                    }}
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs"
                  >
                    {t('applyNow')}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* AI Resume ATS Optimizer Tool Section */}
      <div id="resume-ai-tool" className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-5">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
            <Sparkles className="w-5 h-5 text-amber-500" />
          </div>
          <div>
            <h3 className="font-black text-lg text-slate-900">{t('optimizeResume')}</h3>
            <p className="text-xs text-slate-500">
              Paste your resume text to evaluate ATS readability, key competencies, and role match percentage.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Target Job Role</label>
              <input
                type="text"
                value={aiAnalysisTargetRole}
                onChange={(e) => setAiAnalysisTargetRole(e.target.value)}
                placeholder="e.g. Sales Executive, Electrician Supervisor, React Developer..."
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Resume Text</label>
              <textarea
                rows={5}
                placeholder="Paste experience summary, skills, previous jobs..."
                value={resumeText}
                onChange={(e) => setResumeText(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
              />
            </div>
            <button
              onClick={handleRunAiResumeTest}
              disabled={aiAnalyzing || !resumeText.trim()}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 disabled:opacity-50"
            >
              {aiAnalyzing ? 'Analyzing with Gemini AI...' : 'Analyze Resume Fit'}
            </button>
          </div>

          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs">
            {aiAnalysisResult ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <span className="font-bold text-slate-800">ATS Readiness Score</span>
                  <span className="text-xl font-black text-blue-700">{aiAnalysisResult.atsScore}%</span>
                </div>
                {aiAnalysisResult.strengths?.length > 0 && (
                  <div>
                    <span className="font-bold text-emerald-800 block mb-1">Strengths:</span>
                    <ul className="list-disc list-inside space-y-0.5 text-slate-600 text-[11px]">
                      {aiAnalysisResult.strengths.map((s: string, i: number) => (
                        <li key={i}>{s}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {aiAnalysisResult.actionableImprovements?.length > 0 && (
                  <div>
                    <span className="font-bold text-amber-800 block mb-1">Suggestions:</span>
                    <ul className="list-disc list-inside space-y-0.5 text-slate-600 text-[11px]">
                      {aiAnalysisResult.actionableImprovements.map((s: string, i: number) => (
                        <li key={i}>{s}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 p-6">
                <FileCheck className="w-8 h-8 mb-2 opacity-50" />
                <p>AI Score and ATS keyword breakdown will appear here.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Apply Modal with Explicit User Consent Gate (Prompt requirement) */}
      {selectedJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-8 max-w-lg w-full space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div>
              <span className="text-[10px] font-bold text-blue-600 uppercase">Apply for Verified Job</span>
              <h3 className="text-xl font-black text-slate-900">{selectedJob.title}</h3>
              <p className="text-xs text-slate-500">{selectedJob.companyName} • {selectedJob.location}</p>
            </div>

            {applyError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl">
                {applyError}
              </div>
            )}
            {applySuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs rounded-xl flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>Application submitted to recruiter!</span>
              </div>
            )}

            <form onSubmit={handleApply} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Your Full Name *</label>
                <input
                  type="text"
                  value={applicantName}
                  onChange={(e) => setApplicantName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email *</label>
                  <input
                    type="email"
                    value={applicantEmail}
                    onChange={(e) => setApplicantEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Mobile *</label>
                  <input
                    type="tel"
                    value={applicantPhone}
                    onChange={(e) => setApplicantPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    required
                  />
                </div>
              </div>

              {/* Explicit User Approval Gate (Prompt requirement) */}
              <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 text-amber-950">
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={consentApproved}
                    onChange={(e) => setConsentApproved(e.target.checked)}
                    className="mt-0.5 rounded border-amber-400 text-amber-600 focus:ring-amber-500 w-4 h-4"
                  />
                  <div className="text-[11px] leading-relaxed">
                    <span className="font-bold block">User Consent Confirmation:</span>
                    {t('applicationReviewNotice')} I confirm I want to submit my application to {selectedJob.companyName}.
                  </div>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedJob(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={applyLoading || !consentApproved}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs disabled:opacity-50 shadow-md"
                >
                  {applyLoading ? 'Submitting...' : 'Submit Application'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
