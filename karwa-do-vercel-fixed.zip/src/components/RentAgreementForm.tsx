import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  FileText,
  AlertTriangle,
  CheckCircle,
  Building,
  User,
  Shield,
  ArrowRight,
  Upload,
  Calendar,
} from 'lucide-react';
import { Booking } from '../types/index.ts';

interface RentAgreementFormProps {
  onSuccess: (booking: Booking) => void;
  onCancel: () => void;
  onOpenAuth: () => void;
}

export const RentAgreementForm: React.FC<RentAgreementFormProps> = ({
  onSuccess,
  onCancel,
  onOpenAuth,
}) => {
  const { t } = useLanguage();
  const { user } = useAuth();

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Form states
  const [packageType, setPackageType] = useState<'online' | 'home_visit'>('online');
  const [landlordName, setLandlordName] = useState('');
  const [landlordPhone, setLandlordPhone] = useState('');
  const [landlordPan, setLandlordPan] = useState('');
  const [tenantName, setTenantName] = useState('');
  const [tenantPhone, setTenantPhone] = useState('');
  const [tenantPan, setTenantPan] = useState('');
  const [propertyAddress, setPropertyAddress] = useState('');
  const [city, setCity] = useState('Mumbai');
  const [state, setState] = useState('Maharashtra');
  const [pincode, setPincode] = useState('');
  const [monthlyRent, setMonthlyRent] = useState('25000');
  const [securityDeposit, setSecurityDeposit] = useState('100000');
  const [durationMonths, setDurationMonths] = useState('11');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);

  const packagePrice = packageType === 'online' ? 1199 : 1999;
  const platformCommission = packageType === 'online' ? 250 : 450;
  const providerAmount = packagePrice - platformCommission;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onOpenAuth();
      return;
    }

    if (!landlordName || !tenantName || !propertyAddress || !pincode) {
      setErrorMsg('Please complete all landlord, tenant, and property fields.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);

    try {
      // Find or link service ID (online rent agreement is id 11 or 12)
      const serviceSlug =
        packageType === 'online' ? 'rent-agreement-online' : 'rent-agreement-home-visit';
      const sRes = await fetch(`/api/services`);
      const services = await sRes.json();
      const matched = services.find((s: any) => s.slug === serviceSlug) || services[0];

      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.uid}`,
          'x-user-id': user.uid,
        },
        body: JSON.stringify({
          serviceId: matched.id,
          scheduledDate: startDate,
          scheduledTime: '11:00 AM - 01:00 PM',
          serviceType: 'rent_agreement',
          problemDescription: `Rent Agreement draft for ${tenantName} & ${landlordName} at ${propertyAddress}, ${city}`,
          serviceDetails: {
            packageType,
            landlord: { name: landlordName, phone: landlordPhone, pan: landlordPan },
            tenant: { name: tenantName, phone: tenantPhone, pan: tenantPan },
            property: { address: propertyAddress, city, state, pincode },
            financials: {
              monthlyRent: parseInt(monthlyRent, 10),
              securityDeposit: parseInt(securityDeposit, 10),
              durationMonths: parseInt(durationMonths, 10),
              startDate,
            },
          },
          paymentMethod: 'upi',
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to submit rent agreement application');
      }

      const booking = await res.json();
      onSuccess(booking);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Submission failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 to-slate-900 text-white p-6 sm:p-8">
        <div className="flex items-center gap-2 text-blue-300 text-xs font-bold uppercase tracking-wider mb-2">
          <FileText className="w-4 h-4 text-amber-400" />
          <span>{t('rentAgreementTitle')}</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black">{t('rentAgreementSubtitle')}</h2>
        <p className="text-xs sm:text-sm text-slate-300 mt-1">
          Legally drafted tenancy contract customized to your state's rental rules with doorstep verification assistance.
        </p>
      </div>

      {/* Mandatory Statutory State Disclaimer (Phase 3 Section 18) */}
      <div className="bg-amber-50 border-y border-amber-200/80 p-4 sm:p-5 flex items-start gap-3 text-amber-900">
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="text-xs leading-relaxed">
          <span className="font-bold block mb-0.5">State Legal & Registration Disclosure:</span>
          <p className="font-semibold text-amber-950">
            Registration and documentation requirements may vary by state. KARWA DO will coordinate the applicable process through the appropriate service provider.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
        {/* Step Indicator */}
        <div className="flex items-center justify-between text-xs font-bold text-slate-500 border-b border-slate-100 pb-4">
          <span className={step === 1 ? 'text-blue-600 font-extrabold' : ''}>
            1. Service Configuration & Parties
          </span>
          <span className="text-slate-300">→</span>
          <span className={step === 2 ? 'text-blue-600 font-extrabold' : ''}>
            2. Property & Terms
          </span>
          <span className="text-slate-300">→</span>
          <span className={step === 3 ? 'text-blue-600 font-extrabold' : ''}>
            3. Review & Financials
          </span>
        </div>

        {errorMsg && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl">
            {errorMsg}
          </div>
        )}

        {/* STEP 1: Package & Parties */}
        {step === 1 && (
          <div className="space-y-5 animate-in fade-in duration-150">
            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wide mb-2">
                Configure Rent Agreement Service:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {[
                  {
                    id: 'online',
                    title: 'Rent Agreement Preparation',
                    desc: 'Legally vetted draft preview, lawyer review & digital PDF.',
                    price: 1199,
                  },
                  {
                    id: 'home_visit',
                    title: 'Home Visit & Biometric',
                    desc: 'Executive visits premises with biometric verification device.',
                    price: 1999,
                  },
                  {
                    id: 'registration_assist',
                    title: 'Registration Assistance',
                    desc: 'End-to-end stamp duty & registrar compliance coordination.',
                    price: 2499,
                  },
                  {
                    id: 'doc_verification',
                    title: 'Document Verification',
                    desc: 'Lawyer check of title deeds, Index-II, and ID proofs.',
                    price: 799,
                  },
                  {
                    id: 'appointment_assist',
                    title: 'Appointment Assistance',
                    desc: 'Prioritized slot booking at applicable registration offices.',
                    price: 599,
                  },
                ].map((pkg) => {
                  const isSelected = packageType === (pkg.id as any);
                  return (
                    <div
                      key={pkg.id}
                      onClick={() => setPackageType(pkg.id as any)}
                      className={`p-3.5 rounded-2xl border-2 cursor-pointer transition ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/60 shadow-sm'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className={`font-bold text-xs ${isSelected ? 'text-blue-900' : 'text-slate-900'}`}>
                          {pkg.title}
                        </span>
                        <span className="font-black text-blue-700 text-xs">₹{pkg.price}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{pkg.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Landlord Details */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <h4 className="font-bold text-xs uppercase tracking-wide text-slate-700 mb-3 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-blue-600" />
                <span>{t('landlordDetails')}</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="Full Legal Name *"
                  value={landlordName}
                  onChange={(e) => setLandlordName(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                  required
                />
                <input
                  type="tel"
                  placeholder="Mobile Number *"
                  value={landlordPhone}
                  onChange={(e) => setLandlordPhone(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                  required
                />
                <input
                  type="text"
                  placeholder="PAN / Aadhaar (optional)"
                  value={landlordPan}
                  onChange={(e) => setLandlordPan(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                />
              </div>
            </div>

            {/* Tenant Details */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <h4 className="font-bold text-xs uppercase tracking-wide text-slate-700 mb-3 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-blue-600" />
                <span>{t('tenantDetails')}</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="Full Legal Name *"
                  value={tenantName}
                  onChange={(e) => setTenantName(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                  required
                />
                <input
                  type="tel"
                  placeholder="Mobile Number *"
                  value={tenantPhone}
                  onChange={(e) => setTenantPhone(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                  required
                />
                <input
                  type="text"
                  placeholder="PAN / Aadhaar (optional)"
                  value={tenantPan}
                  onChange={(e) => setTenantPan(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                />
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setStep(2)}
                disabled={!landlordName || !tenantName}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 disabled:opacity-50"
              >
                <span>Continue to Property Details</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Property & Financials */}
        {step === 2 && (
          <div className="space-y-5 animate-in fade-in duration-150">
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
              <h4 className="font-bold text-xs uppercase tracking-wide text-slate-700 flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5 text-blue-600" />
                <span>{t('propertyDetails')}</span>
              </h4>

              <textarea
                placeholder="Complete Rented Property Address (Flat/House No, Building, Area) *"
                value={propertyAddress}
                onChange={(e) => setPropertyAddress(e.target.value)}
                rows={2}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                required
              />

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="City *"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                  required
                />
                <select
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                >
                  <option value="Maharashtra">Maharashtra</option>
                  <option value="Karnataka">Karnataka</option>
                  <option value="Delhi">Delhi NCR</option>
                  <option value="Gujarat">Gujarat</option>
                  <option value="Tamil Nadu">Tamil Nadu</option>
                  <option value="Telangana">Telangana</option>
                  <option value="West Bengal">West Bengal</option>
                  <option value="Uttar Pradesh">Uttar Pradesh</option>
                </select>
                <input
                  type="text"
                  placeholder="Pincode *"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                  required
                />
              </div>
            </div>

            {/* Financial Terms */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {t('monthlyRent')}
                </label>
                <input
                  type="number"
                  value={monthlyRent}
                  onChange={(e) => setMonthlyRent(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {t('securityDeposit')}
                </label>
                <input
                  type="number"
                  value={securityDeposit}
                  onChange={(e) => setSecurityDeposit(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {t('agreementDuration')}
                </label>
                <select
                  value={durationMonths}
                  onChange={(e) => setDurationMonths(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-bold"
                >
                  <option value="11">11 Months (Standard)</option>
                  <option value="24">24 Months</option>
                  <option value="36">36 Months</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                {t('startDate')}
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                required
              />
            </div>

            <div className="flex justify-between">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 text-xs font-bold"
              >
                Back
              </button>
              <button
                type="button"
                onClick={() => setStep(3)}
                disabled={!propertyAddress || !pincode}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 disabled:opacity-50"
              >
                <span>Continue to Summary</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Review & Financial Snapshot */}
        {step === 3 && (
          <div className="space-y-5 animate-in fade-in duration-150">
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs space-y-2">
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Service:</span>
                <span className="font-bold text-slate-900">
                  {packageType === 'online'
                    ? 'Rent Agreement Preparation & Verification'
                    : 'Rent Agreement Home Visit & Biometric Assistance'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Parties:</span>
                <span className="font-semibold text-slate-800">
                  {landlordName} (Landlord) ⇄ {tenantName} (Tenant)
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Property:</span>
                <span className="font-semibold text-slate-800 truncate max-w-[280px]">
                  {propertyAddress}, {city}, {state} - {pincode}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Rent & Deposit:</span>
                <span className="font-semibold text-slate-800">
                  ₹{monthlyRent}/mo | Deposit: ₹{securityDeposit} ({durationMonths} months)
                </span>
              </div>
            </div>

            {/* Transparent Platform Snapshot */}
            <div className="bg-blue-50/80 rounded-2xl p-4 border border-blue-100 text-xs">
              <span className="font-bold text-blue-900 block mb-2">
                Official Financial Snapshot (Server Calculated):
              </span>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-white p-2.5 rounded-xl border border-blue-100 text-center">
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">{t('customerPrice')}</span>
                  <span className="text-base font-black text-slate-950">₹{packagePrice}</span>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-blue-100 text-center">
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">{t('karwadoCommission')}</span>
                  <span className="text-base font-black text-amber-700">₹{platformCommission}</span>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-blue-100 text-center">
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">{t('providerAmount')}</span>
                  <span className="text-base font-black text-emerald-700">₹{providerAmount}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 text-xs font-bold"
              >
                Back
              </button>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={onCancel}
                  className="px-4 py-2 rounded-xl text-slate-500 hover:bg-slate-100 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-md transition disabled:opacity-50"
                >
                  {loading ? 'Submitting Application...' : `Confirm & Book (₹${packagePrice})`}
                </button>
              </div>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};
