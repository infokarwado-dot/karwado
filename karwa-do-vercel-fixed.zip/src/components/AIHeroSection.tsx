import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import {
  Sparkles,
  ArrowRight,
  Clock,
  Shield,
  CheckCircle2,
  AlertCircle,
  PhoneCall,
  RotateCcw,
  MapPin,
  HelpCircle,
} from 'lucide-react';
import { Service } from '../types/index.ts';

interface AIHeroSectionProps {
  onSelectService: (service: Service, problemText?: string) => void;
  onOpenRentAgreement: () => void;
  onOpenRoadside: () => void;
}

const SAMPLE_PROMPTS = [
  'Meri bike start nahi ho rahi',
  'AC cooling nahi kar raha',
  'Mujhe rent agreement banana hai',
  'Mujhe job chahiye',
  'Laptop repair karwana hai',
  'Mujhe ghar shifting karni hai',
];

export const AIHeroSection: React.FC<AIHeroSectionProps> = ({
  onSelectService,
  onOpenRentAgreement,
  onOpenRoadside,
}) => {
  const { t } = useLanguage();
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [classificationResult, setClassificationResult] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Additional questions answered by user
  const [answers, setAnswers] = useState<Record<string, string>>({});

  // Callback request state
  const [callbackRequested, setCallbackRequested] = useState(false);
  const [callbackPhone, setCallbackPhone] = useState('');
  const [callbackLoading, setCallbackLoading] = useState(false);
  const [callbackSuccessMsg, setCallbackSuccessMsg] = useState<string | null>(null);

  const handleClassify = async (promptToUse?: string) => {
    const text = promptToUse !== undefined ? promptToUse : inputQuery;
    if (!text.trim()) return;

    // Direct routing for specific dedicated workflows
    const lower = text.toLowerCase();
    if (lower.includes('rent') && lower.includes('agreement')) {
      onOpenRentAgreement();
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setClassificationResult(null);
    setAnswers({});
    setCallbackRequested(false);
    setCallbackSuccessMsg(null);

    try {
      const res = await fetch('/api/ai/understand-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: text }),
      });

      if (!res.ok) throw new Error('AI analysis failed');
      const data = await res.json();
      setClassificationResult(data);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Could not analyze the task right now. Please try again or select a service directly from the catalog.');
    } finally {
      setLoading(false);
    }
  };

  const handleCallbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!callbackPhone || !classificationResult?.primaryService?.id) return;
    setCallbackLoading(true);
    try {
      const res = await fetch('/api/bookings/callback-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          serviceId: classificationResult.primaryService.id,
          phone: callbackPhone,
          notes: `Customer task: ${inputQuery}`,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setCallbackSuccessMsg(data.message || 'Callback requested. We will connect you with a verified partner.');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setCallbackLoading(false);
    }
  };

  const primaryService = classificationResult?.primaryService;
  const classification = classificationResult?.classification;
  const availableProviders = classificationResult?.availableProviders || [];
  const isCustomQuote = primaryService?.pricingType === 'CUSTOM_QUOTE' || primaryService?.pricingType === 'quote';

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-blue-950 to-slate-900 text-white pt-12 pb-16 sm:pt-20 sm:pb-24 px-4 sm:px-6 lg:px-8">
      {/* Subtle modern pattern background */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

      <div className="relative max-w-4xl mx-auto text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-300 text-xs font-semibold mb-6 backdrop-blur-sm">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>AI-Powered On-Demand Service Engine</span>
        </div>

        {/* Phase 3 Section 6: Large AI Task Input Heading */}
        <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-white mb-3 leading-tight">
          Kya Karwana Hai?
        </h1>
        <p className="text-base sm:text-xl font-medium text-slate-300 max-w-2xl mx-auto mb-8 sm:mb-10">
          Apna kaam yahan likhiye — hum samajh kar sahi service aur verified provider connect karenge.
        </p>

        {/* Large AI Task Input Box */}
        <div className="relative max-w-2xl mx-auto bg-white/10 backdrop-blur-xl p-2 sm:p-2.5 rounded-2xl border border-white/20 shadow-2xl">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={inputQuery}
                onChange={(e) => setInputQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleClassify()}
                placeholder="Apna kaam yahan likhiye..."
                className="w-full px-4 py-3.5 sm:py-4 rounded-xl bg-white text-slate-900 text-base placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
              />
            </div>
            <button
              onClick={() => handleClassify()}
              disabled={loading || !inputQuery.trim()}
              className="flex items-center justify-center gap-2 px-6 py-3.5 sm:py-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-base shadow-lg shadow-amber-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer whitespace-nowrap"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>Samajh rahe hain...</span>
                </>
              ) : (
                <span>⚡ KARWA DO</span>
              )}
            </button>
          </div>

          {/* Prompt Examples (Phase 3 Section 6) */}
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider shrink-0 mr-1">
              Examples:
            </span>
            {SAMPLE_PROMPTS.map((prompt) => (
              <button
                key={prompt}
                onClick={() => {
                  setInputQuery(prompt);
                  handleClassify(prompt);
                }}
                className="text-xs shrink-0 px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 text-slate-200 border border-white/10 transition"
              >
                “{prompt}”
              </button>
            ))}
          </div>
        </div>

        {/* Phase 3 Section 7 & 8: AI Task Recommendation & Customer Confirmation */}
        {classificationResult && (
          <div className="mt-8 max-w-2xl mx-auto bg-white rounded-3xl text-slate-900 p-6 sm:p-8 text-left shadow-2xl border border-slate-200 animate-in fade-in slide-in-from-bottom-4 duration-300">
            {/* Header: Humne aapki requirement samjhi hai */}
            <div className="border-b border-slate-100 pb-5 mb-5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold mb-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Humne aapki requirement samjhi hai.</span>
              </div>
              <h3 className="text-2xl font-black text-slate-900">
                Service: {primaryService?.name || 'Recommended Service'}
              </h3>
              <div className="flex flex-wrap items-center gap-3 mt-1.5 text-xs text-slate-500 font-medium">
                <span>Category: <strong className="text-slate-800">{classification?.category || 'Service'}</strong></span>
                <span>•</span>
                <span>Urgency: <strong className="uppercase text-amber-700">{classification?.urgency || 'Medium'}</strong></span>
                {classification?.location_required && (
                  <>
                    <span>•</span>
                    <span className="flex items-center gap-1 text-blue-700 font-semibold">
                      <MapPin className="w-3.5 h-3.5" /> Doorstep / Location Required
                    </span>
                  </>
                )}
              </div>
            </div>

            {/* Price & Duration Grid (Phase 3 Section 8 & 9) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Price
                </span>
                {isCustomQuote ? (
                  <span className="text-sm font-bold text-slate-800 block mt-1">
                    Price will be confirmed after provider inspection.
                  </span>
                ) : (
                  <div className="mt-1">
                    <span className="text-2xl font-black text-slate-950">
                      ₹{primaryService?.customerPrice}
                    </span>
                    {primaryService?.pricingType === 'STARTING_FROM' && (
                      <span className="text-[11px] text-slate-500 block font-normal">(Starting Price)</span>
                    )}
                  </div>
                )}
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Estimated Duration
                </span>
                <div className="flex items-center gap-2 mt-1">
                  <Clock className="w-4 h-4 text-blue-600" />
                  <span className="text-base font-bold text-slate-900">
                    {primaryService?.estimatedDuration || '60 mins'}
                  </span>
                </div>
              </div>
            </div>

            {/* What's Included (Configured by Admin) */}
            {primaryService?.whatsIncluded && primaryService.whatsIncluded.length > 0 && (
              <div className="mb-5 p-4 rounded-2xl bg-blue-50/60 border border-blue-100">
                <span className="text-xs font-bold text-blue-900 uppercase tracking-wide block mb-2">
                  What's Included:
                </span>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700">
                  {primaryService.whatsIncluded.map((item: string, idx: number) => (
                    <li key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Additional Questions (Phase 3 Section 7) */}
            {classification?.additional_questions && classification.additional_questions.length > 0 && (
              <div className="mb-5 p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80 text-xs">
                <span className="font-bold text-amber-950 block mb-2 uppercase text-[11px] tracking-wider flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4 text-amber-700" />
                  <span>Aapki suvidha ke liye kuch sawal:</span>
                </span>
                <div className="space-y-3">
                  {classification.additional_questions.map((q: any, qIdx: number) => (
                    <div key={qIdx} className="space-y-1.5">
                      <p className="font-semibold text-slate-800">{q.question}</p>
                      {q.options && q.options.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {q.options.map((opt: string) => {
                            const isSelected = answers[q.question] === opt;
                            return (
                              <button
                                key={opt}
                                type="button"
                                onClick={() => setAnswers({ ...answers, [q.question]: opt })}
                                className={`px-3 py-1 rounded-xl border text-xs font-medium transition ${
                                  isSelected
                                    ? 'bg-amber-600 text-white border-amber-600 font-bold'
                                    : 'bg-white text-slate-700 border-slate-300 hover:border-slate-400'
                                }`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>
                      ) : (
                        <input
                          type="text"
                          placeholder="Yahan type karein..."
                          value={answers[q.question] || ''}
                          onChange={(e) => setAnswers({ ...answers, [q.question]: e.target.value })}
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Provider Matching & Availability (Phase 3 Section 12) */}
            <div className="pt-3 border-t border-slate-100 mb-6">
              {availableProviders.length > 0 ? (
                <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="font-bold text-emerald-900 block">
                        {availableProviders.length} Verified Partner(s) Online
                      </span>
                      <span className="text-[11px] text-emerald-700">
                        Aadhaar verified & ready to serve in your service area.
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-slate-100 border border-slate-300 text-xs space-y-3">
                  <div className="flex items-start gap-2.5 text-slate-700">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block text-slate-900">
                        No provider is currently available for this service.
                      </span>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Our verified network in your area is currently occupied. Request a callback and our dispatch desk will arrange an appointment.
                      </p>
                    </div>
                  </div>

                  {!callbackRequested ? (
                    <button
                      type="button"
                      onClick={() => setCallbackRequested(true)}
                      className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-2"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                      <span>Request Callback</span>
                    </button>
                  ) : callbackSuccessMsg ? (
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-medium">
                      ✓ {callbackSuccessMsg}
                    </div>
                  ) : (
                    <form onSubmit={handleCallbackSubmit} className="flex gap-2 pt-1">
                      <input
                        type="tel"
                        placeholder="Enter 10-digit mobile *"
                        value={callbackPhone}
                        onChange={(e) => setCallbackPhone(e.target.value)}
                        className="px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-xs font-semibold flex-1"
                        required
                      />
                      <button
                        type="submit"
                        disabled={callbackLoading}
                        className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs"
                      >
                        {callbackLoading ? 'Submitting...' : 'Submit'}
                      </button>
                    </form>
                  )}
                </div>
              )}
            </div>

            {/* Customer Confirmation Buttons (Phase 3 Section 8) */}
            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  const combinedInstructions = Object.entries(answers)
                    .map(([k, v]) => `${k}: ${v}`)
                    .join(' | ');
                  const finalProblem = [inputQuery, combinedInstructions].filter(Boolean).join('\n');
                  onSelectService(primaryService, finalProblem);
                }}
                className="flex-1 py-3.5 px-5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setClassificationResult(null);
                  setInputQuery('');
                }}
                className="py-3.5 px-5 rounded-2xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                <span>Choose Another Service</span>
              </button>
            </div>
          </div>
        )}

        {errorMsg && (
          <div className="mt-4 p-3 rounded-xl bg-red-500/20 border border-red-500/40 text-red-200 text-xs max-w-lg mx-auto">
            {errorMsg}
          </div>
        )}
      </div>
    </section>
  );
};
