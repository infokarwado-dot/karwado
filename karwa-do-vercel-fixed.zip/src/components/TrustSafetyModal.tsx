import React from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { X, ShieldCheck, Lock, AlertTriangle, FileText, CheckCircle2 } from 'lucide-react';

interface TrustSafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TrustSafetyModal: React.FC<TrustSafetyModalProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-8 space-y-6 max-h-[85vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900">{t('customerSafety')}</h3>
            <p className="text-xs text-slate-500">
              Our safety commitment, verified provider standards, and statutory consumer protection.
            </p>
          </div>
        </div>

        <div className="space-y-4 text-xs text-slate-600 leading-relaxed">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>1. Mandatory Provider KYC & Verification</span>
            </h4>
            <p>
              Every technician, driver, and executive must upload government-recognized identity (Aadhaar/PAN), trade credentials, and bank account proofs. Only verified professionals with an active status can accept bookings.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <Lock className="w-4 h-4 text-blue-600" />
              <span>2. Privacy & Exact Location Protection</span>
            </h4>
            <p>
              Your full address and contact details are masked and only revealed to the assigned professional when a booking is officially accepted. Location coordinates are accessed only with your express browser consent.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>3. Zero Hidden Charges & Transparent Pricing</span>
            </h4>
            <p>
              The platform publishes exact prices before booking. In case extra spare parts or labor are needed on-site, the provider must raise an itemized quote in the app which you must explicitly approve before any charge is added.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-purple-600" />
              <span>4. Rent Agreement State Jurisdictions</span>
            </h4>
            <p>
              Legal requirements, stamp duty schedules, biometric registration, and authorized procedures vary significantly across Indian states (e.g. Maharashtra Rent Control Act, Delhi Rent Act, Karnataka Tenancy Act). KARWA DO facilitates digital drafts and doorstep coordination in compliance with applicable local rules.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>5. Resolution & Dispute Guarantee</span>
            </h4>
            <p>
              Dissatisfied with a service? Raise a dispute directly from your booking card within 48 hours. Our escalation desk investigates with provider GPS logs, photographic evidence, and initiates refunds where warranted.
            </p>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800 transition"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
